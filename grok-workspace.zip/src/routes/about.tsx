import { createFileRoute, Link } from "@tanstack/react-router";
import { pageTitle, SITE } from "@/lib/site";
import { toolList } from "@/lib/catalog";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: pageTitle("About") },
      {
        name: "description",
        content: `About ${SITE.name}: a free, private collection of everyday calculators, converters, and generators.`,
      },
      { name: "robots", content: "index, follow" },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <main className="mx-auto flex max-w-3xl flex-col gap-6 px-4 py-12">
      <p className="drawing-label">About</p>
      <h1 className="font-display text-3xl font-semibold tracking-tight">
        A small public workshop.
      </h1>
      <p className="text-lg text-muted">
        {SITE.name} is a set of {toolList.length} everyday tools: the calculator
        you open before a meeting, the converter you need at a desk, the
        password you generate once and copy.
      </p>
      <p className="text-muted">
        Every tool runs in your browser. We do not create accounts, we do not
        store what you type on a server, and there is no charge to use the
        catalog.
      </p>
      <p className="text-muted">
        The layout is already prepared for advertising. When ads are enabled in
        one config file, they occupy reserved slots in the header, sidebar,
        in-content band, and footer. Until then those slots stay empty so the
        pages stay quiet.
      </p>
      <p className="text-muted">
        If you want a specific instrument added, start with the{" "}
        <Link to="/tools" className="text-fg underline underline-offset-2">
          full catalog
        </Link>{" "}
        — most daily jobs are already there.
      </p>
    </main>
  );
}
