import { useEffect } from "react";
import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Star } from "lucide-react";
import { getCategory, getTool, relatedTools, type ToolSlug } from "@/lib/catalog";
import { pageTitle } from "@/lib/site";
import { useToolPrefs } from "@/lib/prefs";
import { AdSlot } from "@/components/layout/ad-slot";
import { JsonLd } from "@/components/json-ld";
import { toolComponents } from "@/components/tools/registry";
import { ToolCard } from "@/components/tools/tool-card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/tools/$slug")({
  loader: ({ params }) => {
    const tool = getTool(params.slug);
    if (!tool) throw notFound();
    return { tool };
  },
  head: ({ loaderData }) => {
    const tool = loaderData?.tool;
    if (!tool) return { meta: [{ title: "Tool — Datum" }] };
    return {
      meta: [
        { title: pageTitle(tool.seoTitle) },
        { name: "description", content: tool.seoDescription },
        { name: "keywords", content: tool.keywords.join(", ") },
        { name: "robots", content: "index, follow" },
      ],
    };
  },
  component: ToolPage,
});

function ToolPage() {
  const { tool } = Route.useLoaderData();
  const Component = toolComponents[tool.slug as ToolSlug];
  const category = getCategory(tool.category);
  const related = relatedTools(tool.slug);
  const touch = useToolPrefs((s) => s.touch);
  const toggleFavorite = useToolPrefs((s) => s.toggleFavorite);
  const favorite = useToolPrefs((s) => s.favorites.includes(tool.slug));

  useEffect(() => {
    touch(tool.slug);
  }, [tool.slug, touch]);

  return (
    <main className="mx-auto flex max-w-6xl flex-col gap-8 px-4 py-8">
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "WebApplication",
          name: tool.name,
          applicationCategory: "UtilitiesApplication",
          operatingSystem: "Any",
          description: tool.seoDescription,
          offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
          isAccessibleForFree: true,
        }}
      />
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: "Home", item: "/" },
            { "@type": "ListItem", position: 2, name: "Tools", item: "/tools" },
            { "@type": "ListItem", position: 3, name: tool.name },
          ],
        }}
      />
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "HowTo",
          name: `Use the ${tool.name}`,
          description: tool.seoDescription,
          step: [
            {
              "@type": "HowToStep",
              name: "Open the tool",
              text: `Open the free ${tool.name} in your browser. No account is required.`,
            },
            {
              "@type": "HowToStep",
              name: "Enter values",
              text: "Type or paste your input. Processing happens on this device.",
            },
            {
              "@type": "HowToStep",
              name: "Copy the result",
              text: "Read the result and copy it if you need it elsewhere.",
            },
          ],
        }}
      />
      <nav className="text-sm text-muted" aria-label="Breadcrumb">
        <ol className="flex flex-wrap items-center gap-2">
          <li>
            <Link to="/" className="hover:text-fg">
              Home
            </Link>
          </li>
          <li aria-hidden="true">/</li>
          <li>
            <Link to="/tools" className="hover:text-fg">
              Tools
            </Link>
          </li>
          <li aria-hidden="true">/</li>
          <li className="text-fg">{tool.name}</li>
        </ol>
      </nav>

      <header className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="flex flex-col gap-2">
          <p className="drawing-label">
            {category?.index} {category?.label}
          </p>
          <h1 className="font-display text-3xl font-semibold tracking-tight">
            {tool.name}
          </h1>
          <p className="max-w-2xl text-muted">{tool.description}</p>
        </div>
        <Button
          type="button"
          variant="secondary"
          onClick={() => toggleFavorite(tool.slug)}
          aria-pressed={favorite}
        >
          <Star className={cn("size-4", favorite && "fill-fg")} />
          {favorite ? "Saved" : "Save"}
        </Button>
      </header>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_18rem]">
        <div className="min-w-0">{Component ? <Component /> : null}</div>
        <aside className="flex flex-col gap-4">
          <AdSlot slot="sidebar" />
          <div className="rounded-xl bg-surface p-4 shadow-card">
            <p className="drawing-label mb-2">On this device</p>
            <p className="text-sm text-muted">
              This tool processes data in your browser. Refreshing the page
              clears what you typed, except where noted.
            </p>
          </div>
          <div className="rounded-xl bg-surface p-4 shadow-card">
            <p className="drawing-label mb-2">About</p>
            <p className="text-sm text-muted">{tool.seoDescription}</p>
          </div>
        </aside>
      </div>

      <AdSlot slot="toolBottom" />

      <section className="flex flex-col gap-4">
        <h2 className="font-display text-2xl font-semibold">Related tools</h2>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {related.map((item) => (
            <ToolCard key={item.slug} tool={item} />
          ))}
        </div>
      </section>
    </main>
  );
}
