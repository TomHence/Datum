import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { categories, searchTools, toolsByCategory, toolList } from "@/lib/catalog";
import { SITE, pageTitle } from "@/lib/site";
import { AdSlot } from "@/components/layout/ad-slot";
import { ToolCard } from "@/components/tools/tool-card";
import { Input } from "@/components/ui/input";

type ToolsSearch = {
  q?: string;
};

export const Route = createFileRoute("/tools/")({
  validateSearch: (search: Record<string, unknown>): ToolsSearch => ({
    q: typeof search.q === "string" ? search.q : undefined,
  }),
  head: () => ({
    meta: [
      { title: pageTitle("All tools") },
      {
        name: "description",
        content: `Browse all ${toolList.length} free ${SITE.name} calculators, converters, generators, and text tools. ${SITE.description}`,
      },
      { name: "robots", content: "index, follow" },
    ],
  }),
  component: ToolsIndex,
});

function ToolsIndex() {
  const { q } = Route.useSearch();
  const [query, setQuery] = useState(q ?? "");
  const filtered = useMemo(() => searchTools(query), [query]);
  const searching = query.trim().length > 0;

  return (
    <main className="mx-auto flex max-w-6xl flex-col gap-10 px-4 py-10">
      <header className="flex flex-col gap-3">
        <p className="drawing-label">Catalog</p>
        <h1 className="font-display text-3xl font-semibold tracking-tight">All tools</h1>
        <p className="max-w-2xl text-muted">
          {toolList.length} instruments for daily work. Filter by name or keyword, or
          jump a category.
        </p>
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Filter tools…"
          className="max-w-md"
        />
      </header>
      <AdSlot slot="header" />
      {searching ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((tool) => (
            <ToolCard key={tool.slug} tool={tool} />
          ))}
        </div>
      ) : (
        categories.map((category) => (
          <section
            key={category.id}
            id={category.id}
            className="scroll-mt-24 flex flex-col gap-4"
          >
            <h2 className="font-display text-2xl font-semibold">
              <span className="drawing-label mr-3">{category.index}</span>
              {category.label}
            </h2>
            <p className="text-sm text-muted">{category.blurb}</p>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {toolsByCategory(category.id).map((tool) => (
                <ToolCard key={tool.slug} tool={tool} />
              ))}
            </div>
          </section>
        ))
      )}
    </main>
  );
}
