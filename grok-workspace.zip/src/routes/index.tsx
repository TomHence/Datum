import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Lock, Monitor, Search } from "lucide-react";
import {
  categories,
  popularTools,
  searchTools,
  toolsByCategory,
  toolList,
} from "@/lib/catalog";
import { SITE } from "@/lib/site";
import { siteFaq } from "@/lib/faq";
import { useToolPrefs } from "@/lib/prefs";
import { AdSlot } from "@/components/layout/ad-slot";
import { FaqSection } from "@/components/layout/faq-section";
import { HeroPlate } from "@/components/layout/hero-plate";
import { JsonLd } from "@/components/json-ld";
import { ToolCard } from "@/components/tools/tool-card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: `${SITE.name} — ${SITE.tagline}` },
      { name: "description", content: SITE.description },
      {
        name: "keywords",
        content:
          "free online tools, calculator, unit converter, password generator, word counter, json formatter, qr code, vat calculator, image compressor, image resizer, image crop",
      },
      { name: "robots", content: "index, follow" },
    ],
  }),
  component: Home,
});

function Home() {
  const [query, setQuery] = useState("");
  const [hydrated, setHydrated] = useState(false);
  const recents = useToolPrefs((s) => s.recents);
  const favorites = useToolPrefs((s) => s.favorites);
  useEffect(() => {
    setHydrated(true);
  }, []);
  const recentTools = hydrated
    ? recents
        .map((slug) => toolList.find((tool) => tool.slug === slug))
        .filter((tool): tool is NonNullable<typeof tool> => Boolean(tool))
    : [];
  const savedTools = hydrated
    ? favorites
        .map((slug) => toolList.find((tool) => tool.slug === slug))
        .filter((tool): tool is NonNullable<typeof tool> => Boolean(tool))
    : [];
  const filtered = useMemo(() => searchTools(query), [query]);
  const isSearch = query.trim().length > 0;

  return (
    <main>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "WebSite",
          name: SITE.name,
          description: SITE.description,
          potentialAction: {
            "@type": "SearchAction",
            target: "/tools?q={search_term_string}",
            "query-input": "required name=search_term_string",
          },
        }}
      />
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "ItemList",
          name: `${SITE.name} daily tools`,
          numberOfItems: toolList.length,
          itemListElement: toolList.map((tool, index) => ({
            "@type": "ListItem",
            position: index + 1,
            name: tool.name,
            url: `/tools/${tool.slug}`,
          })),
        }}
      />
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: siteFaq.map((item) => ({
            "@type": "Question",
            name: item.question,
            acceptedAnswer: { "@type": "Answer", text: item.answer },
          })),
        }}
      />

      <section className="hero-grid border-b border-border">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 lg:grid-cols-[minmax(0,1fr)_22rem] lg:items-stretch sm:py-16">
          <div className="flex flex-col justify-center gap-7">
            <p className="drawing-label">DS-01 / Public instruments</p>
            <h1 className="max-w-xl font-display text-3xl font-semibold tracking-tight sm:text-4xl">
              The tools you reach for every day.
            </h1>
            <p className="max-w-xl text-lg text-muted">
              {toolList.length} calculators, converters, and generators. They run
              on your device. Nothing is uploaded. There is no account and no fee.
            </p>
            <label className="relative max-w-xl">
              <span className="sr-only">Search tools</span>
              <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search percentage, password, JSON…"
                className="h-12 pl-10"
              />
            </label>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <a
                  key={category.id}
                  href={`#${category.id}`}
                  className="min-h-11 rounded-full bg-surface px-3 py-2 text-sm text-muted shadow-card hover:text-fg"
                >
                  {category.index} {category.label}
                </a>
              ))}
            </div>
            <dl className="grid max-w-xl grid-cols-3 gap-3 border-t border-border pt-5">
              {[
                { label: "Tools", value: String(toolList.length) },
                { label: "Accounts", value: "0" },
                { label: "Uploads", value: "0" },
              ].map((item) => (
                <div key={item.label}>
                  <dt className="drawing-label">{item.label}</dt>
                  <dd className="font-display text-2xl font-semibold tabular-nums">
                    {item.value}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
          <HeroPlate />
        </div>
      </section>

      <div className="mx-auto flex max-w-6xl flex-col gap-14 px-4 py-12">
        {isSearch ? (
          <section className="flex flex-col gap-4">
            <h2 className="font-display text-2xl font-semibold">
              {filtered.length} result{filtered.length === 1 ? "" : "s"}
            </h2>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {filtered.map((tool) => (
                <ToolCard key={tool.slug} tool={tool} />
              ))}
            </div>
          </section>
        ) : (
          <>
            {savedTools.length ? (
              <section className="flex flex-col gap-4">
                <p className="drawing-label">Saved on this device</p>
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  {savedTools.slice(0, 4).map((tool) => (
                    <ToolCard key={tool.slug} tool={tool} />
                  ))}
                </div>
              </section>
            ) : null}

            {recentTools.length ? (
              <section className="flex flex-col gap-4">
                <p className="drawing-label">Recently used</p>
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  {recentTools.slice(0, 4).map((tool) => (
                    <ToolCard key={tool.slug} tool={tool} />
                  ))}
                </div>
              </section>
            ) : null}

            <section className="flex flex-col gap-4">
              <div className="flex items-end justify-between gap-4">
                <div>
                  <p className="drawing-label">Frequently opened</p>
                  <h2 className="font-display text-2xl font-semibold">Popular tools</h2>
                </div>
                <Button asChild variant="ghost">
                  <Link to="/tools">
                    Full catalog
                    <ArrowRight className="size-4" />
                  </Link>
                </Button>
              </div>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {popularTools().map((tool) => (
                  <ToolCard key={tool.slug} tool={tool} />
                ))}
              </div>
            </section>

            <AdSlot slot="inContent" />

            {categories.map((category) => (
              <section
                key={category.id}
                id={category.id}
                className="scroll-mt-24 flex flex-col gap-4"
              >
                <div className="flex items-baseline justify-between gap-4">
                  <h2 className="font-display text-2xl font-semibold">
                    <span className="drawing-label mr-3">{category.index}</span>
                    {category.label}
                  </h2>
                  <p className="hidden max-w-sm text-sm text-muted sm:block">
                    {category.blurb}
                  </p>
                </div>
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {toolsByCategory(category.id).map((tool) => (
                    <ToolCard key={tool.slug} tool={tool} />
                  ))}
                </div>
              </section>
            ))}
          </>
        )}

        <section className="grid gap-4 rounded-xl bg-surface p-5 shadow-card sm:grid-cols-3">
          {[
            {
              icon: Lock,
              title: "Private by design",
              body: "Inputs never leave this tab. There is no account and no cloud processing.",
            },
            {
              icon: Monitor,
              title: "Works on your phone",
              body: "Large tap targets, a searchable catalog, and layouts that fit a narrow screen.",
            },
            {
              icon: ArrowRight,
              title: "Free, always",
              body: "Use every tool without paying. Ads can be added later without changing the layout.",
            },
          ].map((item) => (
            <div key={item.title} className="flex flex-col gap-2">
              <item.icon className="size-5 text-accent" strokeWidth={1.75} />
              <h3 className="font-medium">{item.title}</h3>
              <p className="text-sm text-muted">{item.body}</p>
            </div>
          ))}
        </section>

        <FaqSection />
      </div>
    </main>
  );
}
