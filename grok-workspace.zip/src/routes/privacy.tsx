import { createFileRoute } from "@tanstack/react-router";
import { pageTitle, SITE } from "@/lib/site";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: pageTitle("Privacy") },
      {
        name: "description",
        content: `Privacy notes for ${SITE.name}. Tools run in your browser. We do not sell personal data.`,
      },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <main className="mx-auto flex max-w-3xl flex-col gap-6 px-4 py-12">
      <p className="drawing-label">Privacy</p>
      <h1 className="font-display text-3xl font-semibold tracking-tight">
        What stays on your device.
      </h1>
      <section className="flex flex-col gap-3 text-muted">
        <h2 className="font-display text-xl font-semibold text-fg">Tool input</h2>
        <p>
          Calculators, converters, generators, and text tools run entirely in
          your browser. The numbers, passwords, JSON, and notes you type are
          not uploaded to a {SITE.name} server.
        </p>
      </section>
      <section className="flex flex-col gap-3 text-muted">
        <h2 className="font-display text-xl font-semibold text-fg">Local storage</h2>
        <p>
          This site may keep recent tools, saved tools, and your world-clock
          city list in your browser's local storage so the catalog feels
          familiar on the next visit. You can clear that data from your
          browser settings.
        </p>
      </section>
      <section className="flex flex-col gap-3 text-muted">
        <h2 className="font-display text-xl font-semibold text-fg">Fonts</h2>
        <p>
          Typefaces are loaded from Google Fonts. That request is made by your
          browser to Google's servers.
        </p>
      </section>
      <section className="flex flex-col gap-3 text-muted">
        <h2 className="font-display text-xl font-semibold text-fg">Advertising</h2>
        <p>
          Advertising is currently off. If ads are enabled later, a third-party
          network such as Google AdSense may set cookies and collect standard
          advertising data according to that network's policy.
        </p>
      </section>
      <section className="flex flex-col gap-3 text-muted">
        <h2 className="font-display text-xl font-semibold text-fg">Accounts</h2>
        <p>There are no user accounts and no passwords stored by this site.</p>
      </section>
    </main>
  );
}
