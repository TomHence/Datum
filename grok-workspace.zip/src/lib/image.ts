export const MAX_IMAGE_BYTES = 12 * 1024 * 1024;

export const MIME = {
  jpeg: "image/jpeg",
  png: "image/png",
  webp: "image/webp",
} as const;

export type MimeKey = keyof typeof MIME;

export async function fileToImage(file: File): Promise<{ img: HTMLImageElement; url: string }> {
  if (!file.type.startsWith("image/") && file.type !== "image/svg+xml") {
    throw new Error("Choose an image file.");
  }
  if (file.size > MAX_IMAGE_BYTES) {
    throw new Error("Keep files under 12 MB.");
  }

  if (typeof createImageBitmap === "function") {
    try {
      const bitmap = await createImageBitmap(file, {
        imageOrientation: "from-image",
      } as ImageBitmapOptions);
      const canvas = document.createElement("canvas");
      canvas.width = bitmap.width;
      canvas.height = bitmap.height;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("Canvas is not available.");
      ctx.drawImage(bitmap, 0, 0);
      bitmap.close();
      const blob = await canvasToBlob(canvas, file.type.startsWith("image/") ? file.type : "image/png");
      const url = URL.createObjectURL(blob);
      const img = await blobUrlToImage(url);
      return { img, url };
    } catch {
      /* fall through to element decode */
    }
  }

  const url = URL.createObjectURL(file);
  try {
    const img = await blobUrlToImage(url);
    return { img, url };
  } catch (err) {
    URL.revokeObjectURL(url);
    throw err;
  }
}

function blobUrlToImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Could not read that image."));
    img.src = url;
  });
}

export function makeCanvas(width: number, height: number) {
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(width));
  canvas.height = Math.max(1, Math.round(height));
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas is not available.");
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  return { canvas, ctx };
}

export function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

export function canvasToBlob(
  canvas: HTMLCanvasElement,
  type: string,
  quality = 0.92,
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (!blob) reject(new Error("Could not export the image."));
        else resolve(blob);
      },
      type,
      quality,
    );
  });
}

export async function compressToTarget(
  canvas: HTMLCanvasElement,
  type: string,
  targetBytes: number,
): Promise<Blob> {
  if (type === MIME.png) return canvasToBlob(canvas, type);
  let lo = 0.35;
  let hi = 0.96;
  let best = await canvasToBlob(canvas, type, 0.72);
  if (best.size <= targetBytes) {
    const finer = await canvasToBlob(canvas, type, hi);
    if (finer.size <= targetBytes) return finer;
  }
  for (let i = 0; i < 8; i += 1) {
    const mid = (lo + hi) / 2;
    const blob = await canvasToBlob(canvas, type, mid);
    if (blob.size > targetBytes) {
      hi = mid;
    } else {
      lo = mid;
      best = blob;
    }
  }
  return best;
}

export function fillColor(
  ctx: CanvasRenderingContext2D,
  color: string,
  width: number,
  height: number,
) {
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, width, height);
}

export function fillPaper(ctx: CanvasRenderingContext2D, width: number, height: number) {
  const raw = getComputedStyle(document.body).getPropertyValue("--color-bg").trim();
  fillColor(ctx, raw || "white", width, height);
}

export function drawFitted(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  width: number,
  height: number,
  mode: "contain" | "cover",
) {
  const scale =
    mode === "cover"
      ? Math.max(width / img.naturalWidth, height / img.naturalHeight)
      : Math.min(width / img.naturalWidth, height / img.naturalHeight);
  const dw = img.naturalWidth * scale;
  const dh = img.naturalHeight * scale;
  ctx.drawImage(img, (width - dw) / 2, (height - dh) / 2, dw, dh);
}

export function rotatedSize(width: number, height: number, radians: number) {
  const c = Math.abs(Math.cos(radians));
  const s = Math.abs(Math.sin(radians));
  return {
    width: Math.max(1, Math.round(width * c + height * s)),
    height: Math.max(1, Math.round(width * s + height * c)),
  };
}

export function applyVignette(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  amount: number,
) {
  if (amount <= 0) return;
  const inner = Math.min(width, height) * 0.32;
  const outer = Math.max(width, height) * 0.72;
  const g = ctx.createRadialGradient(width / 2, height / 2, inner, width / 2, height / 2, outer);
  g.addColorStop(0, "rgba(0,0,0,0)");
  g.addColorStop(1, `rgba(0,0,0,${amount})`);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, width, height);
}

export function toHex(r: number, g: number, b: number) {
  return `#${[r, g, b].map((n) => n.toString(16).padStart(2, "0")).join("")}`;
}

export function hexToRgb(hex: string): [number, number, number] | null {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m?.[1]) return null;
  const n = Number.parseInt(m[1], 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function rgbToHsl(r: number, g: number, b: number) {
  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;
  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const d = max - min;
  let h = 0;
  if (d !== 0) {
    if (max === rn) h = ((gn - bn) / d) % 6;
    else if (max === gn) h = (bn - rn) / d + 2;
    else h = (rn - gn) / d + 4;
    h *= 60;
    if (h < 0) h += 360;
  }
  const l = (max + min) / 2;
  const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
  return `${Math.round(h)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
}

export function extractPalette(img: HTMLImageElement, count = 6): string[] {
  const canvas = document.createElement("canvas");
  const w = 96;
  const h = Math.max(1, Math.round((96 * img.naturalHeight) / img.naturalWidth));
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) return [];
  ctx.drawImage(img, 0, 0, w, h);
  const data = ctx.getImageData(0, 0, w, h).data;
  const buckets = new Map<string, { n: number; r: number; g: number; b: number }>();
  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] < 128) continue;
    const r = data[i] >> 4 << 4;
    const g = data[i + 1] >> 4 << 4;
    const b = data[i + 2] >> 4 << 4;
    const key = `${r},${g},${b}`;
    const cur = buckets.get(key) ?? { n: 0, r: 0, g: 0, b: 0 };
    cur.n += 1;
    cur.r += data[i];
    cur.g += data[i + 1];
    cur.b += data[i + 2];
    buckets.set(key, cur);
  }
  return [...buckets.values()]
    .sort((a, b) => b.n - a.n)
    .slice(0, count)
    .map((c) => toHex(Math.round(c.r / c.n), Math.round(c.g / c.n), Math.round(c.b / c.n)));
}

export function extFor(type: string) {
  if (type === "image/webp") return "webp";
  if (type === "image/png") return "png";
  return "jpg";
}

export function stem(name: string) {
  return name.replace(/\.[^.]+$/, "") || "image";
}

export function scaledEdge(img: HTMLImageElement, maxEdge: number) {
  const scale = Math.min(1, maxEdge / Math.max(img.naturalWidth, img.naturalHeight));
  return {
    width: Math.max(1, Math.round(img.naturalWidth * scale)),
    height: Math.max(1, Math.round(img.naturalHeight * scale)),
  };
}
