import { SITE, pageTitle } from "@/lib/site";

export function pageMeta(opts: {
  title: string;
  description: string;
  keywords?: string;
}) {
  return [
    { title: pageTitle(opts.title) },
    { name: "description", content: opts.description },
    ...(opts.keywords ? [{ name: "keywords", content: opts.keywords }] : []),
    { name: "robots", content: "index, follow" },
    { name: "author", content: SITE.name },
  ];
}
