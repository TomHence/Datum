import type { ReactNode } from "react";
import { createElement, Fragment } from "react";

function escapeText(text: string) {
  return text
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">");
}

function inline(text: string): ReactNode[] {
  const nodes: ReactNode[] = [];
  const pattern =
    /(`[^`]+`)|(\*\*[^*]+\*\*)|(\*[^*]+\*)|(\[[^\]]+\]\([^)]+\))/g;
  let last = 0;
  let match: RegExpExecArray | null;
  let key = 0;
  while ((match = pattern.exec(text))) {
    if (match.index > last) {
      nodes.push(text.slice(last, match.index));
    }
    const token = match[0];
    if (token.startsWith("`")) {
      nodes.push(
        createElement(
          "code",
          { key: key++, className: "rounded-sm bg-bg px-1 py-0.5 font-mono text-sm" },
          token.slice(1, -1),
        ),
      );
    } else if (token.startsWith("**")) {
      nodes.push(createElement("strong", { key: key++ }, token.slice(2, -2)));
    } else if (token.startsWith("*")) {
      nodes.push(createElement("em", { key: key++ }, token.slice(1, -1)));
    } else {
      const link = token.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
      if (link) {
        const href = link[2].startsWith("http") ? link[2] : "#";
        nodes.push(
          createElement(
            "a",
            {
              key: key++,
              href,
              className: "text-accent underline underline-offset-2",
              target: href.startsWith("http") ? "_blank" : undefined,
              rel: href.startsWith("http") ? "noreferrer" : undefined,
            },
            link[1],
          ),
        );
      }
    }
    last = match.index + token.length;
  }
  if (last < text.length) nodes.push(text.slice(last));
  return nodes;
}

export function renderMarkdown(source: string): ReactNode {
  const lines = source.replace(/\r\n/g, "\n").split("\n");
  const blocks: ReactNode[] = [];
  let i = 0;
  let key = 0;

  while (i < lines.length) {
    const line = lines[i];
    if (!line.trim()) {
      i += 1;
      continue;
    }
    if (line.startsWith("```")) {
      const buf: string[] = [];
      i += 1;
      while (i < lines.length && !lines[i].startsWith("```")) {
        buf.push(lines[i]);
        i += 1;
      }
      i += 1;
      blocks.push(
        createElement(
          "pre",
          {
            key: key++,
            className:
              "overflow-x-auto rounded-md bg-bg p-4 font-mono text-sm shadow-card",
          },
          createElement("code", null, buf.join("\n")),
        ),
      );
      continue;
    }
    if (line.startsWith("# ")) {
      blocks.push(
        createElement(
          "h1",
          { key: key++, className: "font-display text-2xl font-semibold" },
          ...inline(line.slice(2)),
        ),
      );
      i += 1;
      continue;
    }
    if (line.startsWith("## ")) {
      blocks.push(
        createElement(
          "h2",
          { key: key++, className: "font-display text-xl font-semibold" },
          ...inline(line.slice(3)),
        ),
      );
      i += 1;
      continue;
    }
    if (line.startsWith("### ")) {
      blocks.push(
        createElement(
          "h3",
          { key: key++, className: "font-display text-lg font-semibold" },
          ...inline(line.slice(4)),
        ),
      );
      i += 1;
      continue;
    }
    if (line.startsWith("> ")) {
      const buf = [line.slice(2)];
      i += 1;
      while (i < lines.length && lines[i].startsWith("> ")) {
        buf.push(lines[i].slice(2));
        i += 1;
      }
      blocks.push(
        createElement(
          "blockquote",
          {
            key: key++,
            className: "border-l-2 border-border-strong pl-4 text-muted",
          },
          buf.join(" "),
        ),
      );
      continue;
    }
    if (/^[-*] /.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^[-*] /.test(lines[i])) {
        items.push(lines[i].replace(/^[-*] /, ""));
        i += 1;
      }
      blocks.push(
        createElement(
          "ul",
          { key: key++, className: "list-disc space-y-1 pl-5" },
          items.map((item, idx) =>
            createElement("li", { key: idx }, ...inline(item)),
          ),
        ),
      );
      continue;
    }
    if (/^\d+\. /.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\d+\. /.test(lines[i])) {
        items.push(lines[i].replace(/^\d+\. /, ""));
        i += 1;
      }
      blocks.push(
        createElement(
          "ol",
          { key: key++, className: "list-decimal space-y-1 pl-5" },
          items.map((item, idx) =>
            createElement("li", { key: idx }, ...inline(item)),
          ),
        ),
      );
      continue;
    }
    const para = [line];
    i += 1;
    while (
      i < lines.length &&
      lines[i].trim() &&
      !/^#{1,3} |^```|^> |^[-*] |^\d+\. /.test(lines[i])
    ) {
      para.push(lines[i]);
      i += 1;
    }
    blocks.push(
      createElement(
        "p",
        { key: key++, className: "leading-normal" },
        ...inline(para.join(" ")),
      ),
    );
  }

  if (!blocks.length) {
    return createElement("p", { className: "text-muted" }, "Preview appears here.");
  }
  return createElement(Fragment, null, ...blocks);
}

export function escapeHtmlPreview(text: string) {
  return escapeText(text);
}
