import { SITE } from "@/lib/site";
import { toolList } from "@/lib/catalog";

export const siteFaq = [
  {
    question: "Are these tools really free?",
    answer:
      "Yes. Every tool on Datum is free to use. There is no account, no trial, and no paywall.",
  },
  {
    question: "Do you upload what I type?",
    answer:
      "No. Calculators, converters, and generators run in your browser. Inputs stay on your device.",
  },
  {
    question: "Will this work on my phone?",
    answer:
      "Yes. The layout is built for a phone-width screen first, with tap targets large enough for thumbs.",
  },
  {
    question: "How many tools are there?",
    answer: `The catalog currently has ${toolList.length} instruments across calculate, convert, text, generate, develop, time, and image.`,
  },
  {
    question: "Will there be ads?",
    answer: `${SITE.name} is designed so advertising can be switched on later without redesigning pages. Ads are currently off.`,
  },
] as const;
