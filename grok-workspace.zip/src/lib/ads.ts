/**
 * Single switch for advertising.
 *
 * 1. Create an AdSense (or similar) account and add this site.
 * 2. Paste your publisher client id and slot ids below.
 * 3. Set `enabled` to true.
 *
 * Layout already reserves header, in-content, sidebar, tool-bottom, and footer slots.
 * While `enabled` is false, slots render nothing so the layout stays clean.
 */
export const adsConfig = {
  enabled: false,
  provider: "adsense" as const,
  adsenseClient: "ca-pub-XXXXXXXXXXXXXXXX",
  slots: {
    header: "0000000000",
    inContent: "0000000000",
    sidebar: "0000000000",
    toolBottom: "0000000000",
    footer: "0000000000",
  },
} as const;

export type AdSlotId = keyof typeof adsConfig.slots;

export function adsAreLive() {
  return adsConfig.enabled && !adsConfig.adsenseClient.includes("XXXX");
}

export function adsShowPreview() {
  return adsConfig.enabled && !adsAreLive();
}

export function adsenseScriptSrc() {
  return `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${adsConfig.adsenseClient}`;
}
