import { toolList } from "@/lib/catalog";

function xmlEscape(value: string) {
  return value
    .replaceAll("&", "&" + "amp;")
    .replaceAll("<", "&" + "lt;")
    .replaceAll(">", "&" + "gt;")
    .replaceAll('"', "&" + "quot;");
}

const LASTMOD = "2026-09-30";

export function buildSitemap(origin: string) {
  const paths: { path: string; priority: string }[] = [
    { path: "/", priority: "1.0" },
    { path: "/tools", priority: "0.9" },
    { path: "/about", priority: "0.4" },
    { path: "/privacy", priority: "0.3" },
    ...toolList.map((tool) => ({ path: `/tools/${tool.slug}`, priority: "0.8" })),
  ];
  const urls = paths
    .map((item) => {
      const loc = xmlEscape(`${origin}${item.path}`);
      return `  <url>\n    <loc>${loc}</loc>\n    <lastmod>${LASTMOD}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>${item.priority}</priority>\n  </url>`;
    })
    .join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;
}
