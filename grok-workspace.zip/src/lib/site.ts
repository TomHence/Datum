export const SITE = {
  name: "Datum",
  tagline: "Daily tools. Exact, private, free.",
  description:
    "Free online calculators, converters, generators, and text tools. Everything runs in your browser — no account, no uploads, no cost.",
  shortName: "Datum",
} as const;

export function pageTitle(name: string) {
  return `${name} — ${SITE.name}`;
}
