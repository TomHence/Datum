import { toast } from "sonner";

export async function copyText(text: string, success = "Copied") {
  try {
    await navigator.clipboard.writeText(text);
    toast.success(success);
    return true;
  } catch {
    toast.error("Could not copy");
    return false;
  }
}
