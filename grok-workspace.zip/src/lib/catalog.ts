export const categories = [
  {
    id: "calculate",
    label: "Calculate",
    index: "01",
    blurb: "Percentages, loans, tips, tax, and everyday arithmetic.",
  },
  {
    id: "convert",
    label: "Convert",
    index: "02",
    blurb: "Units, color, time zones, and number bases.",
  },
  {
    id: "text",
    label: "Text",
    index: "03",
    blurb: "Count, restyle, clean, and compare copy without leaving the page.",
  },
  {
    id: "generate",
    label: "Generate",
    index: "04",
    blurb: "Passwords, QR codes, IDs, and random values.",
  },
  {
    id: "develop",
    label: "Develop",
    index: "05",
    blurb: "Format JSON, encode data, and hash strings locally.",
  },
  {
    id: "time",
    label: "Time",
    index: "06",
    blurb: "Clocks, timers, ages, countdowns, and focus sessions.",
  },
  {
    id: "image",
    label: "Image",
    index: "07",
    blurb: "Resize, crop, convert, and inspect pictures on this device.",
  },
] as const;

export type CategoryId = (typeof categories)[number]["id"];

export type ToolIcon =
  | "calculator"
  | "percent"
  | "scale"
  | "utensils"
  | "tag"
  | "landmark"
  | "trending-up"
  | "users"
  | "ruler"
  | "pipette"
  | "clock"
  | "binary"
  | "globe"
  | "type"
  | "case-sensitive"
  | "text-quote"
  | "file-code"
  | "key-round"
  | "qr-code"
  | "fingerprint"
  | "dices"
  | "braces"
  | "file-digit"
  | "link-2"
  | "hash"
  | "timer"
  | "cake"
  | "earth"
  | "circle-dot"
  | "receipt"
  | "wallet"
  | "fuel"
  | "image"
  | "file-image"
  | "eraser"
  | "columns-2"
  | "hourglass"
  | "crop"
  | "scaling"
  | "rotate-cw"
  | "sun"
  | "palette"
  | "image-down"
  | "stamp"
  | "square-dashed";

export type ToolDef = {
  slug: string;
  name: string;
  description: string;
  seoTitle: string;
  seoDescription: string;
  category: CategoryId;
  icon: ToolIcon;
  keywords: string[];
  popular?: boolean;
};

export const tools = [
  {
    slug: "calculator",
    name: "Calculator",
    description: "A fast on-screen calculator with keyboard support.",
    seoTitle: "Online Calculator",
    seoDescription:
      "Free online calculator for everyday arithmetic. Use your keyboard or tap the pad. Runs entirely in your browser.",
    category: "calculate",
    icon: "calculator",
    keywords: ["calculator", "math", "add", "multiply"],
    popular: true,
  },
  {
    slug: "percentage",
    name: "Percentage",
    description: "Find a percent of a number, reverse percent, or percent change.",
    seoTitle: "Percentage Calculator",
    seoDescription:
      "Calculate percentages, reverse percentages, and percent change instantly. Free, private, no sign-up.",
    category: "calculate",
    icon: "percent",
    keywords: ["percent", "percentage", "increase", "decrease"],
    popular: true,
  },
  {
    slug: "bmi-calculator",
    name: "BMI Calculator",
    description: "Body mass index from height and weight, metric or imperial.",
    seoTitle: "BMI Calculator",
    seoDescription:
      "Calculate body mass index in metric or imperial units and see the standard weight category.",
    category: "calculate",
    icon: "scale",
    keywords: ["bmi", "body mass", "health", "weight"],
    popular: true,
  },
  {
    slug: "tip-calculator",
    name: "Tip Calculator",
    description: "Split a bill with tip and per-person totals.",
    seoTitle: "Tip Calculator",
    seoDescription:
      "Calculate tip and split a restaurant bill between any number of people. Free and instant.",
    category: "calculate",
    icon: "utensils",
    keywords: ["tip", "gratuity", "bill", "split"],
    popular: true,
  },
  {
    slug: "discount-calculator",
    name: "Discount Calculator",
    description: "Sale price, amount saved, or original price from a discount.",
    seoTitle: "Discount Calculator",
    seoDescription:
      "Find sale price, savings, or the original price from a discount percentage.",
    category: "calculate",
    icon: "tag",
    keywords: ["discount", "sale", "off", "markdown"],
  },
  {
    slug: "vat-calculator",
    name: "VAT & Sales Tax",
    description: "Add or remove tax. See net, tax, and gross from one amount.",
    seoTitle: "VAT and Sales Tax Calculator",
    seoDescription:
      "Add or extract VAT and sales tax. Enter an amount and rate to see net, tax, and gross. Free, in-browser.",
    category: "calculate",
    icon: "receipt",
    keywords: ["vat", "sales tax", "gst", "tax inclusive"],
    popular: true,
  },
  {
    slug: "loan-calculator",
    name: "Loan Calculator",
    description: "Monthly payment, total interest, and payoff for a fixed loan.",
    seoTitle: "Loan & EMI Calculator",
    seoDescription:
      "Estimate monthly loan payments (EMI), total interest, and overall cost from amount, rate, and term.",
    category: "calculate",
    icon: "landmark",
    keywords: ["loan", "emi", "mortgage", "payment"],
  },
  {
    slug: "compound-interest",
    name: "Compound Interest",
    description: "Future value with compounding frequency and optional contributions.",
    seoTitle: "Compound Interest Calculator",
    seoDescription:
      "Project compound growth from principal, rate, time, compounding frequency, and monthly additions.",
    category: "calculate",
    icon: "trending-up",
    keywords: ["compound", "interest", "investment", "savings"],
  },
  {
    slug: "salary-converter",
    name: "Salary Converter",
    description: "Hourly, monthly, and yearly pay from hours and working weeks.",
    seoTitle: "Salary to Hourly Converter",
    seoDescription:
      "Convert hourly, monthly, and yearly salary. Adjust hours per week and weeks per year. Free and private.",
    category: "calculate",
    icon: "wallet",
    keywords: ["salary", "hourly", "wage", "annual"],
  },
  {
    slug: "split-bill",
    name: "Split Bill",
    description: "Divide a total across people, with optional tax and tip.",
    seoTitle: "Bill Splitter",
    seoDescription:
      "Split a bill evenly with tax and tip. See the total and the amount each person pays.",
    category: "calculate",
    icon: "users",
    keywords: ["split", "bill", "share", "group"],
  },
  {
    slug: "fuel-cost",
    name: "Fuel Cost",
    description: "Trip cost from distance, economy, and price per litre or gallon.",
    seoTitle: "Fuel Cost Calculator",
    seoDescription:
      "Estimate trip fuel cost from distance, fuel economy, and price. Supports L/100km, MPG, litres, and gallons.",
    category: "calculate",
    icon: "fuel",
    keywords: ["fuel", "gas", "mileage", "trip cost"],
  },
  {
    slug: "unit-converter",
    name: "Unit Converter",
    description: "Length, mass, temperature, volume, area, speed, data, and more.",
    seoTitle: "Unit Converter",
    seoDescription:
      "Convert length, weight, temperature, volume, area, speed, time, energy, pressure, and data units.",
    category: "convert",
    icon: "ruler",
    keywords: ["units", "convert", "metric", "imperial"],
    popular: true,
  },
  {
    slug: "color-converter",
    name: "Color Converter",
    description: "Hex, RGB, and HSL with contrast against white and black.",
    seoTitle: "Color Converter",
    seoDescription:
      "Convert colors between HEX, RGB, and HSL. Check contrast against white and black.",
    category: "convert",
    icon: "pipette",
    keywords: ["color", "hex", "rgb", "hsl"],
  },
  {
    slug: "unix-timestamp",
    name: "Unix Timestamp",
    description: "Convert epoch seconds or milliseconds to local and UTC time.",
    seoTitle: "Unix Timestamp Converter",
    seoDescription:
      "Convert Unix epoch time to human-readable dates and back. Supports seconds and milliseconds.",
    category: "convert",
    icon: "clock",
    keywords: ["unix", "epoch", "timestamp", "utc"],
  },
  {
    slug: "number-base",
    name: "Number Base",
    description: "Decimal, binary, octal, and hexadecimal in both directions.",
    seoTitle: "Binary Hex Converter",
    seoDescription:
      "Convert numbers between decimal, binary, octal, and hexadecimal. Free and instant.",
    category: "convert",
    icon: "binary",
    keywords: ["binary", "hex", "octal", "base"],
  },
  {
    slug: "timezone-converter",
    name: "Time Zone Converter",
    description: "Convert a date and time between major world cities.",
    seoTitle: "Time Zone Converter",
    seoDescription:
      "Convert a date and time across world time zones. Compare cities without leaving the page.",
    category: "convert",
    icon: "globe",
    keywords: ["timezone", "utc", "convert time", "cities"],
  },
  {
    slug: "word-counter",
    name: "Word Counter",
    description: "Words, characters, sentences, paragraphs, and reading time.",
    seoTitle: "Word Counter",
    seoDescription:
      "Count words, characters, sentences, and paragraphs. Includes speaking and reading time.",
    category: "text",
    icon: "type",
    keywords: ["word count", "characters", "reading time"],
    popular: true,
  },
  {
    slug: "case-converter",
    name: "Case Converter",
    description: "Upper, lower, title, sentence, camel, snake, and kebab case.",
    seoTitle: "Text Case Converter",
    seoDescription:
      "Convert text to uppercase, lowercase, title case, sentence case, camelCase, snake_case, and kebab-case.",
    category: "text",
    icon: "case-sensitive",
    keywords: ["uppercase", "lowercase", "title case", "camelCase"],
  },
  {
    slug: "text-cleaner",
    name: "Text Cleaner",
    description: "Trim, collapse spaces, drop empty or duplicate lines, sort.",
    seoTitle: "Text Cleaner",
    seoDescription:
      "Clean pasted text: trim lines, collapse whitespace, remove empty or duplicate lines, and sort. Runs locally.",
    category: "text",
    icon: "eraser",
    keywords: ["trim", "whitespace", "duplicate lines", "clean text"],
  },
  {
    slug: "text-diff",
    name: "Text Diff",
    description: "Compare two blocks of text and highlight added or removed lines.",
    seoTitle: "Text Difference Checker",
    seoDescription:
      "Compare two texts line by line. See additions, deletions, and unchanged lines. Private, in-browser.",
    category: "text",
    icon: "columns-2",
    keywords: ["diff", "compare text", "difference", "changes"],
  },
  {
    slug: "lorem-ipsum",
    name: "Lorem Ipsum",
    description: "Generate placeholder paragraphs, sentences, or words.",
    seoTitle: "Lorem Ipsum Generator",
    seoDescription:
      "Generate Lorem Ipsum placeholder text by paragraphs, sentences, or words. Copy in one click.",
    category: "text",
    icon: "text-quote",
    keywords: ["lorem", "ipsum", "placeholder", "dummy text"],
  },
  {
    slug: "markdown-preview",
    name: "Markdown Preview",
    description: "Write Markdown on the left, see a live preview on the right.",
    seoTitle: "Markdown Preview",
    seoDescription:
      "Live Markdown editor and preview. Headings, lists, links, and code — all in the browser.",
    category: "text",
    icon: "file-code",
    keywords: ["markdown", "md", "preview", "editor"],
  },
  {
    slug: "password-generator",
    name: "Password Generator",
    description: "Strong random passwords with length and character controls.",
    seoTitle: "Password Generator",
    seoDescription:
      "Generate strong random passwords on your device. Choose length, symbols, and similar-character exclusion.",
    category: "generate",
    icon: "key-round",
    keywords: ["password", "generator", "random", "secure"],
    popular: true,
  },
  {
    slug: "qr-code",
    name: "QR Code",
    description: "Turn a URL or any text into a downloadable QR code.",
    seoTitle: "QR Code Generator",
    seoDescription:
      "Create a QR code from a URL or text and download it as SVG or PNG. Generated locally.",
    category: "generate",
    icon: "qr-code",
    keywords: ["qr", "qr code", "barcode", "url"],
    popular: true,
  },
  {
    slug: "image-compressor",
    name: "Image Compressor",
    description: "Shrink a photo. Quality, target size, Web/Email presets, and a before/after wipe.",
    seoTitle: "Image Compressor",
    seoDescription:
      "Compress JPEG, WebP, or PNG in your browser. Target a file size, keep dimensions, compare original vs result. Nothing is uploaded.",
    category: "image",
    icon: "image",
    keywords: ["compress image", "resize", "jpeg", "webp"],
    popular: true,
  },
  {
    slug: "uuid-generator",
    name: "UUID Generator",
    description: "Version 4 UUIDs using the Web Crypto API.",
    seoTitle: "UUID Generator",
    seoDescription:
      "Generate RFC 4122 version 4 UUIDs in your browser with the Web Crypto API.",
    category: "generate",
    icon: "fingerprint",
    keywords: ["uuid", "guid", "v4", "identifier"],
  },
  {
    slug: "random-number",
    name: "Random Number",
    description: "Cryptographically strong random integers in a range.",
    seoTitle: "Random Number Generator",
    seoDescription:
      "Generate random integers in any range. Optional unique draws, powered by Web Crypto.",
    category: "generate",
    icon: "dices",
    keywords: ["random", "number", "dice", "rng"],
  },
  {
    slug: "json-formatter",
    name: "JSON Formatter",
    description: "Pretty-print, minify, and validate JSON with error location.",
    seoTitle: "JSON Formatter",
    seoDescription:
      "Format, minify, and validate JSON in your browser. See parse errors with position.",
    category: "develop",
    icon: "braces",
    keywords: ["json", "pretty print", "minify", "validate"],
    popular: true,
  },
  {
    slug: "base64",
    name: "Base64",
    description: "Encode or decode Base64 text using UTF-8.",
    seoTitle: "Base64 Encoder Decoder",
    seoDescription:
      "Encode text to Base64 or decode it back. UTF-8 safe, entirely on your device.",
    category: "develop",
    icon: "file-digit",
    keywords: ["base64", "encode", "decode"],
  },
  {
    slug: "image-base64",
    name: "Image to Base64",
    description: "Turn an image into a data URL. Optional compress, plus HTML, CSS, and Markdown.",
    seoTitle: "Image to Base64 Converter",
    seoDescription:
      "Convert an image to a Base64 data URL in your browser. Compress first, then copy HTML, CSS, or Markdown. No upload.",
    category: "image",
    icon: "file-image",
    keywords: ["image base64", "data url", "embed image"],
  },
  {
    slug: "image-resizer",
    name: "Image Resizer",
    description: "Exact pixels or percent scale. Fit, fill, or stretch, with matte and compare.",
    seoTitle: "Image Resizer",
    seoDescription:
      "Resize images by pixels or percent. Fit, fill, or stretch. Social presets, quality, and a before/after view. Nothing is uploaded.",
    category: "image",
    icon: "scaling",
    keywords: ["resize image", "scale", "pixels", "thumbnail"],
    popular: true,
  },
  {
    slug: "image-crop",
    name: "Image Crop",
    description: "Drag to pan, custom ratios, rule of thirds, rounded corners, and export size.",
    seoTitle: "Image Cropper",
    seoDescription:
      "Crop a photo by dragging. Custom aspect, rule of thirds, rounded corners, and export width. Runs locally.",
    category: "image",
    icon: "crop",
    keywords: ["crop image", "square crop", "aspect ratio", "circle crop"],
    popular: true,
  },
  {
    slug: "image-convert",
    name: "Image Convert",
    description: "JPEG, PNG, and WebP side by side. Matte for transparency, download all three.",
    seoTitle: "Image Format Converter",
    seoDescription:
      "Convert images between JPEG, PNG, and WebP. Compare file sizes and download every format at once. No upload.",
    category: "image",
    icon: "image-down",
    keywords: ["convert image", "png to jpg", "webp", "format"],
  },
  {
    slug: "image-rotate",
    name: "Rotate & Flip",
    description: "Any angle, straighten, expand canvas or crop, flip, then export.",
    seoTitle: "Rotate and Flip Image",
    seoDescription:
      "Rotate any number of degrees, straighten a horizon, expand the canvas, and flip. Processed on your device.",
    category: "image",
    icon: "rotate-cw",
    keywords: ["rotate image", "flip", "mirror", "orient"],
  },
  {
    slug: "image-filters",
    name: "Image Filters",
    description: "Presets, hue, vignette, and a wipe between original and result.",
    seoTitle: "Image Filters",
    seoDescription:
      "Punch, fade, film, noir, and custom sliders. Hue, vignette, and a before/after wipe. All in the browser.",
    category: "image",
    icon: "sun",
    keywords: ["image filter", "grayscale", "brightness", "contrast"],
  },
  {
    slug: "image-palette",
    name: "Color Palette",
    description: "3–10 swatches with hex and HSL. Copy CSS variables or JSON.",
    seoTitle: "Image Color Palette Extractor",
    seoDescription:
      "Extract a colour palette from an image. Copy hex, HSL, CSS variables, or JSON. Nothing is uploaded.",
    category: "image",
    icon: "palette",
    keywords: ["color palette", "extract colors", "hex from image"],
  },
  {
    slug: "image-watermark",
    name: "Watermark",
    description: "Text or logo, tile, rotate, outline, and a compare view.",
    seoTitle: "Image Watermark",
    seoDescription:
      "Add a text or logo watermark. Tile it, rotate, outline, and compare with the original. Runs locally.",
    category: "image",
    icon: "stamp",
    keywords: ["watermark", "overlay text", "copyright"],
  },
  {
    slug: "image-placeholder",
    name: "Placeholder Image",
    description: "Solid, grid, or checker. Subtitle, retina @2x, PNG/JPEG/WebP.",
    seoTitle: "Placeholder Image Generator",
    seoDescription:
      "Create a placeholder image with grid or checker pattern, subtitle, and retina @2x. Free and local.",
    category: "image",
    icon: "square-dashed",
    keywords: ["placeholder image", "dummy image", "mockup"],
  },
  {
    slug: "url-encoder",
    name: "URL Encoder",
    description: "Encode or decode URL components and full URIs.",
    seoTitle: "URL Encoder Decoder",
    seoDescription:
      "Encode and decode URL query strings or full URIs. Toggle component vs URI mode.",
    category: "develop",
    icon: "link-2",
    keywords: ["url", "encodeURIComponent", "percent encoding"],
  },
  {
    slug: "hash-generator",
    name: "Hash Generator",
    description: "SHA-1, SHA-256, SHA-384, and SHA-512 hashes in the browser.",
    seoTitle: "SHA Hash Generator",
    seoDescription:
      "Generate SHA-1, SHA-256, SHA-384, or SHA-512 hashes with the Web Crypto API. Nothing is sent away.",
    category: "develop",
    icon: "hash",
    keywords: ["sha256", "hash", "checksum", "sha"],
  },
  {
    slug: "stopwatch",
    name: "Stopwatch & Timer",
    description: "A stopwatch with laps and a countdown timer.",
    seoTitle: "Stopwatch and Timer",
    seoDescription:
      "Free online stopwatch with lap times and a countdown timer. Keyboard friendly.",
    category: "time",
    icon: "timer",
    keywords: ["stopwatch", "timer", "countdown", "laps"],
  },
  {
    slug: "age-calculator",
    name: "Age & Date",
    description: "Exact age, next birthday, or the span between two dates.",
    seoTitle: "Age and Date Difference Calculator",
    seoDescription:
      "Calculate exact age from a birth date, or the years, months, and days between two dates.",
    category: "time",
    icon: "cake",
    keywords: ["age", "date difference", "birthday"],
    popular: true,
  },
  {
    slug: "countdown",
    name: "Countdown",
    description: "Live countdown to a date and time, down to the second.",
    seoTitle: "Countdown Timer to Date",
    seoDescription:
      "Count down to a date and time. See remaining days, hours, minutes, and seconds. Runs in the tab.",
    category: "time",
    icon: "hourglass",
    keywords: ["countdown", "days until", "event timer"],
  },
  {
    slug: "world-clock",
    name: "World Clock",
    description: "Live times for cities you keep on a personal board.",
    seoTitle: "World Clock",
    seoDescription:
      "Check live local times in cities around the world. Add or remove cities; saved on this device.",
    category: "time",
    icon: "earth",
    keywords: ["world clock", "cities", "local time"],
  },
  {
    slug: "pomodoro",
    name: "Pomodoro",
    description: "Focus and break intervals with a visible countdown.",
    seoTitle: "Pomodoro Timer",
    seoDescription:
      "A simple Pomodoro focus timer with customizable work and break lengths. Runs in the tab.",
    category: "time",
    icon: "circle-dot",
    keywords: ["pomodoro", "focus", "pomodoro timer"],
  },
] as const satisfies readonly ToolDef[];

export type ToolSlug = (typeof tools)[number]["slug"];

export const toolList: readonly ToolDef[] = tools;

export function getTool(slug: string): ToolDef | undefined {
  return toolList.find((tool) => tool.slug === slug);
}

export function toolsByCategory(id: CategoryId) {
  return toolList.filter((tool) => tool.category === id);
}

export function popularTools() {
  return toolList.filter((tool) => tool.popular);
}

export function searchTools(query: string) {
  const q = query.trim().toLowerCase();
  if (!q) return toolList.slice();
  return toolList.filter((tool) => {
    const hay = [
      tool.name,
      tool.description,
      tool.category,
      ...tool.keywords,
    ]
      .join(" ")
      .toLowerCase();
    return hay.includes(q);
  });
}

export function relatedTools(slug: string, limit = 4) {
  const current = getTool(slug);
  if (!current) return popularTools().slice(0, limit);
  const same = toolList.filter(
    (tool) => tool.category === current.category && tool.slug !== slug,
  );
  const rest = toolList.filter(
    (tool) => tool.category !== current.category && tool.slug !== slug,
  );
  return [...same, ...rest].slice(0, limit);
}

export function getCategory(id: CategoryId) {
  return categories.find((item) => item.id === id);
}
