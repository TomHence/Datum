import { create } from "zustand";
import { persist } from "zustand/middleware";

type ToolPrefs = {
  recents: string[];
  favorites: string[];
  touch: (slug: string) => void;
  toggleFavorite: (slug: string) => void;
  isFavorite: (slug: string) => boolean;
};

export const useToolPrefs = create<ToolPrefs>()(
  persist(
    (set, get) => ({
      recents: [],
      favorites: [],
      touch: (slug) =>
        set({
          recents: [slug, ...get().recents.filter((item) => item !== slug)].slice(0, 8),
        }),
      toggleFavorite: (slug) =>
        set({
          favorites: get().favorites.includes(slug)
            ? get().favorites.filter((item) => item !== slug)
            : [slug, ...get().favorites],
        }),
      isFavorite: (slug) => get().favorites.includes(slug),
    }),
    { name: "datum-tool-prefs" },
  ),
);
