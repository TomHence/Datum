export type LinearUnit = {
  id: string;
  label: string;
  symbol: string;
  factor: number;
};

export type UnitCategoryId =
  | "length"
  | "mass"
  | "temperature"
  | "volume"
  | "area"
  | "speed"
  | "time"
  | "data"
  | "energy"
  | "pressure";

type LinearCategory = {
  id: Exclude<UnitCategoryId, "temperature">;
  label: string;
  kind: "linear";
  units: LinearUnit[];
};

type TemperatureCategory = {
  id: "temperature";
  label: string;
  kind: "temperature";
  units: { id: string; label: string; symbol: string }[];
};

export type UnitCategory = LinearCategory | TemperatureCategory;

const length: LinearCategory = {
  id: "length",
  label: "Length",
  kind: "linear",
  units: [
    { id: "nm", label: "Nanometer", symbol: "nm", factor: 1e-9 },
    { id: "mm", label: "Millimeter", symbol: "mm", factor: 0.001 },
    { id: "cm", label: "Centimeter", symbol: "cm", factor: 0.01 },
    { id: "m", label: "Meter", symbol: "m", factor: 1 },
    { id: "km", label: "Kilometer", symbol: "km", factor: 1000 },
    { id: "in", label: "Inch", symbol: "in", factor: 0.0254 },
    { id: "ft", label: "Foot", symbol: "ft", factor: 0.3048 },
    { id: "yd", label: "Yard", symbol: "yd", factor: 0.9144 },
    { id: "mi", label: "Mile", symbol: "mi", factor: 1609.344 },
    { id: "nmi", label: "Nautical mile", symbol: "nmi", factor: 1852 },
  ],
};

const mass: LinearCategory = {
  id: "mass",
  label: "Mass",
  kind: "linear",
  units: [
    { id: "mg", label: "Milligram", symbol: "mg", factor: 0.000001 },
    { id: "g", label: "Gram", symbol: "g", factor: 0.001 },
    { id: "kg", label: "Kilogram", symbol: "kg", factor: 1 },
    { id: "t", label: "Tonne", symbol: "t", factor: 1000 },
    { id: "oz", label: "Ounce", symbol: "oz", factor: 0.028349523125 },
    { id: "lb", label: "Pound", symbol: "lb", factor: 0.45359237 },
    { id: "st", label: "Stone", symbol: "st", factor: 6.35029318 },
  ],
};

const volume: LinearCategory = {
  id: "volume",
  label: "Volume",
  kind: "linear",
  units: [
    { id: "ml", label: "Milliliter", symbol: "ml", factor: 0.000001 },
    { id: "l", label: "Liter", symbol: "l", factor: 0.001 },
    { id: "m3", label: "Cubic meter", symbol: "m³", factor: 1 },
    { id: "tsp", label: "Teaspoon (US)", symbol: "tsp", factor: 0.00000492892159375 },
    { id: "tbsp", label: "Tablespoon (US)", symbol: "tbsp", factor: 0.00001478676478125 },
    { id: "cup", label: "Cup (US)", symbol: "cup", factor: 0.0002365882365 },
    { id: "floz", label: "Fluid ounce (US)", symbol: "fl oz", factor: 0.0000295735295625 },
    { id: "pt", label: "Pint (US)", symbol: "pt", factor: 0.000473176473 },
    { id: "qt", label: "Quart (US)", symbol: "qt", factor: 0.000946352946 },
    { id: "gal", label: "Gallon (US)", symbol: "gal", factor: 0.003785411784 },
  ],
};

const area: LinearCategory = {
  id: "area",
  label: "Area",
  kind: "linear",
  units: [
    { id: "cm2", label: "Square centimeter", symbol: "cm²", factor: 0.0001 },
    { id: "m2", label: "Square meter", symbol: "m²", factor: 1 },
    { id: "km2", label: "Square kilometer", symbol: "km²", factor: 1_000_000 },
    { id: "ha", label: "Hectare", symbol: "ha", factor: 10_000 },
    { id: "in2", label: "Square inch", symbol: "in²", factor: 0.00064516 },
    { id: "ft2", label: "Square foot", symbol: "ft²", factor: 0.09290304 },
    { id: "yd2", label: "Square yard", symbol: "yd²", factor: 0.83612736 },
    { id: "ac", label: "Acre", symbol: "ac", factor: 4046.8564224 },
    { id: "mi2", label: "Square mile", symbol: "mi²", factor: 2_589_988.110336 },
  ],
};

const speed: LinearCategory = {
  id: "speed",
  label: "Speed",
  kind: "linear",
  units: [
    { id: "mps", label: "Meters per second", symbol: "m/s", factor: 1 },
    { id: "kph", label: "Kilometers per hour", symbol: "km/h", factor: 1000 / 3600 },
    { id: "mph", label: "Miles per hour", symbol: "mph", factor: 1609.344 / 3600 },
    { id: "kn", label: "Knot", symbol: "kn", factor: 1852 / 3600 },
    { id: "fps", label: "Feet per second", symbol: "ft/s", factor: 0.3048 },
  ],
};

const time: LinearCategory = {
  id: "time",
  label: "Time",
  kind: "linear",
  units: [
    { id: "ms", label: "Millisecond", symbol: "ms", factor: 0.001 },
    { id: "s", label: "Second", symbol: "s", factor: 1 },
    { id: "min", label: "Minute", symbol: "min", factor: 60 },
    { id: "h", label: "Hour", symbol: "h", factor: 3600 },
    { id: "d", label: "Day", symbol: "d", factor: 86400 },
    { id: "wk", label: "Week", symbol: "wk", factor: 604800 },
  ],
};

const data: LinearCategory = {
  id: "data",
  label: "Data",
  kind: "linear",
  units: [
    { id: "b", label: "Byte", symbol: "B", factor: 1 },
    { id: "kb", label: "Kilobyte (10³)", symbol: "KB", factor: 1e3 },
    { id: "mb", label: "Megabyte (10⁶)", symbol: "MB", factor: 1e6 },
    { id: "gb", label: "Gigabyte (10⁹)", symbol: "GB", factor: 1e9 },
    { id: "tb", label: "Terabyte (10¹²)", symbol: "TB", factor: 1e12 },
    { id: "kib", label: "Kibibyte (2¹⁰)", symbol: "KiB", factor: 1024 },
    { id: "mib", label: "Mebibyte (2²⁰)", symbol: "MiB", factor: 1024 ** 2 },
    { id: "gib", label: "Gibibyte (2³⁰)", symbol: "GiB", factor: 1024 ** 3 },
    { id: "tib", label: "Tebibyte (2⁴⁰)", symbol: "TiB", factor: 1024 ** 4 },
  ],
};

const energy: LinearCategory = {
  id: "energy",
  label: "Energy",
  kind: "linear",
  units: [
    { id: "j", label: "Joule", symbol: "J", factor: 1 },
    { id: "kj", label: "Kilojoule", symbol: "kJ", factor: 1000 },
    { id: "cal", label: "Calorie", symbol: "cal", factor: 4.184 },
    { id: "kcal", label: "Kilocalorie", symbol: "kcal", factor: 4184 },
    { id: "wh", label: "Watt-hour", symbol: "Wh", factor: 3600 },
    { id: "kwh", label: "Kilowatt-hour", symbol: "kWh", factor: 3_600_000 },
    { id: "btu", label: "BTU", symbol: "BTU", factor: 1055.05585262 },
  ],
};

const pressure: LinearCategory = {
  id: "pressure",
  label: "Pressure",
  kind: "linear",
  units: [
    { id: "pa", label: "Pascal", symbol: "Pa", factor: 1 },
    { id: "kpa", label: "Kilopascal", symbol: "kPa", factor: 1000 },
    { id: "bar", label: "Bar", symbol: "bar", factor: 100000 },
    { id: "psi", label: "PSI", symbol: "psi", factor: 6894.757293168 },
    { id: "atm", label: "Atmosphere", symbol: "atm", factor: 101325 },
    { id: "mmhg", label: "mmHg", symbol: "mmHg", factor: 133.322387415 },
  ],
};

const temperature: TemperatureCategory = {
  id: "temperature",
  label: "Temperature",
  kind: "temperature",
  units: [
    { id: "c", label: "Celsius", symbol: "°C" },
    { id: "f", label: "Fahrenheit", symbol: "°F" },
    { id: "k", label: "Kelvin", symbol: "K" },
  ],
};

export const unitCategories: UnitCategory[] = [
  length,
  mass,
  temperature,
  volume,
  area,
  speed,
  time,
  data,
  energy,
  pressure,
];

export function toKelvin(value: number, from: string) {
  if (from === "c") return value + 273.15;
  if (from === "f") return ((value - 32) * 5) / 9 + 273.15;
  return value;
}

export function fromKelvin(kelvin: number, to: string) {
  if (to === "c") return kelvin - 273.15;
  if (to === "f") return ((kelvin - 273.15) * 9) / 5 + 32;
  return kelvin;
}

export function convertLinear(
  value: number,
  from: LinearUnit,
  to: LinearUnit,
) {
  return (value * from.factor) / to.factor;
}
