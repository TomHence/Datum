import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2 text-fg", className)}>
      <svg
        viewBox="0 0 24 24"
        className="size-6"
        fill="none"
        aria-hidden="true"
      >
        <rect
          x="3.25"
          y="3.25"
          width="17.5"
          height="17.5"
          stroke="currentColor"
          strokeWidth="1.5"
        />
        <circle cx="12" cy="12" r="1.6" fill="currentColor" />
        <path
          d="M12 3.25v3.5M12 17.25v3.5M3.25 12h3.5M17.25 12h3.5"
          stroke="currentColor"
          strokeWidth="1.5"
        />
      </svg>
      <span className="font-display text-lg font-semibold tracking-tight">
        Datum
      </span>
    </span>
  );
}
