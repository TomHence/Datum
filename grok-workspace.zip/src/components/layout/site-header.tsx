import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Menu, Search } from "lucide-react";
import { categories } from "@/lib/catalog";
import { Logo } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { SearchPalette } from "@/components/layout/search-palette";

export function SiteHeader() {
  const [searchOpen, setSearchOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-bg/90 backdrop-blur-sm">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
        <Link to="/" className="shrink-0" aria-label="Datum home">
          <Logo />
        </Link>
        <nav className="hidden items-center gap-6 text-sm font-medium md:flex">
          <Link to="/tools" className="text-fg hover:text-accent">
            All tools
          </Link>
          <Link to="/about" className="text-muted hover:text-fg">
            About
          </Link>
          <Link to="/privacy" className="text-muted hover:text-fg">
            Privacy
          </Link>
        </nav>
        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="secondary"
            className="hidden min-w-48 justify-between gap-3 px-3 text-muted md:inline-flex"
            onClick={() => setSearchOpen(true)}
          >
            <span className="inline-flex items-center gap-2">
              <Search className="size-4" />
              Search
            </span>
            <kbd className="drawing-label rounded-sm bg-bg px-1.5 py-0.5">⌘K</kbd>
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="md:hidden"
            aria-label="Search tools"
            onClick={() => setSearchOpen(true)}
          >
            <Search className="size-5" />
          </Button>
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="md:hidden"
                aria-label="Open menu"
              >
                <Menu className="size-5" />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <SheetTitle className="pr-10">Menu</SheetTitle>
              <div className="mt-6 flex flex-col gap-5">
                <Link
                  to="/tools"
                  className="text-base font-medium"
                  onClick={() => setMenuOpen(false)}
                >
                  All tools
                </Link>
                <Link
                  to="/about"
                  className="text-base text-muted"
                  onClick={() => setMenuOpen(false)}
                >
                  About
                </Link>
                <Link
                  to="/privacy"
                  className="text-base text-muted"
                  onClick={() => setMenuOpen(false)}
                >
                  Privacy
                </Link>
                <div className="grid gap-3">
                  {categories.map((category) => (
                    <a
                      key={category.id}
                      href={`/tools#${category.id}`}
                      className="flex items-baseline justify-between text-sm"
                      onClick={() => setMenuOpen(false)}
                    >
                      <span>{category.label}</span>
                      <span className="drawing-label">{category.index}</span>
                    </a>
                  ))}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
      <SearchPalette open={searchOpen} onOpenChange={setSearchOpen} />
    </header>
  );
}
