import { useEffect, useRef } from "react";
import {
  adsAreLive,
  adsConfig,
  adsShowPreview,
  type AdSlotId,
} from "@/lib/ads";
import { cn } from "@/lib/utils";

declare global {
  interface Window {
    adsbygoogle?: unknown[];
  }
}

const sizes: Record<AdSlotId, string> = {
  header: "min-h-20",
  inContent: "min-h-20",
  sidebar: "min-h-64",
  toolBottom: "min-h-20",
  footer: "min-h-20",
};

export function AdSlot({
  slot,
  className,
}: {
  slot: AdSlotId;
  className?: string;
}) {
  const pushed = useRef(false);

  useEffect(() => {
    if (!adsAreLive() || pushed.current) return;
    try {
      window.adsbygoogle = window.adsbygoogle || [];
      window.adsbygoogle.push({});
      pushed.current = true;
    } catch {
      // Ad network not ready; layout still holds the slot.
    }
  }, []);

  if (!adsConfig.enabled) return null;

  if (adsShowPreview()) {
    return (
      <aside
        className={cn(
          "flex items-center justify-center rounded-lg bg-bg shadow-card",
          sizes[slot],
          className,
        )}
        aria-label="Advertisement placement"
      >
        <p className="drawing-label">Advertisement</p>
      </aside>
    );
  }

  return (
    <aside className={cn("overflow-hidden", className)} aria-label="Advertisement">
      <ins
        className="adsbygoogle block"
        style={{ display: "block" }}
        data-ad-client={adsConfig.adsenseClient}
        data-ad-slot={adsConfig.slots[slot]}
        data-ad-format="auto"
        data-full-width-responsive="true"
      />
    </aside>
  );
}
