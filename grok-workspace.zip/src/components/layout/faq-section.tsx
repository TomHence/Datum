import { siteFaq } from "@/lib/faq";

export function FaqSection() {
  return (
    <section className="flex flex-col gap-6">
      <div>
        <p className="drawing-label">Notes</p>
        <h2 className="font-display text-2xl font-semibold">Questions, answered</h2>
      </div>
      <div className="grid gap-px overflow-hidden rounded-xl bg-border shadow-card sm:grid-cols-2">
        {siteFaq.map((item) => (
          <article key={item.question} className="flex flex-col gap-2 bg-surface p-5">
            <h3 className="font-medium tracking-tight">{item.question}</h3>
            <p className="text-sm text-muted">{item.answer}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
