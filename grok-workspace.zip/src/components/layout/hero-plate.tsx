import { Link } from "@tanstack/react-router";
import { popularTools, toolList } from "@/lib/catalog";

export function HeroPlate() {
  const featured = popularTools().slice(0, 8);

  return (
    <aside className="sheet-frame hidden min-w-0 flex-col lg:flex">
      <div className="flex items-start justify-between gap-4 border-b border-border px-4 py-3">
        <div>
          <p className="drawing-label">Datum studio</p>
          <p className="font-display text-lg font-semibold tracking-tight">Sheet A1</p>
        </div>
        <div className="text-right">
          <p className="drawing-label">Rev 01</p>
          <p className="drawing-label text-fg">{toolList.length} tools</p>
        </div>
      </div>
      <ol className="flex flex-1 flex-col">
        {featured.map((tool, index) => (
          <li key={tool.slug} className="border-b border-border last:border-b-0">
            <Link
              to="/tools/$slug"
              params={{ slug: tool.slug }}
              className="flex items-baseline justify-between gap-3 px-4 py-3 hover:bg-bg"
            >
              <span className="flex min-w-0 items-baseline gap-3">
                <span className="drawing-label w-6 shrink-0">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <span className="truncate font-medium">{tool.name}</span>
              </span>
              <span className="drawing-label shrink-0">{tool.category}</span>
            </Link>
          </li>
        ))}
      </ol>
      <div className="flex items-center justify-between gap-3 border-t border-border px-4 py-3">
        <span className="scale-bar" aria-hidden="true" />
        <p className="drawing-label">Scale 1:1</p>
      </div>
    </aside>
  );
}
