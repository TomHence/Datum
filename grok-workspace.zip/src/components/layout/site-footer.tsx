import { Link } from "@tanstack/react-router";
import { categories, toolsByCategory, toolList } from "@/lib/catalog";
import { SITE } from "@/lib/site";
import { AdSlot } from "@/components/layout/ad-slot";
import { Logo } from "@/components/logo";

export function SiteFooter() {
  return (
    <footer className="mt-16 border-t border-border bg-surface">
      <div className="mx-auto flex max-w-6xl flex-col gap-10 px-4 py-10">
        <AdSlot slot="footer" />
        <div className="grid gap-10 md:grid-cols-[1.2fr_2fr]">
          <div className="flex flex-col gap-3">
            <Logo />
            <p className="max-w-sm text-sm text-muted">{SITE.tagline}</p>
            <p className="max-w-sm text-sm text-muted">
              Every tool runs on your device. There is no account, and we do not
              upload what you type.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-6 sm:grid-cols-3">
            {categories.map((category) => (
              <div key={category.id} className="flex flex-col gap-2">
                <p className="drawing-label">{category.index} {category.label}</p>
                {toolsByCategory(category.id)
                  .slice(0, 5)
                  .map((tool) => (
                    <Link
                      key={tool.slug}
                      to="/tools/$slug"
                      params={{ slug: tool.slug }}
                      className="text-sm text-muted hover:text-fg"
                    >
                      {tool.name}
                    </Link>
                  ))}
              </div>
            ))}
          </div>
        </div>
        <div className="title-block grid gap-3 sm:grid-cols-4">
          <div>
            <p className="drawing-label">Project</p>
            <p className="text-sm font-medium">{SITE.name}</p>
          </div>
          <div>
            <p className="drawing-label">Instruments</p>
            <p className="text-sm font-medium tabular-nums">{toolList.length}</p>
          </div>
          <div>
            <p className="drawing-label">Scale</p>
            <p className="text-sm font-medium">1 : 1</p>
          </div>
          <div>
            <p className="drawing-label">Sheet</p>
            <p className="text-sm font-medium">Index / Public</p>
          </div>
        </div>
        <div className="flex flex-col justify-between gap-3 border-t border-border pt-6 text-sm text-muted sm:flex-row">
          <p>Free to use. Built for everyday work.</p>
          <div className="flex gap-4">
            <Link to="/about" className="hover:text-fg">
              About
            </Link>
            <Link to="/privacy" className="hover:text-fg">
              Privacy
            </Link>
            <Link to="/tools" className="hover:text-fg">
              All tools
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
