import { useEffect, useMemo, useState } from "react";
import { Command } from "cmdk";
import { useNavigate } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { categories, searchTools } from "@/lib/catalog";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { ToolIcon } from "@/components/tool-icon";

export function SearchPalette({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const results = useMemo(() => searchTools(query), [query]);

  useEffect(() => {
    if (!open) setQuery("");
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="top-[18%] translate-y-0 p-0 sm:max-w-xl">
        <DialogTitle className="sr-only">Search tools</DialogTitle>
        <Command label="Search tools" className="flex flex-col">
          <div className="flex items-center gap-2 border-b border-border px-3">
            <Search className="size-4 text-muted" />
            <Command.Input
              value={query}
              onValueChange={setQuery}
              placeholder="Search calculators, converters, generators…"
              className="h-14 w-full bg-transparent text-base outline-none placeholder:text-subtle"
            />
          </div>
          <Command.List className="max-h-80 overflow-y-auto p-2">
            <Command.Empty className="px-3 py-8 text-center text-sm text-muted">
              No tools match that search.
            </Command.Empty>
            {categories.map((category) => {
              const items = results.filter((tool) => tool.category === category.id);
              if (!items.length) return null;
              return (
                <Command.Group
                  key={category.id}
                  heading={category.label}
                  className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-2 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:tracking-wide [&_[cmdk-group-heading]]:text-muted [&_[cmdk-group-heading]]:uppercase"
                >
                  {items.map((tool) => (
                    <Command.Item
                      key={tool.slug}
                      value={`${tool.name} ${tool.keywords.join(" ")}`}
                      onSelect={() => {
                        onOpenChange(false);
                        void navigate({
                          to: "/tools/$slug",
                          params: { slug: tool.slug },
                        });
                      }}
                      className="flex cursor-pointer items-center gap-3 rounded-md px-2 py-2 text-sm data-[selected=true]:bg-bg"
                    >
                      <span className="flex size-9 items-center justify-center rounded-sm bg-bg text-fg">
                        <ToolIcon name={tool.icon} />
                      </span>
                      <span className="flex min-w-0 flex-col">
                        <span className="font-medium">{tool.name}</span>
                        <span className="truncate text-xs text-muted">
                          {tool.description}
                        </span>
                      </span>
                    </Command.Item>
                  ))}
                </Command.Group>
              );
            })}
          </Command.List>
        </Command>
      </DialogContent>
    </Dialog>
  );
}
