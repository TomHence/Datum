import { Link } from "@tanstack/react-router";
import type { ToolDef } from "@/lib/catalog";
import { ToolIcon } from "@/components/tool-icon";
import { cn } from "@/lib/utils";

export function ToolCard({
  tool,
  className,
}: {
  tool: ToolDef;
  className?: string;
}) {
  return (
    <Link
      to="/tools/$slug"
      params={{ slug: tool.slug }}
      className={cn(
        "group flex flex-col gap-3 rounded-xl bg-surface p-4 shadow-card transition-[box-shadow,transform] duration-150 ease-[cubic-bezier(0.22,1,0.36,1)] hover:shadow-card-hover",
        className,
      )}
    >
      <span className="flex items-start justify-between gap-3">
        <span className="flex size-10 items-center justify-center rounded-sm bg-bg text-fg">
          <ToolIcon name={tool.icon} />
        </span>
        {tool.popular ? (
          <span className="drawing-label">Frequent</span>
        ) : null}
      </span>
      <span className="flex flex-col gap-1">
        <span className="font-medium tracking-tight">{tool.name}</span>
        <span className="text-sm text-muted">{tool.description}</span>
      </span>
    </Link>
  );
}
