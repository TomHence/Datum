import { useEffect, useMemo, useRef, useState } from "react";
import { formatFixed, parseNumeric } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Field,
  ResultPanel,
  ResultRow,
  ToolForm,
  ToolPanel,
} from "@/components/tools/shared";
import { ZONES, fmtZone } from "@/components/tools/convert-small";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

function pad(n: number, size = 2) {
  return String(n).padStart(size, "0");
}

function formatMs(ms: number) {
  const total = Math.max(0, Math.floor(ms));
  const minutes = Math.floor(total / 60000);
  const seconds = Math.floor((total % 60000) / 1000);
  const tenths = Math.floor((total % 1000) / 10);
  return `${pad(minutes)}:${pad(seconds)}.${pad(tenths)}`;
}

export function StopwatchTool() {
  const [mode, setMode] = useState("stopwatch");
  const [running, setRunning] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [laps, setLaps] = useState<number[]>([]);
  const started = useRef<number | null>(null);
  const base = useRef(0);
  const [mins, setMins] = useState("5");
  const [secs, setSecs] = useState("0");
  const [remain, setRemain] = useState(5 * 60 * 1000);

  useEffect(() => {
    if (!running) return;
    const id = window.setInterval(() => {
      if (mode === "stopwatch" && started.current !== null) {
        setElapsed(base.current + (performance.now() - started.current));
      }
      if (mode === "timer") {
        setRemain((prev) => {
          const next = prev - 100;
          if (next <= 0) {
            setRunning(false);
            return 0;
          }
          return next;
        });
      }
    }, 80);
    return () => window.clearInterval(id);
  }, [running, mode]);

  const startStopwatch = () => {
    started.current = performance.now();
    setRunning(true);
  };
  const pauseStopwatch = () => {
    if (started.current !== null) base.current += performance.now() - started.current;
    started.current = null;
    setRunning(false);
  };

  return (
    <ToolPanel>
      <Tabs value={mode} onValueChange={(v) => { setMode(v); setRunning(false); }}>
        <TabsList>
          <TabsTrigger value="stopwatch">Stopwatch</TabsTrigger>
          <TabsTrigger value="timer">Timer</TabsTrigger>
        </TabsList>
        <TabsContent value="stopwatch" className="flex flex-col gap-4">
          <p className="font-display text-center text-4xl font-semibold tabular-nums">
            {formatMs(elapsed)}
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            {running ? (
              <Button type="button" onClick={pauseStopwatch}>Pause</Button>
            ) : (
              <Button type="button" onClick={startStopwatch}>Start</Button>
            )}
            <Button
              type="button"
              variant="secondary"
              onClick={() => setLaps((prev) => [elapsed, ...prev].slice(0, 20))}
              disabled={elapsed === 0}
            >
              Lap
            </Button>
            <Button
              type="button"
              variant="ghost"
              onClick={() => {
                setRunning(false);
                setElapsed(0);
                setLaps([]);
                started.current = null;
                base.current = 0;
              }}
            >
              Reset
            </Button>
          </div>
          {laps.length ? (
            <ol className="space-y-1 text-sm tabular-nums text-muted">
              {laps.map((lap, i) => (
                <li key={`${lap}-${i}`}>
                  Lap {laps.length - i}: {formatMs(lap)}
                </li>
              ))}
            </ol>
          ) : null}
        </TabsContent>
        <TabsContent value="timer" className="flex flex-col gap-4">
          <ToolForm>
            <Field label="Minutes" htmlFor="tm-m">
              <Input id="tm-m" inputMode="numeric" value={mins} onChange={(e) => setMins(e.target.value)} />
            </Field>
            <Field label="Seconds" htmlFor="tm-s">
              <Input id="tm-s" inputMode="numeric" value={secs} onChange={(e) => setSecs(e.target.value)} />
            </Field>
          </ToolForm>
          <p className="font-display text-center text-4xl font-semibold tabular-nums">
            {formatMs(remain)}
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            {running ? (
              <Button type="button" onClick={() => setRunning(false)}>Pause</Button>
            ) : (
              <Button
                type="button"
                onClick={() => {
                  if (remain <= 0) {
                    const m = parseNumeric(mins) ?? 0;
                    const s = parseNumeric(secs) ?? 0;
                    setRemain((m * 60 + s) * 1000);
                  }
                  setRunning(true);
                }}
              >
                Start
              </Button>
            )}
            <Button
              type="button"
              variant="ghost"
              onClick={() => {
                const m = parseNumeric(mins) ?? 0;
                const s = parseNumeric(secs) ?? 0;
                setRunning(false);
                setRemain((m * 60 + s) * 1000);
              }}
            >
              Reset
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </ToolPanel>
  );
}

function diffYMD(from: Date, to: Date) {
  let years = to.getFullYear() - from.getFullYear();
  let months = to.getMonth() - from.getMonth();
  let days = to.getDate() - from.getDate();
  if (days < 0) {
    months -= 1;
    const prev = new Date(to.getFullYear(), to.getMonth(), 0).getDate();
    days += prev;
  }
  if (months < 0) {
    years -= 1;
    months += 12;
  }
  return { years, months, days };
}

export function AgeCalculatorTool() {
  const today = new Date();
  const iso = (d: Date) => d.toISOString().slice(0, 10);
  const [birth, setBirth] = useState("1994-06-15");
  const [other, setOther] = useState(iso(today));

  const start = useMemo(() => new Date(`${birth}T00:00:00`), [birth]);
  const end = useMemo(() => new Date(`${other}T00:00:00`), [other]);
  const valid = !Number.isNaN(start.getTime()) && !Number.isNaN(end.getTime()) && end >= start;
  const span = valid ? diffYMD(start, end) : null;
  const totalDays = valid ? Math.round((end.getTime() - start.getTime()) / 86400000) : null;

  return (
    <ToolPanel className="flex flex-col gap-4">
      <ToolForm>
        <Field label="From date (birth date)" htmlFor="age-from">
          <Input id="age-from" type="date" value={birth} onChange={(e) => setBirth(e.target.value)} />
        </Field>
        <Field label="To date" htmlFor="age-to">
          <Input id="age-to" type="date" value={other} onChange={(e) => setOther(e.target.value)} />
        </Field>
      </ToolForm>
      <ResultPanel>
        <ResultRow label="Years" value={span ? String(span.years) : "—"} large />
        <ResultRow label="Months" value={span ? String(span.months) : "—"} />
        <ResultRow label="Days" value={span ? String(span.days) : "—"} />
        <ResultRow label="Total days" value={totalDays !== null ? String(totalDays) : "—"} copy />
      </ResultPanel>
    </ToolPanel>
  );
}

const DEFAULT_CITIES = ["America/New_York", "Europe/London", "Asia/Dubai", "Asia/Tokyo"];

export function WorldClockTool() {
  const [now, setNow] = useState(() => new Date());
  const [cities, setCities] = useState<string[]>(DEFAULT_CITIES);
  const [add, setAdd] = useState("Australia/Sydney");

  useEffect(() => {
    const stored = localStorage.getItem("datum-world-clock");
    if (stored) {
      try {
        const parsed = JSON.parse(stored) as string[];
        if (Array.isArray(parsed) && parsed.length) setCities(parsed);
      } catch {
        /* ignore */
      }
    }
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    localStorage.setItem("datum-world-clock", JSON.stringify(cities));
  }, [cities]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <div className="flex flex-col gap-2 sm:flex-row">
        <Select value={add} onValueChange={setAdd}>
          <SelectTrigger aria-label="Add city">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {ZONES.map((zone) => (
              <SelectItem key={zone.id} value={zone.id}>
                {zone.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button
          type="button"
          variant="secondary"
          onClick={() => setCities((prev) => (prev.includes(add) ? prev : [...prev, add]))}
        >
          Add city
        </Button>
      </div>
      <div className="grid gap-2">
        {cities.map((id) => {
          const label = ZONES.find((z) => z.id === id)?.label ?? id;
          return (
            <div key={id} className="flex items-center justify-between gap-3 rounded-sm bg-bg px-4 py-3">
              <div>
                <p className="font-medium">{label}</p>
                <p className="text-sm text-muted">{id}</p>
              </div>
              <div className="flex items-center gap-3">
                <p className="font-display text-lg font-semibold tabular-nums">{fmtZone(now, id)}</p>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setCities((prev) => prev.filter((c) => c !== id))}
                >
                  Remove
                </Button>
              </div>
            </div>
          );
        })}
      </div>
    </ToolPanel>
  );
}

function beep() {
  const ctx = new AudioContext();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.frequency.value = 880;
  gain.gain.value = 0.05;
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start();
  osc.stop(ctx.currentTime + 0.25);
}

export function PomodoroTool() {
  const [work, setWork] = useState("25");
  const [brk, setBrk] = useState("5");
  const [phase, setPhase] = useState<"focus" | "break">("focus");
  const [remain, setRemain] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const [sessions, setSessions] = useState(0);

  useEffect(() => {
    if (!running) return;
    const id = window.setInterval(() => {
      setRemain((prev) => {
        if (prev <= 1) {
          beep();
          if (phase === "focus") {
            setSessions((n) => n + 1);
            setPhase("break");
            return (parseNumeric(brk) ?? 5) * 60;
          }
          setPhase("focus");
          return (parseNumeric(work) ?? 25) * 60;
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [running, phase, brk, work]);

  const mm = Math.floor(remain / 60);
  const ss = remain % 60;

  return (
    <ToolPanel className="flex flex-col gap-4">
      <ToolForm>
        <Field label="Focus minutes" htmlFor="po-w">
          <Input id="po-w" inputMode="numeric" value={work} onChange={(e) => setWork(e.target.value)} />
        </Field>
        <Field label="Break minutes" htmlFor="po-b">
          <Input id="po-b" inputMode="numeric" value={brk} onChange={(e) => setBrk(e.target.value)} />
        </Field>
      </ToolForm>
      <p className="drawing-label text-center">{phase === "focus" ? "Focus" : "Break"}</p>
      <p className="font-display text-center text-5xl font-semibold tabular-nums">
        {pad(mm)}:{pad(ss)}
      </p>
      <div className="flex flex-wrap justify-center gap-2">
        <Button type="button" onClick={() => setRunning((v) => !v)}>
          {running ? "Pause" : "Start"}
        </Button>
        <Button
          type="button"
          variant="ghost"
          onClick={() => {
            setRunning(false);
            setPhase("focus");
            setRemain((parseNumeric(work) ?? 25) * 60);
          }}
        >
          Reset
        </Button>
      </div>
      <ResultPanel>
        <ResultRow label="Completed focus sessions" value={String(sessions)} />
        <p className="pt-2 text-sm text-muted">
          Target ratio is typically {formatFixed((parseNumeric(work) ?? 25) / ((parseNumeric(brk) ?? 5) || 1), 1)}
          :1 focus to break.
        </p>
      </ResultPanel>
    </ToolPanel>
  );
}

function splitDuration(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  return { days, hours, minutes, seconds, past: ms < 0 };
}

export function CountdownTool() {
  const [target, setTarget] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    d.setMinutes(0, 0, 0);
    const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
    return local.toISOString().slice(0, 16);
  });
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(id);
  }, []);

  const parts = useMemo(() => {
    const t = new Date(target).getTime();
    if (!Number.isFinite(t)) return null;
    return splitDuration(t - now);
  }, [target, now]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <Field label="Date and time" htmlFor="cd-t">
        <Input
          id="cd-t"
          type="datetime-local"
          value={target}
          onChange={(e) => setTarget(e.target.value)}
        />
      </Field>
      {parts ? (
        <>
          <p className="drawing-label text-center">
            {parts.past ? "Elapsed" : "Remaining"}
          </p>
          <div className="grid grid-cols-4 gap-2 text-center">
            {[
              { label: "Days", value: parts.days },
              { label: "Hours", value: parts.hours },
              { label: "Minutes", value: parts.minutes },
              { label: "Seconds", value: parts.seconds },
            ].map((item) => (
              <div key={item.label} className="rounded-sm bg-bg px-2 py-4">
                <p className="font-display text-2xl font-semibold tabular-nums">
                  {item.value}
                </p>
                <p className="drawing-label mt-1">{item.label}</p>
              </div>
            ))}
          </div>
        </>
      ) : (
        <p className="text-sm text-muted">Enter a valid date.</p>
      )}
    </ToolPanel>
  );
}
