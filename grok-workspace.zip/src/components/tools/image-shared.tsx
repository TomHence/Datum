import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { fileToImage } from "@/lib/image";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Field } from "@/components/tools/shared";

export type Source = {
  file: File;
  img: HTMLImageElement;
  url: string;
};

export function useSource() {
  const [source, setSource] = useState<Source | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    return () => {
      if (source?.url) URL.revokeObjectURL(source.url);
    };
  }, [source]);

  const onFile = async (file: File | null) => {
    if (!file) return;
    try {
      const next = await fileToImage(file);
      setSource((prev) => {
        if (prev?.url) URL.revokeObjectURL(prev.url);
        return { file, img: next.img, url: next.url };
      });
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not read that image.");
    }
  };

  return { source, error, onFile, setError };
}

export function useBlobUrl() {
  const ref = useRef<string | null>(null);
  const [url, setUrl] = useState<string | null>(null);
  const [size, setSize] = useState<number | null>(null);

  const setBlob = useCallback((blob: Blob | null) => {
    if (ref.current) URL.revokeObjectURL(ref.current);
    if (!blob) {
      ref.current = null;
      setUrl(null);
      setSize(null);
      return;
    }
    const next = URL.createObjectURL(blob);
    ref.current = next;
    setUrl(next);
    setSize(blob.size);
  }, []);

  useEffect(
    () => () => {
      if (ref.current) URL.revokeObjectURL(ref.current);
    },
    [],
  );
  return { url, size, setBlob };
}

export function FilePick({
  onFile,
  hint = "Drop a JPEG, PNG, WebP, GIF, or SVG. Stays on this device.",
  label = "Image",
  inputId,
}: {
  onFile: (file: File | null) => void;
  hint?: string;
  label?: string;
  inputId?: string;
}) {
  const [over, setOver] = useState(false);
  const id = inputId ?? `pick-${label.replace(/\s+/g, "-").toLowerCase()}`;

  return (
    <Field label={label} hint={hint} htmlFor={id}>
      <label
        htmlFor={id}
        className={cn(
          "flex min-h-28 cursor-pointer flex-col items-center justify-center gap-2 rounded-xl bg-bg px-4 py-5 text-center shadow-card transition-colors duration-150",
          over && "bg-accent-soft text-fg",
        )}
        onDragOver={(e) => {
          e.preventDefault();
          setOver(true);
        }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setOver(false);
          onFile(e.dataTransfer.files[0] ?? null);
        }}
      >
        <span className="text-sm text-muted">Drop an image here, or browse</span>
        <Input
          id={id}
          type="file"
          accept="image/*,image/svg+xml"
          className="max-w-xs"
          onChange={(e) => onFile(e.target.files?.[0] ?? null)}
        />
      </label>
    </Field>
  );
}

export function Preview({ src, alt }: { src: string; alt: string }) {
  return (
    <img
      src={src}
      alt={alt}
      className="img-check max-h-72 w-full rounded-sm object-contain"
    />
  );
}

export function DownloadLink({ href, name, label = "Download" }: { href: string; name: string; label?: string }) {
  return (
    <Button asChild>
      <a href={href} download={name}>
        {label}
      </a>
    </Button>
  );
}

export function Choice({
  options,
  value,
  onChange,
}: {
  options: { id: string; label: string }[];
  value: string;
  onChange: (id: string) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((item) => (
        <Button
          key={item.id}
          type="button"
          size="sm"
          variant={value === item.id ? "default" : "secondary"}
          onClick={() => onChange(item.id)}
        >
          {item.label}
        </Button>
      ))}
    </div>
  );
}

export function ColorField({
  id,
  label,
  value,
  onChange,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <Field label={label} htmlFor={id}>
      <div className="flex items-center gap-2">
        <input
          id={id}
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="size-11 shrink-0 rounded-md bg-elevated shadow-card"
        />
        <Input value={value} onChange={(e) => onChange(e.target.value)} className="font-mono" />
      </div>
    </Field>
  );
}

export function SwitchRow({
  id,
  label,
  checked,
  onCheckedChange,
}: {
  id: string;
  label: string;
  checked: boolean;
  onCheckedChange: (next: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <Label htmlFor={id}>{label}</Label>
      <Switch id={id} checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  );
}

export function CompareFrame({
  before,
  after,
}: {
  before: string;
  after: string;
}) {
  const [mode, setMode] = useState("after");
  const [pct, setPct] = useState(50);
  return (
    <div className="flex flex-col gap-3">
      <Choice
        value={mode}
        onChange={setMode}
        options={[
          { id: "after", label: "Result" },
          { id: "before", label: "Original" },
          { id: "split", label: "Side by side" },
          { id: "wipe", label: "Wipe" },
        ]}
      />
      {mode === "split" ? (
        <div className="grid gap-2 sm:grid-cols-2">
          <figure className="flex flex-col gap-1">
            <Preview src={before} alt="Original" />
            <figcaption className="drawing-label">Original</figcaption>
          </figure>
          <figure className="flex flex-col gap-1">
            <Preview src={after} alt="Result" />
            <figcaption className="drawing-label">Result</figcaption>
          </figure>
        </div>
      ) : mode === "wipe" ? (
        <div className="relative overflow-hidden rounded-sm bg-bg">
          <img src={after} alt="Result" className="img-check block w-full" />
          <div
            className="absolute inset-0 overflow-hidden"
            style={{ clipPath: `inset(0 ${100 - pct}% 0 0)` }}
          >
            <img src={before} alt="Original" className="img-check absolute inset-0 size-full object-contain" />
          </div>
          <div
            className="pointer-events-none absolute inset-y-0 w-0.5 bg-accent"
            style={{ left: `${pct}%` }}
          />
          <input
            type="range"
            min={4}
            max={96}
            value={pct}
            aria-label="Compare wipe"
            className="absolute inset-0 cursor-ew-resize opacity-0"
            onChange={(e) => setPct(Number(e.target.value))}
          />
        </div>
      ) : (
        <Preview src={mode === "before" ? before : after} alt={mode === "before" ? "Original" : "Result"} />
      )}
    </div>
  );
}

export function Advanced({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="flex flex-col gap-4">
      <Button type="button" variant="ghost" className="self-start px-0" onClick={() => setOpen((v) => !v)}>
        {open ? "Hide advanced" : "Show advanced"}
      </Button>
      {open ? children : null}
    </div>
  );
}
