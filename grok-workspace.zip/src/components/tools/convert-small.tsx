import { useMemo, useState } from "react";
import { formatNumber, parseNumeric } from "@/lib/format";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Field,
  ResultPanel,
  ResultRow,
  ToolForm,
  ToolPanel,
} from "@/components/tools/shared";

const ZONES = [
  { id: "UTC", label: "UTC" },
  { id: "America/New_York", label: "New York" },
  { id: "America/Chicago", label: "Chicago" },
  { id: "America/Denver", label: "Denver" },
  { id: "America/Los_Angeles", label: "Los Angeles" },
  { id: "America/Sao_Paulo", label: "São Paulo" },
  { id: "Europe/London", label: "London" },
  { id: "Europe/Paris", label: "Paris" },
  { id: "Europe/Berlin", label: "Berlin" },
  { id: "Africa/Cairo", label: "Cairo" },
  { id: "Africa/Johannesburg", label: "Johannesburg" },
  { id: "Asia/Dubai", label: "Dubai" },
  { id: "Asia/Kolkata", label: "Mumbai" },
  { id: "Asia/Singapore", label: "Singapore" },
  { id: "Asia/Shanghai", label: "Shanghai" },
  { id: "Asia/Tokyo", label: "Tokyo" },
  { id: "Australia/Sydney", label: "Sydney" },
  { id: "Pacific/Auckland", label: "Auckland" },
] as const;

function fmtZone(date: Date, zone: string) {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: zone,
    dateStyle: "medium",
    timeStyle: "short",
    hour12: false,
  }).format(date);
}

export function UnixTimestampTool() {
  const nowSec = Math.floor(Date.now() / 1000);
  const [raw, setRaw] = useState(String(nowSec));

  const parsed = useMemo(() => {
    const n = parseNumeric(raw);
    if (n === null) return null;
    const ms = Math.abs(n) >= 1e12 ? n : n * 1000;
    const date = new Date(ms);
    if (Number.isNaN(date.getTime())) return null;
    return date;
  }, [raw]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <Field label="Unix time (seconds or milliseconds)" htmlFor="ts-raw">
        <Input id="ts-raw" inputMode="numeric" value={raw} onChange={(e) => setRaw(e.target.value)} />
      </Field>
      <Button type="button" variant="secondary" onClick={() => setRaw(String(Math.floor(Date.now() / 1000)))}>
        Use now
      </Button>
      <ResultPanel>
        <ResultRow label="Local" value={parsed ? parsed.toString() : "Invalid"} copy />
        <ResultRow label="UTC ISO" value={parsed ? parsed.toISOString() : "—"} copy />
        <ResultRow
          label="Seconds"
          value={parsed ? String(Math.floor(parsed.getTime() / 1000)) : "—"}
          copy
        />
        <ResultRow label="Milliseconds" value={parsed ? String(parsed.getTime()) : "—"} copy />
      </ResultPanel>
    </ToolPanel>
  );
}

function toBase(n: number, radix: number) {
  if (!Number.isFinite(n) || !Number.isInteger(n)) return "—";
  return (n >>> 0).toString(radix);
}

export function NumberBaseTool() {
  const [dec, setDec] = useState("255");
  const n = parseNumeric(dec);
  const int = n !== null && Number.isInteger(n) ? n : null;

  return (
    <ToolPanel className="flex flex-col gap-4">
      <Field label="Decimal integer" htmlFor="base-dec">
        <Input id="base-dec" inputMode="numeric" value={dec} onChange={(e) => setDec(e.target.value)} />
      </Field>
      <ResultPanel>
        <ResultRow label="Binary" value={int === null ? "—" : toBase(int, 2)} copy />
        <ResultRow label="Octal" value={int === null ? "—" : toBase(int, 8)} copy />
        <ResultRow label="Decimal" value={int === null ? "—" : String(int)} copy />
        <ResultRow
          label="Hex"
          value={int === null ? "—" : toBase(int, 16).toUpperCase()}
          copy
        />
      </ResultPanel>
      <p className="text-sm text-muted">Paste a hex value with a 0x prefix to convert from hex.</p>
      <Field label="From hex / binary / octal" htmlFor="base-any">
        <Input
          id="base-any"
          placeholder="0xFF or 0b1111 or 0o17"
          onChange={(e) => {
            const v = e.target.value.trim();
            try {
              if (/^0x[0-9a-f]+$/i.test(v)) setDec(String(Number.parseInt(v.slice(2), 16)));
              else if (/^0b[01]+$/i.test(v)) setDec(String(Number.parseInt(v.slice(2), 2)));
              else if (/^0o[0-7]+$/i.test(v)) setDec(String(Number.parseInt(v.slice(2), 8)));
            } catch {
              /* ignore */
            }
          }}
        />
      </Field>
    </ToolPanel>
  );
}

export function TimezoneConverterTool() {
  const [from, setFrom] = useState("America/New_York");
  const [to, setTo] = useState("Asia/Tokyo");
  const [local, setLocal] = useState(() => {
    const d = new Date();
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  });

  const date = useMemo(() => {
    const asLocal = new Date(local);
    return Number.isNaN(asLocal.getTime()) ? null : asLocal;
  }, [local]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <Field label="Date and time" htmlFor="tz-local">
        <Input
          id="tz-local"
          type="datetime-local"
          value={local}
          onChange={(e) => setLocal(e.target.value)}
        />
      </Field>
      <ToolForm>
        <Field label="From zone">
          <Select value={from} onValueChange={setFrom}>
            <SelectTrigger aria-label="From time zone">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {ZONES.map((zone) => (
                <SelectItem key={zone.id} value={zone.id}>
                  {zone.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <Field label="To zone">
          <Select value={to} onValueChange={setTo}>
            <SelectTrigger aria-label="To time zone">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {ZONES.map((zone) => (
                <SelectItem key={zone.id} value={zone.id}>
                  {zone.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
      </ToolForm>
      <ResultPanel>
        <ResultRow label="Interpreted as local clock" value={date ? date.toString() : "—"} />
        <ResultRow label={ZONES.find((z) => z.id === from)?.label ?? from} value={date ? fmtZone(date, from) : "—"} copy />
        <ResultRow label={ZONES.find((z) => z.id === to)?.label ?? to} value={date ? fmtZone(date, to) : "—"} large copy />
      </ResultPanel>
    </ToolPanel>
  );
}

export { ZONES, fmtZone };
