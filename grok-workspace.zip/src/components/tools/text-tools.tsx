import { useMemo, useState } from "react";
import { copyText } from "@/lib/copy";
import { formatFixed } from "@/lib/format";
import { renderMarkdown } from "@/lib/markdown";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Field,
  ResultPanel,
  ResultRow,
  ToolForm,
  ToolPanel,
  CopyButton,
} from "@/components/tools/shared";

export function WordCounterTool() {
  const [text, setText] = useState("");
  const stats = useMemo(() => {
    const trimmed = text.trim();
    const words = trimmed ? trimmed.split(/\s+/).length : 0;
    const chars = text.length;
    const charsNoSpace = text.replace(/\s/g, "").length;
    const sentences = trimmed ? trimmed.split(/[.!?]+/).filter((s) => s.trim()).length : 0;
    const paragraphs = trimmed ? trimmed.split(/\n\s*\n/).filter(Boolean).length : 0;
    const reading = words / 200;
    const speaking = words / 130;
    return { words, chars, charsNoSpace, sentences, paragraphs, reading, speaking };
  }, [text]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <Field label="Text" htmlFor="wc-text">
        <Textarea
          id="wc-text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Paste or type here…"
          className="min-h-52"
        />
      </Field>
      <ResultPanel>
        <ResultRow label="Words" value={String(stats.words)} large />
        <ResultRow label="Characters" value={String(stats.chars)} />
        <ResultRow label="Characters without spaces" value={String(stats.charsNoSpace)} />
        <ResultRow label="Sentences" value={String(stats.sentences)} />
        <ResultRow label="Paragraphs" value={String(stats.paragraphs)} />
        <ResultRow label="Reading time" value={`${formatFixed(stats.reading, 1)} min`} />
        <ResultRow label="Speaking time" value={`${formatFixed(stats.speaking, 1)} min`} />
      </ResultPanel>
    </ToolPanel>
  );
}

function toTitle(text: string) {
  return text.toLowerCase().replace(/\b\w/g, (ch) => ch.toUpperCase());
}

function toSentence(text: string) {
  return text
    .toLowerCase()
    .replace(/(^\s*\w|[.!?]\s+\w)/g, (ch) => ch.toUpperCase());
}

function toCamel(text: string) {
  const parts = text.trim().split(/[^a-zA-Z0-9]+/).filter(Boolean);
  return parts
    .map((part, i) =>
      i === 0 ? part.toLowerCase() : part.slice(0, 1).toUpperCase() + part.slice(1).toLowerCase(),
    )
    .join("");
}

function toSnake(text: string) {
  return text
    .trim()
    .split(/[^a-zA-Z0-9]+/)
    .filter(Boolean)
    .map((p) => p.toLowerCase())
    .join("_");
}

function toKebab(text: string) {
  return toSnake(text).replaceAll("_", "-");
}

export function CaseConverterTool() {
  const [text, setText] = useState("Datum daily tools");
  const modes = [
    { id: "upper", label: "UPPER", value: text.toUpperCase() },
    { id: "lower", label: "lower", value: text.toLowerCase() },
    { id: "title", label: "Title Case", value: toTitle(text) },
    { id: "sentence", label: "Sentence case", value: toSentence(text) },
    { id: "camel", label: "camelCase", value: toCamel(text) },
    { id: "snake", label: "snake_case", value: toSnake(text) },
    { id: "kebab", label: "kebab-case", value: toKebab(text) },
  ];

  return (
    <ToolPanel className="flex flex-col gap-4">
      <Field label="Text" htmlFor="case-text">
        <Textarea id="case-text" value={text} onChange={(e) => setText(e.target.value)} />
      </Field>
      <div className="grid gap-2">
        {modes.map((mode) => (
          <button
            key={mode.id}
            type="button"
            className="flex items-center justify-between gap-3 rounded-sm bg-bg px-3 py-3 text-left"
            onClick={() => void copyText(mode.value)}
          >
            <span className="text-sm text-muted">{mode.label}</span>
            <span className="truncate font-medium">{mode.value || "—"}</span>
          </button>
        ))}
      </div>
      <p className="text-sm text-muted">Tap a row to copy that version.</p>
    </ToolPanel>
  );
}

const LOREM =
  "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";

function loremWords(count: number) {
  const words = LOREM.replace(/[.,]/g, "").split(" ");
  const out: string[] = [];
  for (let i = 0; i < count; i += 1) out.push(words[i % words.length].toLowerCase());
  out[0] = out[0][0].toUpperCase() + out[0].slice(1);
  return `${out.join(" ")}.`;
}

export function LoremIpsumTool() {
  const [count, setCount] = useState("3");
  const [kind, setKind] = useState<"paragraphs" | "sentences" | "words">("paragraphs");
  const n = Math.max(1, Math.min(50, Number(count) || 1));

  const text = useMemo(() => {
    if (kind === "words") return loremWords(n);
    if (kind === "sentences") return Array.from({ length: n }, () => LOREM.split(". ")[0] + ".").join(" ");
    return Array.from({ length: n }, () => LOREM).join("\n\n");
  }, [kind, n]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <ToolForm>
        <Field label="Count" htmlFor="lorem-n">
          <Input id="lorem-n" inputMode="numeric" value={count} onChange={(e) => setCount(e.target.value)} />
        </Field>
        <Field label="Kind">
          <div className="flex flex-wrap gap-2">
            {(["paragraphs", "sentences", "words"] as const).map((item) => (
              <Button
                key={item}
                type="button"
                variant={kind === item ? "default" : "secondary"}
                size="sm"
                onClick={() => setKind(item)}
              >
                {item}
              </Button>
            ))}
          </div>
        </Field>
      </ToolForm>
      <Textarea readOnly value={text} className="min-h-48" />
      <CopyButton value={text} />
    </ToolPanel>
  );
}

export function MarkdownPreviewTool() {
  const [source, setSource] = useState(
    "# Heading\n\nWrite **Markdown** on the left.\n\n- Lists work\n- `code` too\n\n[Datum](https://example.com)",
  );

  return (
    <ToolPanel>
      <div className="grid gap-4 lg:grid-cols-2">
        <Field label="Markdown" htmlFor="md-src">
          <Textarea
            id="md-src"
            value={source}
            onChange={(e) => setSource(e.target.value)}
            className="min-h-72 font-mono text-sm"
          />
        </Field>
        <div className="flex flex-col gap-2">
          <p className="text-sm font-medium">Preview</p>
          <div className="min-h-72 rounded-sm bg-bg px-4 py-3 [&_h1]:mt-0 [&_p]:mt-2">
            {renderMarkdown(source)}
          </div>
        </div>
      </div>
    </ToolPanel>
  );
}

function cleanText(
  text: string,
  opts: {
    trimLines: boolean;
    collapse: boolean;
    dropEmpty: boolean;
    dropDupes: boolean;
    sortLines: boolean;
  },
) {
  let lines = text.replaceAll("\r\n", "\n").split("\n");
  if (opts.trimLines) lines = lines.map((line) => line.trim());
  if (opts.collapse) {
    lines = lines.map((line) => line.replace(/\s+/g, " "));
  }
  if (opts.dropEmpty) lines = lines.filter((line) => line.length > 0);
  if (opts.dropDupes) {
    const seen = new Set<string>();
    lines = lines.filter((line) => {
      if (seen.has(line)) return false;
      seen.add(line);
      return true;
    });
  }
  if (opts.sortLines) lines = [...lines].sort((a, b) => a.localeCompare(b));
  return lines.join("\n");
}

export function TextCleanerTool() {
  const [text, setText] = useState("  Hello   world  \n\nHello   world\nextra   spaces");
  const [trimLines, setTrimLines] = useState(true);
  const [collapse, setCollapse] = useState(true);
  const [dropEmpty, setDropEmpty] = useState(true);
  const [dropDupes, setDropDupes] = useState(false);
  const [sortLines, setSortLines] = useState(false);

  const cleaned = useMemo(
    () => cleanText(text, { trimLines, collapse, dropEmpty, dropDupes, sortLines }),
    [text, trimLines, collapse, dropEmpty, dropDupes, sortLines],
  );

  const toggles = [
    { id: "trim", label: "Trim each line", on: trimLines, set: setTrimLines },
    { id: "collapse", label: "Collapse spaces", on: collapse, set: setCollapse },
    { id: "empty", label: "Remove empty lines", on: dropEmpty, set: setDropEmpty },
    { id: "dupes", label: "Remove duplicate lines", on: dropDupes, set: setDropDupes },
    { id: "sort", label: "Sort lines", on: sortLines, set: setSortLines },
  ];

  return (
    <ToolPanel className="flex flex-col gap-4">
      <Field label="Text" htmlFor="clean-src">
        <Textarea
          id="clean-src"
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="min-h-40 font-mono text-sm"
        />
      </Field>
      <div className="flex flex-wrap gap-2">
        {toggles.map((item) => (
          <Button
            key={item.id}
            type="button"
            size="sm"
            variant={item.on ? "default" : "secondary"}
            onClick={() => item.set(!item.on)}
          >
            {item.label}
          </Button>
        ))}
      </div>
      <Field label="Cleaned">
        <Textarea readOnly value={cleaned} className="min-h-40 font-mono text-sm" />
      </Field>
      <CopyButton value={cleaned} />
    </ToolPanel>
  );
}

type DiffKind = "same" | "add" | "del";

function lineDiff(a: string, b: string): { kind: DiffKind; text: string }[] {
  const left = a.replaceAll("\r\n", "\n").split("\n");
  const right = b.replaceAll("\r\n", "\n").split("\n");
  const n = Math.min(2000, left.length);
  const m = Math.min(2000, right.length);
  const dp: number[][] = Array.from({ length: n + 1 }, () => Array(m + 1).fill(0));
  for (let i = 1; i <= n; i += 1) {
    for (let j = 1; j <= m; j += 1) {
      dp[i][j] =
        left[i - 1] === right[j - 1]
          ? dp[i - 1][j - 1] + 1
          : Math.max(dp[i - 1][j], dp[i][j - 1]);
    }
  }
  const out: { kind: DiffKind; text: string }[] = [];
  let i = n;
  let j = m;
  while (i > 0 && j > 0) {
    if (left[i - 1] === right[j - 1]) {
      out.push({ kind: "same", text: left[i - 1] });
      i -= 1;
      j -= 1;
    } else if (dp[i - 1][j] >= dp[i][j - 1]) {
      out.push({ kind: "del", text: left[i - 1] });
      i -= 1;
    } else {
      out.push({ kind: "add", text: right[j - 1] });
      j -= 1;
    }
  }
  while (i > 0) {
    out.push({ kind: "del", text: left[i - 1] });
    i -= 1;
  }
  while (j > 0) {
    out.push({ kind: "add", text: right[j - 1] });
    j -= 1;
  }
  return out.reverse();
}

export function TextDiffTool() {
  const [left, setLeft] = useState("alpha\nbeta\ngamma");
  const [right, setRight] = useState("alpha\nbeta\ndelta");
  const rows = useMemo(() => lineDiff(left, right), [left, right]);
  const added = rows.filter((r) => r.kind === "add").length;
  const removed = rows.filter((r) => r.kind === "del").length;

  return (
    <ToolPanel className="flex flex-col gap-4">
      <div className="grid gap-4 lg:grid-cols-2">
        <Field label="Original" htmlFor="diff-a">
          <Textarea
            id="diff-a"
            value={left}
            onChange={(e) => setLeft(e.target.value)}
            className="min-h-48 font-mono text-sm"
          />
        </Field>
        <Field label="Revised" htmlFor="diff-b">
          <Textarea
            id="diff-b"
            value={right}
            onChange={(e) => setRight(e.target.value)}
            className="min-h-48 font-mono text-sm"
          />
        </Field>
      </div>
      <ResultPanel>
        <ResultRow label="Added lines" value={String(added)} />
        <ResultRow label="Removed lines" value={String(removed)} />
      </ResultPanel>
      <div className="max-h-80 overflow-auto rounded-sm bg-bg px-3 py-2 font-mono text-sm">
        {rows.map((row, index) => (
          <p
            key={`${row.kind}-${index}-${row.text.slice(0, 24)}`}
            className={
              row.kind === "add"
                ? "text-ok"
                : row.kind === "del"
                  ? "text-danger"
                  : "text-muted"
            }
          >
            <span className="mr-2 inline-block w-3">{row.kind === "add" ? "+" : row.kind === "del" ? "−" : " "}</span>
            {row.text || " "}
          </p>
        ))}
      </div>
    </ToolPanel>
  );
}
