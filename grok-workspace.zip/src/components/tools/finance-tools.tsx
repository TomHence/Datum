import { useMemo, useState } from "react";
import { formatFixed, parseNumeric } from "@/lib/format";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Field,
  ResultPanel,
  ResultRow,
  ToolForm,
  ToolPanel,
} from "@/components/tools/shared";

function useAmount(initial = "") {
  const [raw, setRaw] = useState(initial);
  const value = parseNumeric(raw);
  return { raw, setRaw, value };
}

export function PercentageTool() {
  const [mode, setMode] = useState("of");
  const a = useAmount("25");
  const b = useAmount("200");

  const result = useMemo(() => {
    if (a.value === null || b.value === null) return null;
    if (mode === "of") return (a.value / 100) * b.value;
    if (mode === "is") return b.value === 0 ? null : (a.value / b.value) * 100;
    return b.value === 0 ? null : ((a.value - b.value) / b.value) * 100;
  }, [a.value, b.value, mode]);

  return (
    <ToolPanel>
      <Tabs value={mode} onValueChange={setMode}>
        <TabsList>
          <TabsTrigger value="of">X% of Y</TabsTrigger>
          <TabsTrigger value="is">X is what % of Y</TabsTrigger>
          <TabsTrigger value="change">Percent change</TabsTrigger>
        </TabsList>
        <TabsContent value={mode} className="flex flex-col gap-4">
          <ToolForm>
            <Field label={mode === "of" ? "Percent" : mode === "is" ? "Value" : "New value"} htmlFor="pct-a">
              <Input id="pct-a" inputMode="decimal" value={a.raw} onChange={(e) => a.setRaw(e.target.value)} />
            </Field>
            <Field label={mode === "of" ? "Of number" : mode === "is" ? "Whole" : "Original value"} htmlFor="pct-b">
              <Input id="pct-b" inputMode="decimal" value={b.raw} onChange={(e) => b.setRaw(e.target.value)} />
            </Field>
          </ToolForm>
          <ResultPanel>
            <ResultRow
              label={mode === "of" ? "Result" : mode === "is" ? "Percentage" : "Change"}
              value={
                result === null
                  ? "—"
                  : mode === "of"
                    ? formatFixed(result, 4)
                    : `${formatFixed(result, 4)}%`
              }
              large
              copy
            />
          </ResultPanel>
        </TabsContent>
      </Tabs>
    </ToolPanel>
  );
}

export function TipCalculatorTool() {
  const bill = useAmount("86.40");
  const tip = useAmount("18");
  const people = useAmount("3");

  const math = useMemo(() => {
    if (bill.value === null || tip.value === null || people.value === null) return null;
    if (people.value <= 0) return null;
    const tipAmount = (bill.value * tip.value) / 100;
    const total = bill.value + tipAmount;
    return {
      tipAmount,
      total,
      perPerson: total / people.value,
    };
  }, [bill.value, tip.value, people.value]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <ToolForm>
        <Field label="Bill amount" htmlFor="tip-bill">
          <Input id="tip-bill" inputMode="decimal" value={bill.raw} onChange={(e) => bill.setRaw(e.target.value)} />
        </Field>
        <Field label="Tip percent" htmlFor="tip-pct">
          <Input id="tip-pct" inputMode="decimal" value={tip.raw} onChange={(e) => tip.setRaw(e.target.value)} />
        </Field>
        <Field label="People" htmlFor="tip-people">
          <Input id="tip-people" inputMode="numeric" value={people.raw} onChange={(e) => people.setRaw(e.target.value)} />
        </Field>
      </ToolForm>
      <ResultPanel>
        <ResultRow label="Tip" value={math ? formatFixed(math.tipAmount) : "—"} copy />
        <ResultRow label="Total" value={math ? formatFixed(math.total) : "—"} large copy />
        <ResultRow label="Per person" value={math ? formatFixed(math.perPerson) : "—"} copy />
      </ResultPanel>
    </ToolPanel>
  );
}

export function DiscountCalculatorTool() {
  const price = useAmount("120");
  const off = useAmount("30");

  const math = useMemo(() => {
    if (price.value === null || off.value === null) return null;
    const saved = (price.value * off.value) / 100;
    return { saved, final: price.value - saved };
  }, [price.value, off.value]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <ToolForm>
        <Field label="Original price" htmlFor="disc-price">
          <Input id="disc-price" inputMode="decimal" value={price.raw} onChange={(e) => price.setRaw(e.target.value)} />
        </Field>
        <Field label="Discount percent" htmlFor="disc-off">
          <Input id="disc-off" inputMode="decimal" value={off.raw} onChange={(e) => off.setRaw(e.target.value)} />
        </Field>
      </ToolForm>
      <ResultPanel>
        <ResultRow label="You save" value={math ? formatFixed(math.saved) : "—"} copy />
        <ResultRow label="Sale price" value={math ? formatFixed(math.final) : "—"} large copy />
      </ResultPanel>
    </ToolPanel>
  );
}

export function SplitBillTool() {
  const total = useAmount("240");
  const people = useAmount("4");
  const tax = useAmount("8");
  const tip = useAmount("10");

  const math = useMemo(() => {
    if (total.value === null || people.value === null || tax.value === null || tip.value === null) {
      return null;
    }
    if (people.value <= 0) return null;
    const withTax = total.value * (1 + tax.value / 100);
    const grand = withTax * (1 + tip.value / 100);
    return { grand, per: grand / people.value };
  }, [total.value, people.value, tax.value, tip.value]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <ToolForm>
        <Field label="Subtotal" htmlFor="split-total">
          <Input id="split-total" inputMode="decimal" value={total.raw} onChange={(e) => total.setRaw(e.target.value)} />
        </Field>
        <Field label="People" htmlFor="split-people">
          <Input id="split-people" inputMode="numeric" value={people.raw} onChange={(e) => people.setRaw(e.target.value)} />
        </Field>
        <Field label="Tax percent" htmlFor="split-tax">
          <Input id="split-tax" inputMode="decimal" value={tax.raw} onChange={(e) => tax.setRaw(e.target.value)} />
        </Field>
        <Field label="Tip percent" htmlFor="split-tip">
          <Input id="split-tip" inputMode="decimal" value={tip.raw} onChange={(e) => tip.setRaw(e.target.value)} />
        </Field>
      </ToolForm>
      <ResultPanel>
        <ResultRow label="Grand total" value={math ? formatFixed(math.grand) : "—"} copy />
        <ResultRow label="Each person" value={math ? formatFixed(math.per) : "—"} large copy />
      </ResultPanel>
    </ToolPanel>
  );
}

export function LoanCalculatorTool() {
  const principal = useAmount("250000");
  const rate = useAmount("6.5");
  const years = useAmount("30");

  const math = useMemo(() => {
    if (principal.value === null || rate.value === null || years.value === null) return null;
    const n = years.value * 12;
    if (n <= 0 || principal.value <= 0) return null;
    const r = rate.value / 100 / 12;
    const payment =
      r === 0
        ? principal.value / n
        : (principal.value * r * (1 + r) ** n) / ((1 + r) ** n - 1);
    const total = payment * n;
    return { payment, total, interest: total - principal.value, n };
  }, [principal.value, rate.value, years.value]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <ToolForm>
        <Field label="Loan amount" htmlFor="loan-p">
          <Input id="loan-p" inputMode="decimal" value={principal.raw} onChange={(e) => principal.setRaw(e.target.value)} />
        </Field>
        <Field label="Annual rate (%)" htmlFor="loan-r">
          <Input id="loan-r" inputMode="decimal" value={rate.raw} onChange={(e) => rate.setRaw(e.target.value)} />
        </Field>
        <Field label="Term (years)" htmlFor="loan-y">
          <Input id="loan-y" inputMode="decimal" value={years.raw} onChange={(e) => years.setRaw(e.target.value)} />
        </Field>
      </ToolForm>
      <ResultPanel>
        <ResultRow label="Monthly payment" value={math ? formatFixed(math.payment) : "—"} large copy />
        <ResultRow label="Total paid" value={math ? formatFixed(math.total) : "—"} copy />
        <ResultRow label="Total interest" value={math ? formatFixed(math.interest) : "—"} copy />
        <ResultRow label="Payments" value={math ? String(math.n) : "—"} />
      </ResultPanel>
    </ToolPanel>
  );
}

export function CompoundInterestTool() {
  const principal = useAmount("10000");
  const rate = useAmount("7");
  const years = useAmount("10");
  const monthly = useAmount("200");
  const [freq, setFreq] = useState("12");

  const math = useMemo(() => {
    if (
      principal.value === null ||
      rate.value === null ||
      years.value === null ||
      monthly.value === null
    ) {
      return null;
    }
    const n = Number(freq);
    const t = years.value;
    const r = rate.value / 100;
    if (n <= 0 || t < 0) return null;
    const compound = principal.value * (1 + r / n) ** (n * t);
    const contrib =
      monthly.value === 0
        ? 0
        : monthly.value * (((1 + r / 12) ** (12 * t) - 1) / (r / 12 || 1));
    const extra = r === 0 ? monthly.value * 12 * t : contrib;
    const future = compound + extra;
    const invested = principal.value + monthly.value * 12 * t;
    return { future, invested, gained: future - invested };
  }, [principal.value, rate.value, years.value, monthly.value, freq]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <ToolForm>
        <Field label="Principal" htmlFor="ci-p">
          <Input id="ci-p" inputMode="decimal" value={principal.raw} onChange={(e) => principal.setRaw(e.target.value)} />
        </Field>
        <Field label="Annual rate (%)" htmlFor="ci-r">
          <Input id="ci-r" inputMode="decimal" value={rate.raw} onChange={(e) => rate.setRaw(e.target.value)} />
        </Field>
        <Field label="Years" htmlFor="ci-y">
          <Input id="ci-y" inputMode="decimal" value={years.raw} onChange={(e) => years.setRaw(e.target.value)} />
        </Field>
        <Field label="Monthly addition" htmlFor="ci-m">
          <Input id="ci-m" inputMode="decimal" value={monthly.raw} onChange={(e) => monthly.setRaw(e.target.value)} />
        </Field>
        <Field label="Compounds per year" htmlFor="ci-f">
          <Input id="ci-f" inputMode="numeric" value={freq} onChange={(e) => setFreq(e.target.value)} />
        </Field>
      </ToolForm>
      <ResultPanel>
        <ResultRow label="Future value" value={math ? formatFixed(math.future) : "—"} large copy />
        <ResultRow label="Amount invested" value={math ? formatFixed(math.invested) : "—"} copy />
        <ResultRow label="Interest earned" value={math ? formatFixed(math.gained) : "—"} copy />
      </ResultPanel>
    </ToolPanel>
  );
}

export function VatCalculatorTool() {
  const amount = useAmount("100");
  const rate = useAmount("20");
  const [mode, setMode] = useState("add");

  const math = useMemo(() => {
    if (amount.value === null || rate.value === null || rate.value < 0) return null;
    const r = rate.value / 100;
    if (mode === "add") {
      const tax = amount.value * r;
      return { net: amount.value, tax, gross: amount.value + tax };
    }
    const gross = amount.value;
    const net = gross / (1 + r);
    return { net, tax: gross - net, gross };
  }, [amount.value, rate.value, mode]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <Tabs value={mode} onValueChange={setMode}>
        <TabsList>
          <TabsTrigger value="add">Add tax</TabsTrigger>
          <TabsTrigger value="extract">Tax included</TabsTrigger>
        </TabsList>
      </Tabs>
      <ToolForm>
        <Field label={mode === "add" ? "Net amount" : "Gross amount"} htmlFor="vat-a">
          <Input id="vat-a" inputMode="decimal" value={amount.raw} onChange={(e) => amount.setRaw(e.target.value)} />
        </Field>
        <Field label="Tax rate (%)" htmlFor="vat-r">
          <Input id="vat-r" inputMode="decimal" value={rate.raw} onChange={(e) => rate.setRaw(e.target.value)} />
        </Field>
      </ToolForm>
      <ResultPanel>
        <ResultRow label="Net" value={math ? formatFixed(math.net) : "—"} copy />
        <ResultRow label="Tax" value={math ? formatFixed(math.tax) : "—"} copy />
        <ResultRow label="Gross" value={math ? formatFixed(math.gross) : "—"} large copy />
      </ResultPanel>
    </ToolPanel>
  );
}

export function SalaryConverterTool() {
  const [basis, setBasis] = useState<"hourly" | "monthly" | "yearly">("yearly");
  const amount = useAmount("72000");
  const hours = useAmount("40");
  const weeks = useAmount("52");

  const math = useMemo(() => {
    if (amount.value === null || hours.value === null || weeks.value === null) return null;
    if (hours.value <= 0 || weeks.value <= 0) return null;
    const yearHours = hours.value * weeks.value;
    let yearly = amount.value;
    if (basis === "hourly") yearly = amount.value * yearHours;
    if (basis === "monthly") yearly = amount.value * 12;
    return {
      hourly: yearly / yearHours,
      monthly: yearly / 12,
      yearly,
      weekly: yearly / weeks.value,
    };
  }, [amount.value, hours.value, weeks.value, basis]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <ToolForm>
        <Field label="I know">
          <div className="flex flex-wrap gap-2">
            {(["hourly", "monthly", "yearly"] as const).map((item) => (
              <Button
                key={item}
                type="button"
                size="sm"
                variant={basis === item ? "default" : "secondary"}
                onClick={() => setBasis(item)}
              >
                {item}
              </Button>
            ))}
          </div>
        </Field>
        <Field label={`Amount (${basis})`} htmlFor="sal-a">
          <Input id="sal-a" inputMode="decimal" value={amount.raw} onChange={(e) => amount.setRaw(e.target.value)} />
        </Field>
        <Field label="Hours per week" htmlFor="sal-h">
          <Input id="sal-h" inputMode="decimal" value={hours.raw} onChange={(e) => hours.setRaw(e.target.value)} />
        </Field>
        <Field label="Weeks per year" htmlFor="sal-w">
          <Input id="sal-w" inputMode="decimal" value={weeks.raw} onChange={(e) => weeks.setRaw(e.target.value)} />
        </Field>
      </ToolForm>
      <ResultPanel>
        <ResultRow label="Hourly" value={math ? formatFixed(math.hourly) : "—"} copy />
        <ResultRow label="Weekly" value={math ? formatFixed(math.weekly) : "—"} copy />
        <ResultRow label="Monthly" value={math ? formatFixed(math.monthly) : "—"} copy />
        <ResultRow label="Yearly" value={math ? formatFixed(math.yearly) : "—"} large copy />
      </ResultPanel>
    </ToolPanel>
  );
}

export function FuelCostTool() {
  const distance = useAmount("320");
  const economy = useAmount("7.4");
  const price = useAmount("1.65");
  const [unit, setUnit] = useState<"metric" | "us">("metric");

  const math = useMemo(() => {
    if (distance.value === null || economy.value === null || price.value === null) return null;
    if (distance.value < 0 || economy.value <= 0 || price.value < 0) return null;
    if (unit === "metric") {
      const litres = (economy.value / 100) * distance.value;
      return { fuel: litres, cost: litres * price.value, fuelLabel: "Litres", distLabel: "km" };
    }
    const gallons = distance.value / economy.value;
    return { fuel: gallons, cost: gallons * price.value, fuelLabel: "Gallons", distLabel: "miles" };
  }, [distance.value, economy.value, price.value, unit]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <div className="flex flex-wrap gap-2">
        <Button type="button" size="sm" variant={unit === "metric" ? "default" : "secondary"} onClick={() => setUnit("metric")}>
          L / 100 km
        </Button>
        <Button type="button" size="sm" variant={unit === "us" ? "default" : "secondary"} onClick={() => setUnit("us")}>
          MPG
        </Button>
      </div>
      <ToolForm>
        <Field label={unit === "metric" ? "Distance (km)" : "Distance (miles)"} htmlFor="fuel-d">
          <Input id="fuel-d" inputMode="decimal" value={distance.raw} onChange={(e) => distance.setRaw(e.target.value)} />
        </Field>
        <Field label={unit === "metric" ? "L / 100 km" : "Miles per gallon"} htmlFor="fuel-e">
          <Input id="fuel-e" inputMode="decimal" value={economy.raw} onChange={(e) => economy.setRaw(e.target.value)} />
        </Field>
        <Field label={unit === "metric" ? "Price per litre" : "Price per gallon"} htmlFor="fuel-p">
          <Input id="fuel-p" inputMode="decimal" value={price.raw} onChange={(e) => price.setRaw(e.target.value)} />
        </Field>
      </ToolForm>
      <ResultPanel>
        <ResultRow label={math?.fuelLabel ?? "Fuel"} value={math ? formatFixed(math.fuel, 3) : "—"} copy />
        <ResultRow label="Trip cost" value={math ? formatFixed(math.cost) : "—"} large copy />
      </ResultPanel>
    </ToolPanel>
  );
}

