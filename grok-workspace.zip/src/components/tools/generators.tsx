import { useEffect, useMemo, useState } from "react";
import { encode, renderSVG } from "uqr";
import { copyText } from "@/lib/copy";
import { clampNumber, parseNumeric } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Field,
  ResultPanel,
  ToolForm,
  ToolPanel,
  CopyButton,
} from "@/components/tools/shared";

function randomInt(max: number) {
  const buf = new Uint32Array(1);
  crypto.getRandomValues(buf);
  return buf[0] % max;
}

function randomChars(length: number, alphabet: string) {
  const out: string[] = [];
  for (let i = 0; i < length; i += 1) out.push(alphabet[randomInt(alphabet.length)]);
  return out.join("");
}

function passwordScore(value: string, variety: number) {
  if (value.length >= 16 && variety >= 3) return { label: "Strong", tone: "ok" as const };
  if (value.length >= 12 && variety >= 2) return { label: "Good", tone: "ok" as const };
  if (value.length >= 8) return { label: "Fair", tone: "warn" as const };
  return { label: "Short", tone: "danger" as const };
}

export function PasswordGeneratorTool() {
  const [length, setLength] = useState(16);
  const [upper, setUpper] = useState(true);
  const [lower, setLower] = useState(true);
  const [digits, setDigits] = useState(true);
  const [symbols, setSymbols] = useState(true);
  const [exclude, setExclude] = useState(true);
  const [value, setValue] = useState("");

  const alphabet = useMemo(() => {
    const parts: string[] = [];
    if (lower) parts.push(exclude ? "abcdefghijkmnopqrstuvwxyz" : "abcdefghijklmnopqrstuvwxyz");
    if (upper) parts.push(exclude ? "ABCDEFGHJKLMNPQRSTUVWXYZ" : "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
    if (digits) parts.push(exclude ? "23456789" : "0123456789");
    if (symbols) parts.push("!@#$%^&*_-+=?");
    return parts.join("") || "abcdefghijkmnopqrstuvwxyz";
  }, [upper, lower, digits, symbols, exclude]);

  const generate = () => setValue(randomChars(length, alphabet));

  useEffect(() => {
    setValue(randomChars(length, alphabet));
    // First paint only — later changes wait for Generate.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const variety = [upper, lower, digits, symbols].filter(Boolean).length;
  const score = value ? passwordScore(value, variety) : null;

  const toggles: { id: string; label: string; on: boolean; set: (v: boolean) => void }[] = [
    { id: "upper", label: "Uppercase", on: upper, set: setUpper },
    { id: "lower", label: "Lowercase", on: lower, set: setLower },
    { id: "digits", label: "Digits", on: digits, set: setDigits },
    { id: "symbols", label: "Symbols", on: symbols, set: setSymbols },
    { id: "exclude", label: "Exclude similar (Il1O0)", on: exclude, set: setExclude },
  ];

  return (
    <ToolPanel className="flex flex-col gap-5">
      <Field label={`Length · ${length}`}>
        <Slider
          min={8}
          max={64}
          step={1}
          value={[length]}
          onValueChange={(v) => setLength(v[0] ?? 16)}
          aria-label="Password length"
        />
      </Field>
      <div className="grid gap-3 sm:grid-cols-2">
        {toggles.map((item) => (
          <div key={item.id} className="flex items-center justify-between gap-3 rounded-sm bg-bg px-3 py-2">
            <Label htmlFor={item.id}>{item.label}</Label>
            <Switch id={item.id} checked={item.on} onCheckedChange={item.set} />
          </div>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        <Button type="button" onClick={generate}>
          Generate
        </Button>
        <CopyButton value={value} />
      </div>
      <ResultPanel>
        <p className="break-all font-mono text-lg">{value || "Generate a password to begin."}</p>
        {score ? (
          <div className="mt-3">
            <Badge tone={score.tone}>{score.label}</Badge>
          </div>
        ) : null}
      </ResultPanel>
    </ToolPanel>
  );
}

export function QrCodeTool() {
  const [text, setText] = useState("https://");
  const encoded = useMemo(() => {
    const payload = text.trim() || " ";
    try {
      return {
        svg: renderSVG(payload, {
          ecc: "M",
          border: 2,
          pixelSize: 8,
          blackColor: "#1a1916",
          whiteColor: "#faf8f3",
        }),
        matrix: encode(payload, { ecc: "M", border: 2 }),
      };
    } catch {
      return null;
    }
  }, [text]);

  const download = (kind: "svg" | "png") => {
    if (!encoded) return;
    if (kind === "svg") {
      const blob = new Blob([encoded.svg], { type: "image/svg+xml" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "qr-code.svg";
      a.click();
      URL.revokeObjectURL(url);
      return;
    }
    const size = encoded.matrix.size;
    const canvas = document.createElement("canvas");
    const scale = 8;
    canvas.width = size * scale;
    canvas.height = size * scale;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.fillStyle = "#faf8f3";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#1a1916";
    encoded.matrix.data.forEach((row, y) => {
      row.forEach((cell, x) => {
        if (cell) ctx.fillRect(x * scale, y * scale, scale, scale);
      });
    });
    canvas.toBlob((blob) => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "qr-code.png";
      a.click();
      URL.revokeObjectURL(url);
    });
  };

  return (
    <ToolPanel className="flex flex-col gap-4">
      <Field label="Text or URL" htmlFor="qr-text">
        <Input id="qr-text" value={text} onChange={(e) => setText(e.target.value)} />
      </Field>
      <div className="flex justify-center rounded-sm bg-bg p-4">
        {encoded ? (
          <div
            className="w-56 [&_svg]:h-full [&_svg]:w-full"
            dangerouslySetInnerHTML={{ __html: encoded.svg }}
          />
        ) : (
          <p className="text-sm text-muted">Could not encode that text.</p>
        )}
      </div>
      <div className="flex flex-wrap gap-2">
        <Button type="button" onClick={() => download("svg")}>
          Download SVG
        </Button>
        <Button type="button" variant="secondary" onClick={() => download("png")}>
          Download PNG
        </Button>
      </div>
    </ToolPanel>
  );
}

export function UuidGeneratorTool() {
  const [count, setCount] = useState("5");
  const [values, setValues] = useState<string[]>([]);
  const n = clampNumber(Math.floor(Number(count) || 1), 1, 50);

  const generate = () => {
    const next = Array.from({ length: n }, () => crypto.randomUUID());
    setValues(next);
  };

  return (
    <ToolPanel className="flex flex-col gap-4">
      <ToolForm>
        <Field label="How many" htmlFor="uuid-n">
          <Input id="uuid-n" inputMode="numeric" value={count} onChange={(e) => setCount(e.target.value)} />
        </Field>
      </ToolForm>
      <div className="flex flex-wrap gap-2">
        <Button type="button" onClick={generate}>
          Generate
        </Button>
        <CopyButton value={values.join("\n")} label="Copy all" />
      </div>
      <ResultPanel>
        {values.length ? (
          <ul className="space-y-2 font-mono text-sm">
            {values.map((id) => (
              <li key={id}>
                <button type="button" className="text-left hover:text-accent" onClick={() => void copyText(id)}>
                  {id}
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-muted">Generate to create version 4 UUIDs.</p>
        )}
      </ResultPanel>
    </ToolPanel>
  );
}

export function RandomNumberTool() {
  const [min, setMin] = useState("1");
  const [max, setMax] = useState("100");
  const [count, setCount] = useState("1");
  const [unique, setUnique] = useState(false);
  const [values, setValues] = useState<number[]>([]);

  const generate = () => {
    const lo = parseNumeric(min);
    const hi = parseNumeric(max);
    const n = clampNumber(Math.floor(Number(count) || 1), 1, 100);
    if (lo === null || hi === null) return;
    const a = Math.ceil(Math.min(lo, hi));
    const b = Math.floor(Math.max(lo, hi));
    const span = b - a + 1;
    if (span <= 0) return;
    const out: number[] = [];
    if (unique) {
      const pool = Array.from({ length: span }, (_, i) => a + i);
      const take = Math.min(n, pool.length);
      for (let i = 0; i < take; i += 1) {
        const idx = randomInt(pool.length);
        out.push(pool.splice(idx, 1)[0]);
      }
    } else {
      for (let i = 0; i < n; i += 1) out.push(a + randomInt(span));
    }
    setValues(out);
  };

  return (
    <ToolPanel className="flex flex-col gap-4">
      <ToolForm>
        <Field label="Minimum" htmlFor="rnd-min">
          <Input id="rnd-min" inputMode="numeric" value={min} onChange={(e) => setMin(e.target.value)} />
        </Field>
        <Field label="Maximum" htmlFor="rnd-max">
          <Input id="rnd-max" inputMode="numeric" value={max} onChange={(e) => setMax(e.target.value)} />
        </Field>
        <Field label="Count" htmlFor="rnd-n">
          <Input id="rnd-n" inputMode="numeric" value={count} onChange={(e) => setCount(e.target.value)} />
        </Field>
        <div className="flex items-center justify-between gap-3 rounded-sm bg-bg px-3 py-2">
          <Label htmlFor="rnd-unique">Unique values</Label>
          <Switch id="rnd-unique" checked={unique} onCheckedChange={setUnique} />
        </div>
      </ToolForm>
      <div className="flex flex-wrap gap-2">
        <Button type="button" onClick={generate}>
          Generate
        </Button>
        <CopyButton value={values.join(", ")} />
      </div>
      <ResultPanel>
        <p className="font-display text-2xl font-semibold tabular-nums">
          {values.length ? values.join(" · ") : "—"}
        </p>
      </ResultPanel>
    </ToolPanel>
  );
}
