import type { ComponentType } from "react";
import type { ToolSlug } from "@/lib/catalog";
import { CalculatorTool } from "@/components/tools/calculator";
import {
  CompoundInterestTool,
  DiscountCalculatorTool,
  FuelCostTool,
  LoanCalculatorTool,
  PercentageTool,
  SalaryConverterTool,
  SplitBillTool,
  TipCalculatorTool,
  VatCalculatorTool,
} from "@/components/tools/finance-tools";
import { BmiCalculatorTool } from "@/components/tools/bmi-calculator";
import { UnitConverterTool } from "@/components/tools/unit-converter";
import { ColorConverterTool } from "@/components/tools/color-converter";
import {
  NumberBaseTool,
  TimezoneConverterTool,
  UnixTimestampTool,
} from "@/components/tools/convert-small";
import {
  CaseConverterTool,
  LoremIpsumTool,
  MarkdownPreviewTool,
  TextCleanerTool,
  TextDiffTool,
  WordCounterTool,
} from "@/components/tools/text-tools";
import {
  PasswordGeneratorTool,
  QrCodeTool,
  RandomNumberTool,
  UuidGeneratorTool,
} from "@/components/tools/generators";
import {
  Base64Tool,
  HashGeneratorTool,
  JsonFormatterTool,
  UrlEncoderTool,
} from "@/components/tools/developer-tools";
import {
  ImageBase64Tool,
  ImageCompressorTool,
} from "@/components/tools/media-tools";
import {
  ImageConvertTool,
  ImageCropTool,
  ImageFiltersTool,
  ImagePaletteTool,
  ImagePlaceholderTool,
  ImageResizerTool,
  ImageRotateTool,
  ImageWatermarkTool,
} from "@/components/tools/image-tools";
import {
  AgeCalculatorTool,
  CountdownTool,
  PomodoroTool,
  StopwatchTool,
  WorldClockTool,
} from "@/components/tools/time-tools";

export const toolComponents: Record<ToolSlug, ComponentType> = {
  calculator: CalculatorTool,
  percentage: PercentageTool,
  "bmi-calculator": BmiCalculatorTool,
  "tip-calculator": TipCalculatorTool,
  "discount-calculator": DiscountCalculatorTool,
  "vat-calculator": VatCalculatorTool,
  "loan-calculator": LoanCalculatorTool,
  "compound-interest": CompoundInterestTool,
  "salary-converter": SalaryConverterTool,
  "split-bill": SplitBillTool,
  "fuel-cost": FuelCostTool,
  "unit-converter": UnitConverterTool,
  "color-converter": ColorConverterTool,
  "unix-timestamp": UnixTimestampTool,
  "number-base": NumberBaseTool,
  "timezone-converter": TimezoneConverterTool,
  "word-counter": WordCounterTool,
  "case-converter": CaseConverterTool,
  "text-cleaner": TextCleanerTool,
  "text-diff": TextDiffTool,
  "lorem-ipsum": LoremIpsumTool,
  "markdown-preview": MarkdownPreviewTool,
  "password-generator": PasswordGeneratorTool,
  "qr-code": QrCodeTool,
  "image-compressor": ImageCompressorTool,
  "image-resizer": ImageResizerTool,
  "image-crop": ImageCropTool,
  "image-convert": ImageConvertTool,
  "image-rotate": ImageRotateTool,
  "image-filters": ImageFiltersTool,
  "image-palette": ImagePaletteTool,
  "image-watermark": ImageWatermarkTool,
  "image-placeholder": ImagePlaceholderTool,
  "uuid-generator": UuidGeneratorTool,
  "random-number": RandomNumberTool,
  "json-formatter": JsonFormatterTool,
  base64: Base64Tool,
  "image-base64": ImageBase64Tool,
  "url-encoder": UrlEncoderTool,
  "hash-generator": HashGeneratorTool,
  stopwatch: StopwatchTool,
  "age-calculator": AgeCalculatorTool,
  countdown: CountdownTool,
  "world-clock": WorldClockTool,
  pomodoro: PomodoroTool,
};
