import { useCallback, useEffect, useState } from "react";
import { cn } from "@/lib/utils";

type Op = "+" | "-" | "*" | "/" | null;

type CalcState = {
  display: string;
  acc: number | null;
  op: Op;
  seeded: boolean;
};

const initial: CalcState = {
  display: "0",
  acc: null,
  op: null,
  seeded: false,
};

function apply(op: Exclude<Op, null>, a: number, b: number) {
  if (op === "+") return a + b;
  if (op === "-") return a - b;
  if (op === "*") return a * b;
  if (b === 0) return Number.NaN;
  return a / b;
}

function formatDisplay(n: number) {
  if (!Number.isFinite(n)) return "Error";
  const asStr = n.toPrecision(10).replace(/\.?0+$/, "");
  return asStr.length > 14 ? n.toExponential(6) : String(Number(asStr));
}

const keys = [
  { id: "ac", label: "AC", kind: "fn" },
  { id: "sign", label: "±", kind: "fn" },
  { id: "pct", label: "%", kind: "fn" },
  { id: "/", label: "÷", kind: "op" },
  { id: "7", label: "7", kind: "num" },
  { id: "8", label: "8", kind: "num" },
  { id: "9", label: "9", kind: "num" },
  { id: "*", label: "×", kind: "op" },
  { id: "4", label: "4", kind: "num" },
  { id: "5", label: "5", kind: "num" },
  { id: "6", label: "6", kind: "num" },
  { id: "-", label: "−", kind: "op" },
  { id: "1", label: "1", kind: "num" },
  { id: "2", label: "2", kind: "num" },
  { id: "3", label: "3", kind: "num" },
  { id: "+", label: "+", kind: "op" },
  { id: "0", label: "0", kind: "num" },
  { id: ".", label: ".", kind: "num" },
  { id: "back", label: "⌫", kind: "fn" },
  { id: "=", label: "=", kind: "eq" },
] as const;

export function CalculatorTool() {
  const [state, setState] = useState<CalcState>(initial);

  const press = useCallback((id: string) => {
    setState((prev) => {
      if (id === "ac") return initial;
      if (prev.display === "Error" && id !== "ac") return initial;

      if (id === "back") {
        if (prev.seeded) return { ...prev, display: "0", seeded: true };
        const next = prev.display.slice(0, -1);
        return { ...prev, display: next === "" || next === "-" ? "0" : next };
      }

      if (id === "sign") {
        if (prev.display === "0") return prev;
        const next = prev.display.startsWith("-")
          ? prev.display.slice(1)
          : `-${prev.display}`;
        return { ...prev, display: next };
      }

      if (id === "pct") {
        const n = Number(prev.display) / 100;
        return { ...prev, display: formatDisplay(n), seeded: true };
      }

      if (id === ".") {
        if (prev.seeded) return { ...prev, display: "0.", seeded: false };
        if (prev.display.includes(".")) return prev;
        return { ...prev, display: `${prev.display}.` };
      }

      if (/^\d$/.test(id)) {
        if (prev.seeded || prev.display === "0") {
          return { ...prev, display: id, seeded: false };
        }
        if (prev.display.replace("-", "").replace(".", "").length >= 12) return prev;
        return { ...prev, display: `${prev.display}${id}` };
      }

      const current = Number(prev.display);
      if (id === "=") {
        if (prev.op && prev.acc !== null) {
          const result = apply(prev.op, prev.acc, current);
          return {
            display: formatDisplay(result),
            acc: null,
            op: null,
            seeded: true,
          };
        }
        return { ...prev, seeded: true };
      }

      if (id === "+" || id === "-" || id === "*" || id === "/") {
        if (prev.op && prev.acc !== null && !prev.seeded) {
          const result = apply(prev.op, prev.acc, current);
          return {
            display: formatDisplay(result),
            acc: result,
            op: id,
            seeded: true,
          };
        }
        return {
          ...prev,
          acc: current,
          op: id,
          seeded: true,
        };
      }

      return prev;
    });
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && ["INPUT", "TEXTAREA"].includes(target.tagName)) return;
      const key = event.key;
      if (key === "Enter" || key === "=") {
        event.preventDefault();
        press("=");
        return;
      }
      if (key === "Escape") {
        press("ac");
        return;
      }
      if (key === "Backspace") {
        press("back");
        return;
      }
      if (key === "%") {
        press("pct");
        return;
      }
      if (key === ".") {
        press(".");
        return;
      }
      if (["+", "-", "*", "/"].includes(key)) {
        event.preventDefault();
        press(key);
        return;
      }
      if (/^\d$/.test(key)) press(key);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [press]);

  return (
    <div className="mx-auto w-full max-w-sm">
      <div className="rounded-xl bg-surface p-4 shadow-card">
        <div className="mb-3 rounded-sm bg-bg px-4 py-5 text-right">
          <p className="drawing-label mb-2 h-4">
            {state.op ? `${formatDisplay(state.acc ?? 0)} ${state.op}` : "Ready"}
          </p>
          <p className="font-display text-3xl font-semibold tracking-tight tabular-nums break-all">
            {state.display}
          </p>
        </div>
        <div className="grid grid-cols-4 gap-2">
          {keys.map((key) => (
            <button
              key={key.id}
              type="button"
              onClick={() => press(key.id)}
              className={cn(
                "h-14 rounded-md text-lg font-medium transition-[background-color,transform] duration-150 active:scale-[0.98]",
                key.id === "0" && "col-span-1",
                key.kind === "num" && "bg-elevated text-fg shadow-card",
                key.kind === "fn" && "bg-bg text-muted",
                key.kind === "op" && "bg-bg text-accent",
                key.kind === "eq" && "bg-accent text-accent-fg",
              )}
            >
              {key.label}
            </button>
          ))}
        </div>
        <p className="mt-3 text-center text-xs text-subtle">
          Keyboard: digits, operators, Enter, Esc, Backspace
        </p>
      </div>
    </div>
  );
}
