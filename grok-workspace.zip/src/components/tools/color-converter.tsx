import { useMemo, useState } from "react";
import { formatFixed } from "@/lib/format";
import { Input } from "@/components/ui/input";
import {
  Field,
  ResultPanel,
  ResultRow,
  ToolPanel,
} from "@/components/tools/shared";

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

function hexToRgb(hex: string) {
  const raw = hex.trim().replace("#", "");
  const full =
    raw.length === 3
      ? raw
          .split("")
          .map((ch) => ch + ch)
          .join("")
      : raw;
  if (!/^[0-9a-fA-F]{6}$/.test(full)) return null;
  return {
    r: Number.parseInt(full.slice(0, 2), 16),
    g: Number.parseInt(full.slice(2, 4), 16),
    b: Number.parseInt(full.slice(4, 6), 16),
  };
}

function rgbToHex(r: number, g: number, b: number) {
  return `#${[r, g, b]
    .map((n) => clamp(Math.round(n), 0, 255).toString(16).padStart(2, "0"))
    .join("")}`;
}

function rgbToHsl(r: number, g: number, b: number) {
  const nr = r / 255;
  const ng = g / 255;
  const nb = b / 255;
  const max = Math.max(nr, ng, nb);
  const min = Math.min(nr, ng, nb);
  const l = (max + min) / 2;
  const d = max - min;
  let h = 0;
  let s = 0;
  if (d !== 0) {
    s = d / (1 - Math.abs(2 * l - 1));
    switch (max) {
      case nr:
        h = ((ng - nb) / d) % 6;
        break;
      case ng:
        h = (nb - nr) / d + 2;
        break;
      default:
        h = (nr - ng) / d + 4;
    }
    h *= 60;
    if (h < 0) h += 360;
  }
  return { h, s: s * 100, l: l * 100 };
}

function relativeLuminance(r: number, g: number, b: number) {
  const lin = [r, g, b].map((channel) => {
    const c = channel / 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2];
}

function contrast(r: number, g: number, b: number, against: "white" | "black") {
  const l1 = relativeLuminance(r, g, b);
  const l2 = against === "white" ? 1 : 0;
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

export function ColorConverterTool() {
  const [hex, setHex] = useState("#24554e");
  const rgb = hexToRgb(hex);

  const derived = useMemo(() => {
    if (!rgb) return null;
    const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
    return {
      rgb: `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`,
      hsl: `hsl(${Math.round(hsl.h)} ${formatFixed(hsl.s, 1)}% ${formatFixed(hsl.l, 1)}%)`,
      hex: rgbToHex(rgb.r, rgb.g, rgb.b),
      white: contrast(rgb.r, rgb.g, rgb.b, "white"),
      black: contrast(rgb.r, rgb.g, rgb.b, "black"),
    };
  }, [rgb]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <div className="grid gap-4 sm:grid-cols-[auto_1fr]">
        <Field label="Picker">
          <input
            type="color"
            value={derived?.hex ?? "#24554e"}
            onChange={(e) => setHex(e.target.value)}
            className="h-11 w-16 cursor-pointer rounded-md bg-elevated shadow-card"
            aria-label="Color picker"
          />
        </Field>
        <Field label="HEX" htmlFor="color-hex">
          <Input
            id="color-hex"
            value={hex}
            onChange={(e) => setHex(e.target.value)}
            spellCheck={false}
          />
        </Field>
      </div>
      <div
        className="h-20 rounded-sm shadow-card"
        style={{ background: derived?.hex ?? "#24554e" }}
        aria-hidden="true"
      />
      <ResultPanel>
        <ResultRow label="HEX" value={derived?.hex ?? "Invalid"} copy />
        <ResultRow label="RGB" value={derived?.rgb ?? "—"} copy />
        <ResultRow label="HSL" value={derived?.hsl ?? "—"} copy />
        <ResultRow
          label="Contrast vs white"
          value={derived ? `${formatFixed(derived.white, 2)}:1` : "—"}
        />
        <ResultRow
          label="Contrast vs black"
          value={derived ? `${formatFixed(derived.black, 2)}:1` : "—"}
        />
      </ResultPanel>
    </ToolPanel>
  );
}
