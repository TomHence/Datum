import { useMemo, useState } from "react";
import { formatFixed, parseNumeric } from "@/lib/format";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Field,
  ResultPanel,
  ResultRow,
  ToolForm,
  ToolPanel,
} from "@/components/tools/shared";

function classify(bmi: number) {
  if (bmi < 18.5) return { label: "Underweight", tone: "warn" as const };
  if (bmi < 25) return { label: "Healthy range", tone: "ok" as const };
  if (bmi < 30) return { label: "Overweight", tone: "warn" as const };
  return { label: "Obesity range", tone: "danger" as const };
}

export function BmiCalculatorTool() {
  const [system, setSystem] = useState("metric");
  const [cm, setCm] = useState("175");
  const [kg, setKg] = useState("70");
  const [ft, setFt] = useState("5");
  const [inch, setInch] = useState("9");
  const [lb, setLb] = useState("154");

  const bmi = useMemo(() => {
    if (system === "metric") {
      const height = parseNumeric(cm);
      const weight = parseNumeric(kg);
      if (!height || !weight) return null;
      const meters = height / 100;
      return weight / (meters * meters);
    }
    const feet = parseNumeric(ft) ?? 0;
    const inches = parseNumeric(inch) ?? 0;
    const weight = parseNumeric(lb);
    const totalIn = feet * 12 + inches;
    if (!weight || totalIn <= 0) return null;
    return (weight / (totalIn * totalIn)) * 703;
  }, [system, cm, kg, ft, inch, lb]);

  const band = bmi ? classify(bmi) : null;

  return (
    <ToolPanel className="flex flex-col gap-4">
      <Tabs value={system} onValueChange={setSystem}>
        <TabsList>
          <TabsTrigger value="metric">Metric</TabsTrigger>
          <TabsTrigger value="imperial">Imperial</TabsTrigger>
        </TabsList>
      </Tabs>
      {system === "metric" ? (
        <ToolForm>
          <Field label="Height (cm)" htmlFor="bmi-cm">
            <Input id="bmi-cm" inputMode="decimal" value={cm} onChange={(e) => setCm(e.target.value)} />
          </Field>
          <Field label="Weight (kg)" htmlFor="bmi-kg">
            <Input id="bmi-kg" inputMode="decimal" value={kg} onChange={(e) => setKg(e.target.value)} />
          </Field>
        </ToolForm>
      ) : (
        <ToolForm>
          <Field label="Height (ft)" htmlFor="bmi-ft">
            <Input id="bmi-ft" inputMode="numeric" value={ft} onChange={(e) => setFt(e.target.value)} />
          </Field>
          <Field label="Height (in)" htmlFor="bmi-in">
            <Input id="bmi-in" inputMode="numeric" value={inch} onChange={(e) => setInch(e.target.value)} />
          </Field>
          <Field label="Weight (lb)" htmlFor="bmi-lb">
            <Input id="bmi-lb" inputMode="decimal" value={lb} onChange={(e) => setLb(e.target.value)} />
          </Field>
        </ToolForm>
      )}
      <ResultPanel>
        <div className="flex items-center justify-between gap-3 py-2">
          <span className="text-sm text-muted">BMI</span>
          <span className="font-display text-xl font-semibold tabular-nums">
            {bmi ? formatFixed(bmi, 1) : "—"}
          </span>
        </div>
        {band ? (
          <div className="pt-1">
            <Badge tone={band.tone}>{band.label}</Badge>
          </div>
        ) : null}
        <p className="mt-3 text-sm text-muted">
          Categories follow the WHO adult ranges. This is not medical advice.
        </p>
      </ResultPanel>
    </ToolPanel>
  );
}
