import { useEffect, useState } from "react";
import { formatBytes } from "@/lib/format";
import { copyText } from "@/lib/copy";
import {
  MIME,
  type MimeKey,
  canvasToBlob,
  compressToTarget,
  extFor,
  makeCanvas,
  scaledEdge,
  stem,
} from "@/lib/image";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import {
  Field,
  ResultPanel,
  ResultRow,
  ToolPanel,
  CopyButton,
} from "@/components/tools/shared";
import {
  Advanced,
  Choice,
  CompareFrame,
  DownloadLink,
  FilePick,
  SwitchRow,
  useBlobUrl,
  useSource,
} from "@/components/tools/image-shared";

export function ImageCompressorTool() {
  const { source, error, onFile } = useSource();
  const [format, setFormat] = useState<MimeKey>("jpeg");
  const [quality, setQuality] = useState(0.72);
  const [maxEdge, setMaxEdge] = useState(1600);
  const [keepSize, setKeepSize] = useState(false);
  const [targetOn, setTargetOn] = useState(false);
  const [targetKb, setTargetKb] = useState(250);
  const { url, size, setBlob } = useBlobUrl();
  const [busy, setBusy] = useState(false);
  const [outDim, setOutDim] = useState("");

  useEffect(() => {
    if (!source) return;
    let cancel = false;
    setBusy(true);
    const dim = keepSize
      ? { width: source.img.naturalWidth, height: source.img.naturalHeight }
      : scaledEdge(source.img, maxEdge);
    const { canvas, ctx } = makeCanvas(dim.width, dim.height);
    ctx.drawImage(source.img, 0, 0, dim.width, dim.height);
    const run = targetOn && format !== "png"
      ? compressToTarget(canvas, MIME[format], targetKb * 1024)
      : canvasToBlob(canvas, MIME[format], quality);
    void run
      .then((blob) => {
        if (cancel) return;
        setBlob(blob);
        setOutDim(`${dim.width} × ${dim.height}`);
      })
      .catch((err: unknown) => {
        if (!cancel) console.error(err);
      })
      .finally(() => {
        if (!cancel) setBusy(false);
      });
    return () => {
      cancel = true;
    };
  }, [source, format, quality, maxEdge, keepSize, targetOn, targetKb, setBlob]);

  const saved =
    source && size !== null && source.file.size > 0
      ? `${Math.max(0, Math.round((1 - size / source.file.size) * 100))}%`
      : "—";

  return (
    <ToolPanel className="flex flex-col gap-4">
      <FilePick onFile={onFile} inputId="cmp-file" />
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <Choice
        value={format}
        onChange={(id) => setFormat(id as MimeKey)}
        options={[
          { id: "jpeg", label: "JPEG" },
          { id: "webp", label: "WebP" },
          { id: "png", label: "PNG" },
        ]}
      />
      {!targetOn && format !== "png" ? (
        <Field label={`Quality · ${Math.round(quality * 100)}%`}>
          <Slider
            min={0.35}
            max={0.95}
            step={0.01}
            value={[quality]}
            onValueChange={(v) => setQuality(v[0] ?? 0.72)}
          />
        </Field>
      ) : null}
      {!keepSize ? (
        <Field label={`Longest edge · ${maxEdge}px`}>
          <Slider min={400} max={4000} step={50} value={[maxEdge]} onValueChange={(v) => setMaxEdge(v[0] ?? 1600)} />
        </Field>
      ) : null}
      <Advanced>
        <SwitchRow id="cmp-keep" label="Keep original dimensions" checked={keepSize} onCheckedChange={setKeepSize} />
        {format !== "png" ? (
          <>
            <SwitchRow id="cmp-target" label="Aim for a file size" checked={targetOn} onCheckedChange={setTargetOn} />
            {targetOn ? (
              <Field label={`Target · ${targetKb} KB`}>
                <Slider min={40} max={2000} step={10} value={[targetKb]} onValueChange={(v) => setTargetKb(v[0] ?? 250)} />
              </Field>
            ) : null}
          </>
        ) : null}
        <div className="flex flex-wrap gap-2">
          {[
            { label: "Web", q: 0.68, edge: 1600 },
            { label: "Email", q: 0.78, edge: 1200 },
            { label: "Hi-res", q: 0.88, edge: 2560 },
          ].map((item) => (
            <Button
              key={item.label}
              type="button"
              size="sm"
              variant="secondary"
              onClick={() => {
                setTargetOn(false);
                setKeepSize(false);
                setQuality(item.q);
                setMaxEdge(item.edge);
              }}
            >
              {item.label}
            </Button>
          ))}
        </div>
      </Advanced>
      <ResultPanel>
        <ResultRow
          label="Original"
          value={
            source
              ? `${source.img.naturalWidth} × ${source.img.naturalHeight} · ${formatBytes(source.file.size)}`
              : "—"
          }
        />
        <ResultRow
          label="Compressed"
          value={busy ? "Working…" : size !== null ? `${outDim} · ${formatBytes(size)}` : "—"}
          large
        />
        <ResultRow label="Saved" value={saved} />
      </ResultPanel>
      {url && source ? (
        <>
          <CompareFrame before={source.url} after={url} />
          <DownloadLink href={url} name={`${stem(source.file.name)}-compressed.${extFor(MIME[format])}`} />
        </>
      ) : null}
    </ToolPanel>
  );
}

export function ImageBase64Tool() {
  const { source, error, onFile } = useSource();
  const [dataUrl, setDataUrl] = useState("");
  const [shrink, setShrink] = useState(false);
  const [maxEdge, setMaxEdge] = useState(800);
  const [format, setFormat] = useState<MimeKey>("jpeg");
  const [quality, setQuality] = useState(0.8);

  useEffect(() => {
    if (!source) {
      setDataUrl("");
      return;
    }
    let cancel = false;
    const run = async () => {
      if (!shrink) {
        const reader = new FileReader();
        const raw = await new Promise<string>((resolve, reject) => {
          reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : "");
          reader.onerror = () => reject(new Error("Could not read that file."));
          reader.readAsDataURL(source.file);
        });
        if (!cancel) setDataUrl(raw);
        return;
      }
      const dim = scaledEdge(source.img, maxEdge);
      const { canvas, ctx } = makeCanvas(dim.width, dim.height);
      ctx.drawImage(source.img, 0, 0, dim.width, dim.height);
      const blob = await canvasToBlob(canvas, MIME[format], quality);
      const reader = new FileReader();
      const url = await new Promise<string>((resolve, reject) => {
        reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : "");
        reader.onerror = () => reject(new Error("Could not encode."));
        reader.readAsDataURL(blob);
      });
      if (!cancel) setDataUrl(url);
    };
    void run();
    return () => {
      cancel = true;
    };
  }, [source, shrink, maxEdge, format, quality]);

  const html = dataUrl ? `<img src="${dataUrl}" alt="${source?.file.name ?? "image"}" />` : "";
  const md = dataUrl ? `![image](${dataUrl})` : "";
  const css = dataUrl ? `background-image: url("${dataUrl}");` : "";

  return (
    <ToolPanel className="flex flex-col gap-4">
      <FilePick onFile={onFile} inputId="b64-file" />
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <Advanced>
        <SwitchRow id="b64-shrink" label="Compress before encoding" checked={shrink} onCheckedChange={setShrink} />
        {shrink ? (
          <>
            <Field label={`Longest edge · ${maxEdge}px`}>
              <Slider min={200} max={2000} step={50} value={[maxEdge]} onValueChange={(v) => setMaxEdge(v[0] ?? 800)} />
            </Field>
            <Choice
              value={format}
              onChange={(id) => setFormat(id as MimeKey)}
              options={[
                { id: "jpeg", label: "JPEG" },
                { id: "webp", label: "WebP" },
                { id: "png", label: "PNG" },
              ]}
            />
            {format !== "png" ? (
              <Field label={`Quality · ${Math.round(quality * 100)}%`}>
                <Slider min={0.4} max={0.95} step={0.01} value={[quality]} onValueChange={(v) => setQuality(v[0] ?? 0.8)} />
              </Field>
            ) : null}
          </>
        ) : null}
      </Advanced>
      <ResultPanel>
        <ResultRow label="File" value={source?.file.name ?? "—"} />
        <ResultRow label="Source size" value={source ? formatBytes(source.file.size) : "—"} />
        <ResultRow label="Data URL length" value={dataUrl ? String(dataUrl.length) : "—"} large />
      </ResultPanel>
      {dataUrl ? (
        <>
          <img src={dataUrl} alt="Selected" className="img-check max-h-48 w-full rounded-sm object-contain" />
          <Field label="Data URL">
            <Textarea
              readOnly
              value={dataUrl}
              className="min-h-32 font-mono text-xs"
              onFocus={(e) => e.currentTarget.select()}
            />
          </Field>
          <div className="flex flex-wrap gap-2">
            <CopyButton value={dataUrl} label="Copy data URL" />
            <Button type="button" variant="secondary" onClick={() => void copyText(html)}>
              Copy HTML
            </Button>
            <Button type="button" variant="secondary" onClick={() => void copyText(css)}>
              Copy CSS
            </Button>
            <Button type="button" variant="secondary" onClick={() => void copyText(md)}>
              Copy Markdown
            </Button>
          </div>
        </>
      ) : null}
    </ToolPanel>
  );
}
