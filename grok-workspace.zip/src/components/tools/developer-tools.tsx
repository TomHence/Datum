import { useMemo, useState } from "react";
import { copyText } from "@/lib/copy";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Field,
  ResultPanel,
  ToolPanel,
  CopyButton,
} from "@/components/tools/shared";

export function JsonFormatterTool() {
  const [source, setSource] = useState('{\n  "ok": true\n}');
  const [error, setError] = useState<string | null>(null);
  const [output, setOutput] = useState("");

  const format = (pretty: boolean) => {
    try {
      const parsed: unknown = JSON.parse(source);
      setOutput(JSON.stringify(parsed, null, pretty ? 2 : 0));
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Invalid JSON");
    }
  };

  return (
    <ToolPanel className="flex flex-col gap-4">
      <Field label="JSON" htmlFor="json-src">
        <Textarea
          id="json-src"
          value={source}
          onChange={(e) => setSource(e.target.value)}
          className="min-h-52 font-mono text-sm"
        />
      </Field>
      <div className="flex flex-wrap gap-2">
        <Button type="button" onClick={() => format(true)}>
          Format
        </Button>
        <Button type="button" variant="secondary" onClick={() => format(false)}>
          Minify
        </Button>
        <CopyButton value={output || source} />
      </div>
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      {output ? (
        <Textarea readOnly value={output} className="min-h-40 font-mono text-sm" />
      ) : null}
    </ToolPanel>
  );
}

function encodeBase64(text: string) {
  const bytes = new TextEncoder().encode(text);
  let binary = "";
  bytes.forEach((b) => {
    binary += String.fromCharCode(b);
  });
  return btoa(binary);
}

function decodeBase64(text: string) {
  const binary = atob(text);
  const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

export function Base64Tool() {
  const [source, setSource] = useState("Datum");
  const [mode, setMode] = useState<"encode" | "decode">("encode");

  const result = useMemo(() => {
    try {
      if (mode === "encode") return { output: encodeBase64(source), error: null };
      return { output: decodeBase64(source.trim()), error: null };
    } catch {
      return { output: "", error: "Could not decode that input." };
    }
  }, [source, mode]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <div className="flex flex-wrap gap-2">
        <Button type="button" variant={mode === "encode" ? "default" : "secondary"} onClick={() => setMode("encode")}>
          Encode
        </Button>
        <Button type="button" variant={mode === "decode" ? "default" : "secondary"} onClick={() => setMode("decode")}>
          Decode
        </Button>
      </div>
      <Field label="Input" htmlFor="b64-src">
        <Textarea id="b64-src" value={source} onChange={(e) => setSource(e.target.value)} className="font-mono text-sm" />
      </Field>
      {result.error ? <p className="text-sm text-danger">{result.error}</p> : null}
      <ResultPanel>
        <p className="break-all font-mono text-sm">{result.output || "—"}</p>
      </ResultPanel>
      <CopyButton value={result.output} />
    </ToolPanel>
  );
}

export function UrlEncoderTool() {
  const [source, setSource] = useState("hello world & datum=1");
  const [component, setComponent] = useState(true);
  const encoded = component ? encodeURIComponent(source) : encodeURI(source);
  let decoded = "";
  let error: string | null = null;
  try {
    decoded = component ? decodeURIComponent(source) : decodeURI(source);
  } catch {
    error = "Input is not valid percent-encoding.";
  }

  return (
    <ToolPanel className="flex flex-col gap-4">
      <div className="flex items-center justify-between gap-3 rounded-sm bg-bg px-3 py-2">
        <Label htmlFor="url-comp">Component mode (encodeURIComponent)</Label>
        <Switch id="url-comp" checked={component} onCheckedChange={setComponent} />
      </div>
      <Field label="Input" htmlFor="url-src">
        <Textarea id="url-src" value={source} onChange={(e) => setSource(e.target.value)} className="font-mono text-sm" />
      </Field>
      <ResultPanel>
        <p className="mb-1 text-sm text-muted">Encoded</p>
        <p className="mb-4 break-all font-mono text-sm">{encoded}</p>
        <p className="mb-1 text-sm text-muted">Decoded</p>
        <p className="break-all font-mono text-sm">{error ?? decoded}</p>
      </ResultPanel>
      <div className="flex flex-wrap gap-2">
        <Button type="button" variant="secondary" onClick={() => void copyText(encoded)}>
          Copy encoded
        </Button>
        <Button type="button" variant="secondary" onClick={() => void copyText(decoded)}>
          Copy decoded
        </Button>
      </div>
    </ToolPanel>
  );
}

const HASHES = ["SHA-1", "SHA-256", "SHA-384", "SHA-512"] as const;

async function digest(algo: (typeof HASHES)[number], text: string) {
  const data = new TextEncoder().encode(text);
  const buf = await crypto.subtle.digest(algo, data);
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function HashGeneratorTool() {
  const [source, setSource] = useState("Datum");
  const [algo, setAlgo] = useState<(typeof HASHES)[number]>("SHA-256");
  const [hash, setHash] = useState("");
  const [pending, setPending] = useState(false);

  const run = async () => {
    setPending(true);
    try {
      setHash(await digest(algo, source));
    } finally {
      setPending(false);
    }
  };

  return (
    <ToolPanel className="flex flex-col gap-4">
      <Field label="Algorithm">
        <Select value={algo} onValueChange={(v) => setAlgo(v as (typeof HASHES)[number])}>
          <SelectTrigger aria-label="Hash algorithm">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {HASHES.map((item) => (
              <SelectItem key={item} value={item}>
                {item}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </Field>
      <Field label="Input" htmlFor="hash-src">
        <Textarea id="hash-src" value={source} onChange={(e) => setSource(e.target.value)} className="font-mono text-sm" />
      </Field>
      <Button type="button" onClick={() => void run()} disabled={pending}>
        {pending ? "Hashing…" : "Hash"}
      </Button>
      <ResultPanel>
        <p className="break-all font-mono text-sm">{hash || "Run a hash to see the hex digest."}</p>
      </ResultPanel>
      <CopyButton value={hash} />
    </ToolPanel>
  );
}
