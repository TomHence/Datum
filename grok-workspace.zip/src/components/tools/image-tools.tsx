import { useEffect, useMemo, useRef, useState } from "react";
import { copyText } from "@/lib/copy";
import { clampNumber, formatBytes, parseNumeric } from "@/lib/format";
import {
  MIME,
  type MimeKey,
  applyVignette,
  canvasToBlob,
  compressToTarget,
  downloadBlob,
  extFor,
  extractPalette,
  fillColor,
  hexToRgb,
  makeCanvas,
  rgbToHsl,
  rotatedSize,
  stem,
} from "@/lib/image";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import {
  Field,
  ResultPanel,
  ResultRow,
  ToolForm,
  ToolPanel,
  CopyButton,
} from "@/components/tools/shared";
import {
  Advanced,
  Choice,
  ColorField,
  CompareFrame,
  DownloadLink,
  FilePick,
  Preview,
  SwitchRow,
  useBlobUrl,
  useSource,
} from "@/components/tools/image-shared";

const FORMAT_OPTIONS = [
  { id: "png", label: "PNG" },
  { id: "jpeg", label: "JPEG" },
  { id: "webp", label: "WebP" },
];

function drawContain(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  width: number,
  height: number,
  mode: "contain" | "cover" | "stretch",
  matte: string | null,
) {
  if (matte) fillColor(ctx, matte, width, height);
  if (mode === "stretch") {
    ctx.drawImage(img, 0, 0, width, height);
    return;
  }
  const scale =
    mode === "cover"
      ? Math.max(width / img.naturalWidth, height / img.naturalHeight)
      : Math.min(width / img.naturalWidth, height / img.naturalHeight);
  const dw = img.naturalWidth * scale;
  const dh = img.naturalHeight * scale;
  ctx.drawImage(img, (width - dw) / 2, (height - dh) / 2, dw, dh);
}

export function ImageResizerTool() {
  const { source, error, onFile } = useSource();
  const [mode, setMode] = useState<"px" | "pct">("px");
  const [width, setWidth] = useState("1200");
  const [height, setHeight] = useState("630");
  const [percent, setPercent] = useState(50);
  const [lock, setLock] = useState(true);
  const [fit, setFit] = useState<"contain" | "cover" | "stretch">("contain");
  const [format, setFormat] = useState<MimeKey>("png");
  const [quality, setQuality] = useState(0.9);
  const [matte, setMatte] = useState("#f3efe6");
  const { url, size, setBlob } = useBlobUrl();
  const [busy, setBusy] = useState(false);
  const ratio = source ? source.img.naturalWidth / source.img.naturalHeight : 1;

  const out = useMemo(() => {
    if (!source) return { w: 0, h: 0 };
    if (mode === "pct") {
      const s = percent / 100;
      return {
        w: Math.max(1, Math.round(source.img.naturalWidth * s)),
        h: Math.max(1, Math.round(source.img.naturalHeight * s)),
      };
    }
    return {
      w: Math.max(1, Math.round(parseNumeric(width) ?? 0)),
      h: Math.max(1, Math.round(parseNumeric(height) ?? 0)),
    };
  }, [source, mode, percent, width, height]);

  useEffect(() => {
    if (!source || !out.w || !out.h) return;
    let cancel = false;
    setBusy(true);
    const { canvas, ctx } = makeCanvas(out.w, out.h);
    drawContain(ctx, source.img, out.w, out.h, fit, format === "png" && fit !== "cover" ? null : matte);
    void canvasToBlob(canvas, MIME[format], quality).then((blob) => {
      if (!cancel) {
        setBlob(blob);
        setBusy(false);
      }
    });
    return () => {
      cancel = true;
    };
  }, [source, out.w, out.h, fit, format, quality, matte, setBlob]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <FilePick onFile={onFile} inputId="rz-file" />
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <Choice
        value={mode}
        onChange={(id) => setMode(id as "px" | "pct")}
        options={[
          { id: "px", label: "Pixels" },
          { id: "pct", label: "Percent" },
        ]}
      />
      {mode === "pct" ? (
        <Field label={`Scale · ${percent}%`}>
          <Slider min={5} max={200} step={1} value={[percent]} onValueChange={(v) => setPercent(v[0] ?? 50)} />
        </Field>
      ) : (
        <>
          <div className="flex flex-wrap gap-2">
            {[
              { label: "Original", w: source?.img.naturalWidth, h: source?.img.naturalHeight },
              { label: "OG", w: 1200, h: 630 },
              { label: "Square", w: 1080, h: 1080 },
              { label: "Story", w: 1080, h: 1920 },
              { label: "Avatar", w: 400, h: 400 },
              { label: "Favicon", w: 32, h: 32 },
            ].map((item) => (
              <Button
                key={item.label}
                type="button"
                size="sm"
                variant="secondary"
                disabled={!item.w || !item.h}
                onClick={() => {
                  if (!item.w || !item.h) return;
                  setWidth(String(item.w));
                  setHeight(String(item.h));
                  setLock(item.label === "Original");
                }}
              >
                {item.label}
              </Button>
            ))}
          </div>
          <ToolForm>
            <Field label="Width (px)" htmlFor="rz-w">
              <Input
                id="rz-w"
                inputMode="numeric"
                value={width}
                onChange={(e) => {
                  const next = e.target.value;
                  setWidth(next);
                  if (lock) {
                    const n = parseNumeric(next);
                    if (n) setHeight(String(Math.round(n / ratio)));
                  }
                }}
              />
            </Field>
            <Field label="Height (px)" htmlFor="rz-h">
              <Input
                id="rz-h"
                inputMode="numeric"
                value={height}
                onChange={(e) => {
                  const next = e.target.value;
                  setHeight(next);
                  if (lock) {
                    const n = parseNumeric(next);
                    if (n) setWidth(String(Math.round(n * ratio)));
                  }
                }}
              />
            </Field>
          </ToolForm>
          <SwitchRow id="rz-lock" label="Lock aspect" checked={lock} onCheckedChange={setLock} />
        </>
      )}
      <Choice
        value={fit}
        onChange={(id) => setFit(id as typeof fit)}
        options={[
          { id: "contain", label: "Fit" },
          { id: "cover", label: "Fill" },
          { id: "stretch", label: "Stretch" },
        ]}
      />
      <Choice value={format} onChange={(id) => setFormat(id as MimeKey)} options={FORMAT_OPTIONS} />
      <Advanced>
        {format !== "png" ? (
          <Field label={`Quality · ${Math.round(quality * 100)}%`}>
            <Slider min={0.4} max={0.98} step={0.01} value={[quality]} onValueChange={(v) => setQuality(v[0] ?? 0.9)} />
          </Field>
        ) : null}
        <ColorField id="rz-matte" label="Matte (letterbox / JPEG)" value={matte} onChange={setMatte} />
      </Advanced>
      {source ? (
        <ResultPanel>
          <ResultRow
            label="Original"
            value={`${source.img.naturalWidth} × ${source.img.naturalHeight} · ${formatBytes(source.file.size)}`}
          />
          <ResultRow
            label="Output"
            value={busy ? "Working…" : `${out.w} × ${out.h}${size !== null ? ` · ${formatBytes(size)}` : ""}`}
            large
          />
        </ResultPanel>
      ) : null}
      {url && source ? (
        <>
          <CompareFrame before={source.url} after={url} />
          <DownloadLink href={url} name={`${stem(source.file.name)}-resized.${extFor(MIME[format])}`} />
        </>
      ) : null}
    </ToolPanel>
  );
}

type AspectId = "free" | "1:1" | "4:3" | "3:2" | "16:9" | "9:16" | "custom";

const ASPECTS: { id: AspectId; label: string; value: number | null }[] = [
  { id: "free", label: "Free", value: null },
  { id: "1:1", label: "1:1", value: 1 },
  { id: "4:3", label: "4:3", value: 4 / 3 },
  { id: "3:2", label: "3:2", value: 3 / 2 },
  { id: "16:9", label: "16:9", value: 16 / 9 },
  { id: "9:16", label: "9:16", value: 9 / 16 },
  { id: "custom", label: "Custom", value: null },
];

export function ImageCropTool() {
  const { source, error, onFile } = useSource();
  const [aspect, setAspect] = useState<AspectId>("1:1");
  const [customW, setCustomW] = useState("5");
  const [customH, setCustomH] = useState("4");
  const [sizePct, setSizePct] = useState(80);
  const [ox, setOx] = useState(50);
  const [oy, setOy] = useState(50);
  const [roundPct, setRoundPct] = useState(0);
  const [thirds, setThirds] = useState(true);
  const [exportW, setExportW] = useState("");
  const [format, setFormat] = useState<MimeKey>("png");
  const { url, size, setBlob } = useBlobUrl();
  const drag = useRef<{ x: number; y: number; ox: number; oy: number } | null>(null);

  const ratio = useMemo(() => {
    if (aspect === "custom") {
      const w = parseNumeric(customW) ?? 1;
      const h = parseNumeric(customH) ?? 1;
      return w / Math.max(h, 0.01);
    }
    return ASPECTS.find((a) => a.id === aspect)?.value ?? null;
  }, [aspect, customW, customH]);

  const box = useMemo(() => {
    if (!source) return null;
    const iw = source.img.naturalWidth;
    const ih = source.img.naturalHeight;
    let cw: number;
    let ch: number;
    if (!ratio) {
      cw = (iw * sizePct) / 100;
      ch = (ih * sizePct) / 100;
    } else if (iw / ih > ratio) {
      ch = (ih * sizePct) / 100;
      cw = ch * ratio;
    } else {
      cw = (iw * sizePct) / 100;
      ch = cw / ratio;
    }
    cw = Math.min(iw, Math.max(8, cw));
    ch = Math.min(ih, Math.max(8, ch));
    const x = clampNumber((iw - cw) * (ox / 100), 0, iw - cw);
    const y = clampNumber((ih - ch) * (oy / 100), 0, ih - ch);
    return { x, y, w: cw, h: ch, iw, ih };
  }, [source, ratio, sizePct, ox, oy]);

  useEffect(() => {
    if (!source || !box) return;
    const destW = Math.max(8, Math.round(parseNumeric(exportW) ?? box.w));
    const destH = Math.max(8, Math.round((destW * box.h) / box.w));
    const { canvas, ctx } = makeCanvas(destW, destH);
    const r = (roundPct / 100) * (Math.min(destW, destH) / 2);
    if (r > 0) {
      ctx.beginPath();
      ctx.roundRect(0, 0, destW, destH, r);
      ctx.clip();
    }
    if (format !== "png") fillColor(ctx, "#f3efe6", destW, destH);
    ctx.drawImage(source.img, box.x, box.y, box.w, box.h, 0, 0, destW, destH);
    void canvasToBlob(canvas, MIME[format], 0.92).then(setBlob);
  }, [source, box, roundPct, format, exportW, setBlob]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <FilePick onFile={onFile} inputId="crop-file" />
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <Choice value={aspect} onChange={(id) => setAspect(id as AspectId)} options={ASPECTS.map((a) => ({ id: a.id, label: a.label }))} />
      {aspect === "custom" ? (
        <ToolForm>
          <Field label="Ratio width" htmlFor="crop-rw">
            <Input id="crop-rw" inputMode="decimal" value={customW} onChange={(e) => setCustomW(e.target.value)} />
          </Field>
          <Field label="Ratio height" htmlFor="crop-rh">
            <Input id="crop-rh" inputMode="decimal" value={customH} onChange={(e) => setCustomH(e.target.value)} />
          </Field>
        </ToolForm>
      ) : null}
      <Field label={`Frame · ${sizePct}%`}>
        <Slider min={20} max={100} step={1} value={[sizePct]} onValueChange={(v) => setSizePct(v[0] ?? 80)} />
      </Field>
      <ToolForm>
        <Field label="Horizontal">
          <Slider min={0} max={100} step={1} value={[ox]} onValueChange={(v) => setOx(v[0] ?? 50)} />
        </Field>
        <Field label="Vertical">
          <Slider min={0} max={100} step={1} value={[oy]} onValueChange={(v) => setOy(v[0] ?? 50)} />
        </Field>
      </ToolForm>
      <div className="flex flex-wrap gap-2">
        <Button type="button" size="sm" variant="secondary" onClick={() => { setOx(50); setOy(50); }}>
          Center
        </Button>
      </div>
      {source && box ? (
        <div
          className="relative touch-none overflow-hidden rounded-sm bg-bg"
          onPointerDown={(e) => {
            (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
            drag.current = { x: e.clientX, y: e.clientY, ox, oy };
          }}
          onPointerMove={(e) => {
            if (!drag.current) return;
            const rect = e.currentTarget.getBoundingClientRect();
            const dx = ((e.clientX - drag.current.x) / rect.width) * 100;
            const dy = ((e.clientY - drag.current.y) / rect.height) * 100;
            setOx(clampNumber(drag.current.ox + dx, 0, 100));
            setOy(clampNumber(drag.current.oy + dy, 0, 100));
          }}
          onPointerUp={() => {
            drag.current = null;
          }}
        >
          <img src={source.url} alt="Source" className="pointer-events-none block w-full select-none" draggable={false} />
          <div
            className="crop-veil pointer-events-none absolute ring-1 ring-accent"
            style={{
              left: `${(box.x / box.iw) * 100}%`,
              top: `${(box.y / box.ih) * 100}%`,
              width: `${(box.w / box.iw) * 100}%`,
              height: `${(box.h / box.ih) * 100}%`,
              borderRadius: `${roundPct}%`,
            }}
          >
            {thirds ? (
              <>
                <span className="absolute top-0 bottom-0 left-1/3 w-px bg-elevated/70" />
                <span className="absolute top-0 bottom-0 left-2/3 w-px bg-elevated/70" />
                <span className="absolute right-0 left-0 top-1/3 h-px bg-elevated/70" />
                <span className="absolute right-0 left-0 top-2/3 h-px bg-elevated/70" />
              </>
            ) : null}
          </div>
        </div>
      ) : (
        <p className="text-sm text-muted">Drag on the photo to pan the crop.</p>
      )}
      <Field label={`Corner radius · ${roundPct}%`}>
        <Slider min={0} max={50} step={1} value={[roundPct]} onValueChange={(v) => setRoundPct(v[0] ?? 0)} />
      </Field>
      <Choice value={format} onChange={(id) => setFormat(id as MimeKey)} options={FORMAT_OPTIONS} />
      <Advanced>
        <SwitchRow id="crop-thirds" label="Rule of thirds" checked={thirds} onCheckedChange={setThirds} />
        <Field label="Export width (px, blank = crop size)" htmlFor="crop-ew">
          <Input id="crop-ew" inputMode="numeric" value={exportW} onChange={(e) => setExportW(e.target.value)} placeholder={box ? String(Math.round(box.w)) : ""} />
        </Field>
      </Advanced>
      {url ? (
        <>
          <ResultPanel>
            <ResultRow
              label="Crop"
              value={box ? `${Math.round(box.w)} × ${Math.round(box.h)}` : "—"}
              large
            />
            <ResultRow label="File" value={size !== null ? formatBytes(size) : "—"} />
          </ResultPanel>
          <DownloadLink href={url} name={`${stem(source?.file.name ?? "image")}-crop.${extFor(MIME[format])}`} />
        </>
      ) : null}
    </ToolPanel>
  );
}

export function ImageConvertTool() {
  const { source, error, onFile } = useSource();
  const [format, setFormat] = useState<MimeKey>("webp");
  const [quality, setQuality] = useState(0.85);
  const [matte, setMatte] = useState("#f3efe6");
  const { url, size, setBlob } = useBlobUrl();
  const [pack, setPack] = useState<{ jpeg: number; png: number; webp: number } | null>(null);
  const packRef = useRef<{ jpeg: Blob; png: Blob; webp: Blob } | null>(null);

  useEffect(() => {
    if (!source) return;
    let cancel = false;
    const { canvas, ctx } = makeCanvas(source.img.naturalWidth, source.img.naturalHeight);
    if (format !== "png") fillColor(ctx, matte, canvas.width, canvas.height);
    ctx.drawImage(source.img, 0, 0);
    void (async () => {
      const blob = await canvasToBlob(canvas, MIME[format], quality);
      const jpegCanvas = makeCanvas(source.img.naturalWidth, source.img.naturalHeight);
      fillColor(jpegCanvas.ctx, matte, jpegCanvas.canvas.width, jpegCanvas.canvas.height);
      jpegCanvas.ctx.drawImage(source.img, 0, 0);
      const pngCanvas = makeCanvas(source.img.naturalWidth, source.img.naturalHeight);
      pngCanvas.ctx.drawImage(source.img, 0, 0);
      const [jpeg, png, webp] = await Promise.all([
        canvasToBlob(jpegCanvas.canvas, MIME.jpeg, quality),
        canvasToBlob(pngCanvas.canvas, MIME.png),
        canvasToBlob(jpegCanvas.canvas, MIME.webp, quality),
      ]);
      if (cancel) return;
      setBlob(blob);
      packRef.current = { jpeg, png, webp };
      setPack({ jpeg: jpeg.size, png: png.size, webp: webp.size });
    })();
    return () => {
      cancel = true;
    };
  }, [source, format, quality, matte, setBlob]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <FilePick onFile={onFile} inputId="cv-file" />
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <Choice value={format} onChange={(id) => setFormat(id as MimeKey)} options={FORMAT_OPTIONS} />
      {format !== "png" ? (
        <Field label={`Quality · ${Math.round(quality * 100)}%`}>
          <Slider min={0.4} max={0.98} step={0.01} value={[quality]} onValueChange={(v) => setQuality(v[0] ?? 0.85)} />
        </Field>
      ) : null}
      <Advanced>
        <ColorField id="cv-matte" label="JPEG / WebP matte" value={matte} onChange={setMatte} />
      </Advanced>
      {source ? (
        <ResultPanel>
          <ResultRow label="Original" value={`${source.file.type || "image"} · ${formatBytes(source.file.size)}`} />
          <ResultRow label="This format" value={size !== null ? formatBytes(size) : "—"} large />
          {pack ? (
            <>
              <ResultRow label="JPEG" value={formatBytes(pack.jpeg)} />
              <ResultRow label="PNG" value={formatBytes(pack.png)} />
              <ResultRow label="WebP" value={formatBytes(pack.webp)} />
            </>
          ) : null}
        </ResultPanel>
      ) : null}
      {source && url ? <CompareFrame before={source.url} after={url} /> : source ? <Preview src={source.url} alt="Original" /> : null}
      {url && source ? (
        <div className="flex flex-wrap gap-2">
          <DownloadLink href={url} name={`${stem(source.file.name)}.${extFor(MIME[format])}`} />
          <Button
            type="button"
            variant="secondary"
            onClick={() => {
              const blobs = packRef.current;
              if (!blobs) return;
              const base = stem(source.file.name);
              downloadBlob(blobs.jpeg, `${base}.jpg`);
              downloadBlob(blobs.png, `${base}.png`);
              downloadBlob(blobs.webp, `${base}.webp`);
            }}
          >
            Download all three
          </Button>
        </div>
      ) : null}
    </ToolPanel>
  );
}

export function ImageRotateTool() {
  const { source, error, onFile } = useSource();
  const [angle, setAngle] = useState(0);
  const [flipH, setFlipH] = useState(false);
  const [flipV, setFlipV] = useState(false);
  const [expand, setExpand] = useState(true);
  const [format, setFormat] = useState<MimeKey>("png");
  const [matte, setMatte] = useState("#f3efe6");
  const { url, setBlob } = useBlobUrl();

  useEffect(() => {
    if (!source) return;
    const rad = (angle * Math.PI) / 180;
    const iw = source.img.naturalWidth;
    const ih = source.img.naturalHeight;
    const size = expand ? rotatedSize(iw, ih, rad) : { width: iw, height: ih };
    const { canvas, ctx } = makeCanvas(size.width, size.height);
    if (format !== "png" || !expand) fillColor(ctx, matte, canvas.width, canvas.height);
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate(rad);
    ctx.scale(flipH ? -1 : 1, flipV ? -1 : 1);
    ctx.drawImage(source.img, -iw / 2, -ih / 2);
    void canvasToBlob(canvas, MIME[format], 0.92).then(setBlob);
  }, [source, angle, flipH, flipV, expand, format, matte, setBlob]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <FilePick onFile={onFile} inputId="rot-file" />
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <div className="flex flex-wrap gap-2">
        <Button type="button" variant="secondary" onClick={() => setAngle((n) => n - 90)}>
          −90°
        </Button>
        <Button type="button" variant="secondary" onClick={() => setAngle((n) => n + 90)}>
          +90°
        </Button>
        <Button type="button" variant={flipH ? "default" : "secondary"} onClick={() => setFlipH((v) => !v)}>
          Flip H
        </Button>
        <Button type="button" variant={flipV ? "default" : "secondary"} onClick={() => setFlipV((v) => !v)}>
          Flip V
        </Button>
        <Button type="button" variant="ghost" onClick={() => { setAngle(0); setFlipH(false); setFlipV(false); }}>
          Reset
        </Button>
      </div>
      <Field label={`Straighten · ${angle}°`}>
        <Slider min={-180} max={180} step={1} value={[angle]} onValueChange={(v) => setAngle(v[0] ?? 0)} />
      </Field>
      <SwitchRow id="rot-expand" label="Expand canvas to fit" checked={expand} onCheckedChange={setExpand} />
      <Advanced>
        <Choice value={format} onChange={(id) => setFormat(id as MimeKey)} options={FORMAT_OPTIONS} />
        <ColorField id="rot-matte" label="Background" value={matte} onChange={setMatte} />
      </Advanced>
      {url && source ? (
        <>
          <CompareFrame before={source.url} after={url} />
          <DownloadLink href={url} name={`${stem(source.file.name)}-rotated.${extFor(MIME[format])}`} />
        </>
      ) : null}
    </ToolPanel>
  );
}

type FilterState = {
  gray: number;
  bright: number;
  contrast: number;
  sat: number;
  blur: number;
  hue: number;
  vig: number;
  sepia: boolean;
  invert: boolean;
};

const FILTER_PRESETS: { id: string; label: string; value: FilterState }[] = [
  { id: "none", label: "None", value: { gray: 0, bright: 100, contrast: 100, sat: 100, blur: 0, hue: 0, vig: 0, sepia: false, invert: false } },
  { id: "punch", label: "Punch", value: { gray: 0, bright: 104, contrast: 124, sat: 118, blur: 0, hue: 0, vig: 0.12, sepia: false, invert: false } },
  { id: "fade", label: "Fade", value: { gray: 8, bright: 110, contrast: 86, sat: 78, blur: 0, hue: 8, vig: 0.18, sepia: false, invert: false } },
  { id: "warm", label: "Warm", value: { gray: 0, bright: 106, contrast: 108, sat: 112, blur: 0, hue: -12, vig: 0.08, sepia: false, invert: false } },
  { id: "cool", label: "Cool", value: { gray: 0, bright: 102, contrast: 110, sat: 96, blur: 0, hue: 18, vig: 0.1, sepia: false, invert: false } },
  { id: "noir", label: "Noir", value: { gray: 100, bright: 98, contrast: 132, sat: 0, blur: 0, hue: 0, vig: 0.48, sepia: false, invert: false } },
  { id: "film", label: "Film", value: { gray: 0, bright: 102, contrast: 114, sat: 88, blur: 0, hue: -6, vig: 0.22, sepia: true, invert: false } },
];

export function ImageFiltersTool() {
  const { source, error, onFile } = useSource();
  const [f, setF] = useState<FilterState>(FILTER_PRESETS[0]!.value);
  const [preset, setPreset] = useState("none");
  const [format, setFormat] = useState<MimeKey>("png");
  const { url, setBlob } = useBlobUrl();

  useEffect(() => {
    if (!source) return;
    const { canvas, ctx } = makeCanvas(source.img.naturalWidth, source.img.naturalHeight);
    ctx.filter = [
      `grayscale(${f.gray}%)`,
      `brightness(${f.bright}%)`,
      `contrast(${f.contrast}%)`,
      `saturate(${f.sat}%)`,
      `hue-rotate(${f.hue}deg)`,
      `blur(${f.blur}px)`,
      f.sepia ? "sepia(0.65)" : "",
      f.invert ? "invert(1)" : "",
    ]
      .filter(Boolean)
      .join(" ");
    ctx.drawImage(source.img, 0, 0);
    ctx.filter = "none";
    applyVignette(ctx, canvas.width, canvas.height, f.vig);
    void canvasToBlob(canvas, MIME[format], 0.92).then(setBlob);
  }, [source, f, format, setBlob]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <FilePick onFile={onFile} inputId="fx-file" />
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <Choice
        value={preset}
        onChange={(id) => {
          setPreset(id);
          const found = FILTER_PRESETS.find((p) => p.id === id);
          if (found) setF(found.value);
        }}
        options={FILTER_PRESETS.map((p) => ({ id: p.id, label: p.label }))}
      />
      <Field label={`Brightness · ${f.bright}%`}>
        <Slider min={40} max={180} step={1} value={[f.bright]} onValueChange={(v) => { setPreset("custom"); setF((s) => ({ ...s, bright: v[0] ?? 100 })); }} />
      </Field>
      <Field label={`Contrast · ${f.contrast}%`}>
        <Slider min={40} max={180} step={1} value={[f.contrast]} onValueChange={(v) => { setPreset("custom"); setF((s) => ({ ...s, contrast: v[0] ?? 100 })); }} />
      </Field>
      <Field label={`Saturation · ${f.sat}%`}>
        <Slider min={0} max={200} step={1} value={[f.sat]} onValueChange={(v) => { setPreset("custom"); setF((s) => ({ ...s, sat: v[0] ?? 100 })); }} />
      </Field>
      <Advanced>
        <Field label={`Hue · ${f.hue}°`}>
          <Slider min={-180} max={180} step={1} value={[f.hue]} onValueChange={(v) => { setPreset("custom"); setF((s) => ({ ...s, hue: v[0] ?? 0 })); }} />
        </Field>
        <Field label={`Grayscale · ${f.gray}%`}>
          <Slider min={0} max={100} step={1} value={[f.gray]} onValueChange={(v) => { setPreset("custom"); setF((s) => ({ ...s, gray: v[0] ?? 0 })); }} />
        </Field>
        <Field label={`Blur · ${f.blur}px`}>
          <Slider min={0} max={12} step={1} value={[f.blur]} onValueChange={(v) => { setPreset("custom"); setF((s) => ({ ...s, blur: v[0] ?? 0 })); }} />
        </Field>
        <Field label={`Vignette · ${Math.round(f.vig * 100)}%`}>
          <Slider min={0} max={0.7} step={0.01} value={[f.vig]} onValueChange={(v) => { setPreset("custom"); setF((s) => ({ ...s, vig: v[0] ?? 0 })); }} />
        </Field>
        <div className="flex flex-wrap gap-2">
          <Button type="button" size="sm" variant={f.sepia ? "default" : "secondary"} onClick={() => { setPreset("custom"); setF((s) => ({ ...s, sepia: !s.sepia })); }}>
            Sepia
          </Button>
          <Button type="button" size="sm" variant={f.invert ? "default" : "secondary"} onClick={() => { setPreset("custom"); setF((s) => ({ ...s, invert: !s.invert })); }}>
            Invert
          </Button>
        </div>
        <Choice value={format} onChange={(id) => setFormat(id as MimeKey)} options={FORMAT_OPTIONS} />
      </Advanced>
      {url && source ? (
        <>
          <CompareFrame before={source.url} after={url} />
          <DownloadLink href={url} name={`${stem(source.file.name)}-edit.${extFor(MIME[format])}`} />
        </>
      ) : null}
    </ToolPanel>
  );
}

export function ImagePaletteTool() {
  const { source, error, onFile } = useSource();
  const [count, setCount] = useState(6);
  const colors = useMemo(
    () => (source ? extractPalette(source.img, count) : []),
    [source, count],
  );
  const css = colors.map((c, i) => `  --swatch-${i + 1}: ${c};`).join("\n");
  const json = JSON.stringify(colors, null, 2);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <FilePick onFile={onFile} inputId="pal-file" />
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <Field label={`Swatches · ${count}`}>
        <Slider min={3} max={10} step={1} value={[count]} onValueChange={(v) => setCount(v[0] ?? 6)} />
      </Field>
      {source ? <Preview src={source.url} alt="Source" /> : null}
      {colors.length ? (
        <>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {colors.map((hex) => {
              const rgb = hexToRgb(hex);
              const hsl = rgb ? rgbToHsl(...rgb) : "";
              return (
                <button
                  key={hex}
                  type="button"
                  className="flex flex-col overflow-hidden rounded-md text-left shadow-card"
                  onClick={() => void copyText(hex, "Copied colour")}
                >
                  <span className="h-16 w-full" style={{ backgroundColor: hex }} />
                  <span className="bg-elevated px-3 py-2 font-mono text-xs">
                    {hex}
                    {hsl ? <span className="mt-1 block text-muted">hsl({hsl})</span> : null}
                  </span>
                </button>
              );
            })}
          </div>
          <div className="flex flex-wrap gap-2">
            <CopyButton value={colors.join("\n")} label="Copy hex list" />
            <CopyButton value={`:root {\n${css}\n}`} label="Copy CSS" />
            <CopyButton value={json} label="Copy JSON" />
          </div>
        </>
      ) : (
        <p className="text-sm text-muted">Tap a swatch to copy its hex value.</p>
      )}
    </ToolPanel>
  );
}

export function ImageWatermarkTool() {
  const photo = useSource();
  const mark = useSource();
  const [text, setText] = useState("Datum");
  const [pos, setPos] = useState("br");
  const [size, setSize] = useState(6);
  const [opacity, setOpacity] = useState(0.55);
  const [fill, setFill] = useState("#faf8f3");
  const [stroke, setStroke] = useState("#1a1916");
  const [angle, setAngle] = useState(0);
  const [tile, setTile] = useState(false);
  const [useStroke, setUseStroke] = useState(true);
  const { url, setBlob } = useBlobUrl();

  useEffect(() => {
    if (!photo.source) return;
    const img = photo.source.img;
    const { canvas, ctx } = makeCanvas(img.naturalWidth, img.naturalHeight);
    ctx.drawImage(img, 0, 0);
    ctx.save();
    ctx.globalAlpha = opacity;
    const minSide = Math.min(canvas.width, canvas.height);
    const px = Math.max(12, Math.round((minSide * size) / 100));
    const pad = Math.round(px * 0.8);

    const drawMark = (x: number, y: number, rot: number) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate((rot * Math.PI) / 180);
      if (mark.source) {
        const mw = (minSide * size) / 20;
        const mh = (mw * mark.source.img.naturalHeight) / mark.source.img.naturalWidth;
        ctx.drawImage(mark.source.img, -mw / 2, -mh / 2, mw, mh);
      } else {
        ctx.font = `600 ${px}px "Sora", system-ui, sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        if (useStroke) {
          ctx.lineWidth = Math.max(1, px * 0.08);
          ctx.strokeStyle = stroke;
          ctx.strokeText(text || " ", 0, 0);
        }
        ctx.fillStyle = fill;
        ctx.fillText(text || " ", 0, 0);
      }
      ctx.restore();
    };

    if (tile) {
      const step = Math.max(80, px * 6);
      for (let y = step / 2; y < canvas.height + step; y += step) {
        for (let x = step / 2; x < canvas.width + step; x += step) {
          drawMark(x, y, angle || -24);
        }
      }
    } else {
      const x =
        pos === "tl" || pos === "bl"
          ? pad + px
          : pos === "tr" || pos === "br"
            ? canvas.width - pad - px
            : canvas.width / 2;
      const y =
        pos === "tl" || pos === "tr"
          ? pad + px
          : pos === "bl" || pos === "br"
            ? canvas.height - pad - px
            : canvas.height / 2;
      drawMark(x, y, angle);
    }
    ctx.restore();
    void canvasToBlob(canvas, "image/png").then(setBlob);
  }, [photo.source, mark.source, text, pos, size, opacity, fill, stroke, angle, tile, useStroke, setBlob]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <FilePick onFile={photo.onFile} inputId="wm-photo" />
      {photo.error ? <p className="text-sm text-danger">{photo.error}</p> : null}
      <Field label="Text" htmlFor="wm-t">
        <Input id="wm-t" value={text} onChange={(e) => setText(e.target.value)} />
      </Field>
      <Choice
        value={pos}
        onChange={setPos}
        options={[
          { id: "tl", label: "Top left" },
          { id: "tr", label: "Top right" },
          { id: "c", label: "Center" },
          { id: "bl", label: "Bottom left" },
          { id: "br", label: "Bottom right" },
        ]}
      />
      <Field label={`Size · ${size}%`}>
        <Slider min={2} max={18} step={1} value={[size]} onValueChange={(v) => setSize(v[0] ?? 6)} />
      </Field>
      <Field label={`Opacity · ${Math.round(opacity * 100)}%`}>
        <Slider min={0.12} max={1} step={0.01} value={[opacity]} onValueChange={(v) => setOpacity(v[0] ?? 0.55)} />
      </Field>
      <Advanced>
        <FilePick onFile={mark.onFile} label="Logo (optional)" inputId="wm-mark" hint="Use a PNG with transparency." />
        <SwitchRow id="wm-tile" label="Repeat across the photo" checked={tile} onCheckedChange={setTile} />
        <Field label={`Rotation · ${angle}°`}>
          <Slider min={-90} max={90} step={1} value={[angle]} onValueChange={(v) => setAngle(v[0] ?? 0)} />
        </Field>
        <SwitchRow id="wm-stroke" label="Text outline" checked={useStroke} onCheckedChange={setUseStroke} />
        <ToolForm>
          <ColorField id="wm-c" label="Fill" value={fill} onChange={setFill} />
          <ColorField id="wm-s" label="Outline" value={stroke} onChange={setStroke} />
        </ToolForm>
      </Advanced>
      {url && photo.source ? (
        <>
          <CompareFrame before={photo.source.url} after={url} />
          <DownloadLink href={url} name={`${stem(photo.source.file.name)}-mark.png`} />
        </>
      ) : null}
    </ToolPanel>
  );
}

export function ImagePlaceholderTool() {
  const [w, setW] = useState("1200");
  const [h, setH] = useState("630");
  const [bg, setBg] = useState("#24554e");
  const [fg, setFg] = useState("#faf8f3");
  const [label, setLabel] = useState("");
  const [sub, setSub] = useState("");
  const [pattern, setPattern] = useState<"solid" | "grid" | "checker">("solid");
  const [retina, setRetina] = useState(false);
  const [format, setFormat] = useState<MimeKey>("png");
  const { url, setBlob } = useBlobUrl();

  const width = Math.max(1, Math.min(4000, Math.round(parseNumeric(w) ?? 0)));
  const height = Math.max(1, Math.min(4000, Math.round(parseNumeric(h) ?? 0)));
  const caption = label.trim() || `${width} × ${height}`;
  const scale = retina ? 2 : 1;

  useEffect(() => {
    if (!width || !height) return;
    const cw = width * scale;
    const ch = height * scale;
    const { canvas, ctx } = makeCanvas(cw, ch);
    fillColor(ctx, bg, cw, ch);
    if (pattern === "grid") {
      ctx.strokeStyle = fg;
      ctx.globalAlpha = 0.18;
      ctx.lineWidth = scale;
      const step = 48 * scale;
      for (let x = 0; x <= cw; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, ch);
        ctx.stroke();
      }
      for (let y = 0; y <= ch; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(cw, y);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }
    if (pattern === "checker") {
      const cell = 32 * scale;
      ctx.fillStyle = fg;
      ctx.globalAlpha = 0.12;
      for (let y = 0; y < ch; y += cell) {
        for (let x = 0; x < cw; x += cell) {
          if (((x / cell) + (y / cell)) % 2 === 0) ctx.fillRect(x, y, cell, cell);
        }
      }
      ctx.globalAlpha = 1;
    }
    ctx.fillStyle = fg;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const px = Math.max(14, Math.round(Math.min(cw, ch) / 12));
    ctx.font = `600 ${px}px "Sora", system-ui, sans-serif`;
    ctx.fillText(caption, cw / 2, ch / 2 - (sub.trim() ? px * 0.4 : 0));
    if (sub.trim()) {
      ctx.font = `500 ${Math.round(px * 0.45)}px "Sora", system-ui, sans-serif`;
      ctx.globalAlpha = 0.8;
      ctx.fillText(sub.trim(), cw / 2, ch / 2 + px * 0.55);
      ctx.globalAlpha = 1;
    }
    void canvasToBlob(canvas, MIME[format], 0.92).then(setBlob);
  }, [width, height, bg, fg, caption, sub, pattern, scale, format, setBlob]);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <ToolForm>
        <Field label="Width (px)" htmlFor="ph-w">
          <Input id="ph-w" inputMode="numeric" value={w} onChange={(e) => setW(e.target.value)} />
        </Field>
        <Field label="Height (px)" htmlFor="ph-h">
          <Input id="ph-h" inputMode="numeric" value={h} onChange={(e) => setH(e.target.value)} />
        </Field>
      </ToolForm>
      <Field label="Label" htmlFor="ph-l">
        <Input id="ph-l" value={label} onChange={(e) => setLabel(e.target.value)} placeholder={`${width} × ${height}`} />
      </Field>
      <Choice
        value={pattern}
        onChange={(id) => setPattern(id as typeof pattern)}
        options={[
          { id: "solid", label: "Solid" },
          { id: "grid", label: "Grid" },
          { id: "checker", label: "Checker" },
        ]}
      />
      <ToolForm>
        <ColorField id="ph-bg" label="Background" value={bg} onChange={setBg} />
        <ColorField id="ph-fg" label="Ink" value={fg} onChange={setFg} />
      </ToolForm>
      <div className="flex flex-wrap gap-2">
        {[
          { w: 1200, h: 630, label: "OG card" },
          { w: 1080, h: 1080, label: "Square" },
          { w: 1080, h: 1920, label: "Story" },
          { w: 16, h: 16, label: "Favicon" },
        ].map((item) => (
          <Button
            key={item.label}
            type="button"
            size="sm"
            variant="secondary"
            onClick={() => {
              setW(String(item.w));
              setH(String(item.h));
            }}
          >
            {item.label}
          </Button>
        ))}
      </div>
      <Advanced>
        <Field label="Subtitle" htmlFor="ph-s">
          <Input id="ph-s" value={sub} onChange={(e) => setSub(e.target.value)} />
        </Field>
        <SwitchRow id="ph-2x" label="Retina @2x" checked={retina} onCheckedChange={setRetina} />
        <Choice value={format} onChange={(id) => setFormat(id as MimeKey)} options={FORMAT_OPTIONS} />
      </Advanced>
      {url ? (
        <>
          <Preview src={url} alt="Placeholder preview" />
          <DownloadLink
            href={url}
            name={`placeholder-${width}x${height}${retina ? "@2x" : ""}.${extFor(MIME[format])}`}
          />
        </>
      ) : null}
    </ToolPanel>
  );
}
