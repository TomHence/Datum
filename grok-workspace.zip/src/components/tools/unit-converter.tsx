import { useMemo, useState } from "react";
import { ArrowLeftRight } from "lucide-react";
import {
  convertLinear,
  fromKelvin,
  toKelvin,
  unitCategories,
  type LinearUnit,
} from "@/lib/units";
import { formatNumber, parseNumeric } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Field,
  ResultPanel,
  ResultRow,
  ToolForm,
  ToolPanel,
} from "@/components/tools/shared";

export function UnitConverterTool() {
  const [categoryId, setCategoryId] = useState(unitCategories[0].id);
  const category = unitCategories.find((item) => item.id === categoryId) ?? unitCategories[0];
  const [fromId, setFromId] = useState(category.units[0].id);
  const [toId, setToId] = useState(category.units[1]?.id ?? category.units[0].id);
  const [raw, setRaw] = useState("1");

  const onCategory = (id: string) => {
    const next = unitCategories.find((item) => item.id === id) ?? unitCategories[0];
    setCategoryId(next.id);
    setFromId(next.units[0].id);
    setToId(next.units[1]?.id ?? next.units[0].id);
  };

  const value = parseNumeric(raw);

  const result = useMemo(() => {
    if (value === null) return null;
    if (category.kind === "temperature") {
      return fromKelvin(toKelvin(value, fromId), toId);
    }
    const from = category.units.find((unit) => unit.id === fromId) as LinearUnit | undefined;
    const to = category.units.find((unit) => unit.id === toId) as LinearUnit | undefined;
    if (!from || !to) return null;
    return convertLinear(value, from, to);
  }, [value, category, fromId, toId]);

  const fromUnit = category.units.find((unit) => unit.id === fromId);
  const toUnit = category.units.find((unit) => unit.id === toId);

  return (
    <ToolPanel className="flex flex-col gap-4">
      <Field label="Category">
        <Select value={categoryId} onValueChange={onCategory}>
          <SelectTrigger aria-label="Unit category">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {unitCategories.map((item) => (
              <SelectItem key={item.id} value={item.id}>
                {item.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </Field>
      <ToolForm>
        <Field label="From" htmlFor="unit-from-value">
          <Input
            id="unit-from-value"
            inputMode="decimal"
            value={raw}
            onChange={(e) => setRaw(e.target.value)}
          />
        </Field>
        <Field label="From unit">
          <Select value={fromId} onValueChange={setFromId}>
            <SelectTrigger aria-label="From unit">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {category.units.map((unit) => (
                <SelectItem key={unit.id} value={unit.id}>
                  {unit.label} ({unit.symbol})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <Field label="To unit">
          <Select value={toId} onValueChange={setToId}>
            <SelectTrigger aria-label="To unit">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {category.units.map((unit) => (
                <SelectItem key={unit.id} value={unit.id}>
                  {unit.label} ({unit.symbol})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <div className="flex items-end">
          <Button
            type="button"
            variant="secondary"
            className="w-full"
            onClick={() => {
              setFromId(toId);
              setToId(fromId);
            }}
          >
            <ArrowLeftRight className="size-4" />
            Swap
          </Button>
        </div>
      </ToolForm>
      <ResultPanel>
        <ResultRow
          label={`${fromUnit?.symbol ?? ""} → ${toUnit?.symbol ?? ""}`}
          value={result === null ? "—" : `${formatNumber(result, 10)} ${toUnit?.symbol ?? ""}`}
          large
          copy
        />
      </ResultPanel>
    </ToolPanel>
  );
}
