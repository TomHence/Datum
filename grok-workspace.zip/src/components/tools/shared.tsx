import type { ReactNode } from "react";
import { Copy } from "lucide-react";
import { copyText } from "@/lib/copy";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

export function Field({
  label,
  htmlFor,
  hint,
  children,
}: {
  label: string;
  htmlFor?: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-2">
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
      {hint ? <p className="text-sm text-muted">{hint}</p> : null}
    </div>
  );
}

export function ToolPanel({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("rounded-xl bg-surface p-4 shadow-card sm:p-5", className)}>
      {children}
    </div>
  );
}

export function ResultPanel({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("rounded-sm bg-bg px-4 py-3", className)}>{children}</div>
  );
}

export function ResultRow({
  label,
  value,
  large,
  copy,
}: {
  label: string;
  value: string;
  large?: boolean;
  copy?: boolean;
}) {
  return (
    <div className="flex items-center justify-between gap-3 py-2">
      <span className="text-sm text-muted">{label}</span>
      <span className="inline-flex min-w-0 items-center gap-2">
        <span
          className={cn(
            "truncate font-medium tabular-nums text-fg",
            large && "font-display text-xl font-semibold",
          )}
        >
          {value}
        </span>
        {copy ? (
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="size-9"
            aria-label={`Copy ${label}`}
            onClick={() => void copyText(value)}
          >
            <Copy className="size-4" />
          </Button>
        ) : null}
      </span>
    </div>
  );
}

export function CopyButton({
  value,
  label = "Copy",
  className,
}: {
  value: string;
  label?: string;
  className?: string;
}) {
  return (
    <Button
      type="button"
      variant="secondary"
      className={className}
      onClick={() => void copyText(value)}
    >
      <Copy className="size-4" />
      {label}
    </Button>
  );
}

export function ToolForm({ children }: { children: ReactNode }) {
  return <div className="grid gap-4 sm:grid-cols-2">{children}</div>;
}
