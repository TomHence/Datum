import { Link } from "@tanstack/react-router";
import { popularTools } from "@/lib/catalog";
import { Button } from "@/components/ui/button";

export function NotFound() {
  return (
    <main className="mx-auto flex max-w-3xl flex-col gap-6 px-4 py-20">
      <p className="drawing-label">404 / Not found</p>
      <h1 className="font-display text-3xl font-semibold tracking-tight">
        That page is not on the drawing.
      </h1>
      <p className="max-w-xl text-muted">
        The link may be mistyped, or the tool may have moved. Try the catalog or
        one of these frequently used tools.
      </p>
      <div className="flex flex-wrap gap-3">
        <Button asChild>
          <Link to="/tools">All tools</Link>
        </Button>
        <Button asChild variant="secondary">
          <Link to="/">Home</Link>
        </Button>
      </div>
      <ul className="grid gap-2 sm:grid-cols-2">
        {popularTools().map((tool) => (
          <li key={tool.slug}>
            <Link
              to="/tools/$slug"
              params={{ slug: tool.slug }}
              className="block rounded-lg bg-surface px-4 py-3 shadow-card hover:shadow-card-hover"
            >
              <span className="font-medium">{tool.name}</span>
              <span className="mt-1 block text-sm text-muted">
                {tool.description}
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </main>
  );
}
