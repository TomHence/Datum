import { i as __toESM } from "./_runtime.mjs";
import { a as relatedTools, n as getCategory } from "./_ssr/catalog-DkD8-adi.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "./_libs/@radix-ui/react-collection+[...].mjs";
import { G as Copy, X as Check, Y as ChevronDown, f as Star, rt as ArrowLeftRight } from "./_libs/lucide-react.mjs";
import { y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { a as SelectItemIndicator, c as SelectTrigger$1, i as SelectItem$1, l as SelectValue$1, n as SelectContent$1, o as SelectItemText, r as SelectIcon, s as SelectPortal, t as Select$1, u as SelectViewport } from "./_libs/@radix-ui/react-select+[...].mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { c as cn, i as Button, n as Route, o as AdSlot } from "./_ssr/router-CWhg0SXy.mjs";
import { n as useToolPrefs, t as JsonLd } from "./_ssr/json-ld-D9LX57pF.mjs";
import { n as ToolCard, t as Input } from "./_ssr/input-CNtvLvgh.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "./_libs/radix-ui__react-tabs.mjs";
import { t as Root } from "./_libs/radix-ui__react-label.mjs";
import { n as renderSVG, t as encode } from "./_libs/uqr.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "./_libs/radix-ui__react-slider.mjs";
import { n as SwitchThumb, t as Switch$1 } from "./_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-DAjE321S.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var initial = {
	display: "0",
	acc: null,
	op: null,
	seeded: false
};
function apply(op, a, b) {
	if (op === "+") return a + b;
	if (op === "-") return a - b;
	if (op === "*") return a * b;
	if (b === 0) return NaN;
	return a / b;
}
function formatDisplay(n) {
	if (!Number.isFinite(n)) return "Error";
	const asStr = n.toPrecision(10).replace(/\.?0+$/, "");
	return asStr.length > 14 ? n.toExponential(6) : String(Number(asStr));
}
var keys = [
	{
		id: "ac",
		label: "AC",
		kind: "fn"
	},
	{
		id: "sign",
		label: "±",
		kind: "fn"
	},
	{
		id: "pct",
		label: "%",
		kind: "fn"
	},
	{
		id: "/",
		label: "÷",
		kind: "op"
	},
	{
		id: "7",
		label: "7",
		kind: "num"
	},
	{
		id: "8",
		label: "8",
		kind: "num"
	},
	{
		id: "9",
		label: "9",
		kind: "num"
	},
	{
		id: "*",
		label: "×",
		kind: "op"
	},
	{
		id: "4",
		label: "4",
		kind: "num"
	},
	{
		id: "5",
		label: "5",
		kind: "num"
	},
	{
		id: "6",
		label: "6",
		kind: "num"
	},
	{
		id: "-",
		label: "−",
		kind: "op"
	},
	{
		id: "1",
		label: "1",
		kind: "num"
	},
	{
		id: "2",
		label: "2",
		kind: "num"
	},
	{
		id: "3",
		label: "3",
		kind: "num"
	},
	{
		id: "+",
		label: "+",
		kind: "op"
	},
	{
		id: "0",
		label: "0",
		kind: "num"
	},
	{
		id: ".",
		label: ".",
		kind: "num"
	},
	{
		id: "back",
		label: "⌫",
		kind: "fn"
	},
	{
		id: "=",
		label: "=",
		kind: "eq"
	}
];
function CalculatorTool() {
	const [state, setState] = (0, import_react.useState)(initial);
	const press = (0, import_react.useCallback)((id) => {
		setState((prev) => {
			if (id === "ac") return initial;
			if (prev.display === "Error" && id !== "ac") return initial;
			if (id === "back") {
				if (prev.seeded) return {
					...prev,
					display: "0",
					seeded: true
				};
				const next = prev.display.slice(0, -1);
				return {
					...prev,
					display: next === "" || next === "-" ? "0" : next
				};
			}
			if (id === "sign") {
				if (prev.display === "0") return prev;
				const next = prev.display.startsWith("-") ? prev.display.slice(1) : `-${prev.display}`;
				return {
					...prev,
					display: next
				};
			}
			if (id === "pct") {
				const n = Number(prev.display) / 100;
				return {
					...prev,
					display: formatDisplay(n),
					seeded: true
				};
			}
			if (id === ".") {
				if (prev.seeded) return {
					...prev,
					display: "0.",
					seeded: false
				};
				if (prev.display.includes(".")) return prev;
				return {
					...prev,
					display: `${prev.display}.`
				};
			}
			if (/^\d$/.test(id)) {
				if (prev.seeded || prev.display === "0") return {
					...prev,
					display: id,
					seeded: false
				};
				if (prev.display.replace("-", "").replace(".", "").length >= 12) return prev;
				return {
					...prev,
					display: `${prev.display}${id}`
				};
			}
			const current = Number(prev.display);
			if (id === "=") {
				if (prev.op && prev.acc !== null) return {
					display: formatDisplay(apply(prev.op, prev.acc, current)),
					acc: null,
					op: null,
					seeded: true
				};
				return {
					...prev,
					seeded: true
				};
			}
			if (id === "+" || id === "-" || id === "*" || id === "/") {
				if (prev.op && prev.acc !== null && !prev.seeded) {
					const result = apply(prev.op, prev.acc, current);
					return {
						display: formatDisplay(result),
						acc: result,
						op: id,
						seeded: true
					};
				}
				return {
					...prev,
					acc: current,
					op: id,
					seeded: true
				};
			}
			return prev;
		});
	}, []);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			const target = event.target;
			if (target && ["INPUT", "TEXTAREA"].includes(target.tagName)) return;
			const key = event.key;
			if (key === "Enter" || key === "=") {
				event.preventDefault();
				press("=");
				return;
			}
			if (key === "Escape") {
				press("ac");
				return;
			}
			if (key === "Backspace") {
				press("back");
				return;
			}
			if (key === "%") {
				press("pct");
				return;
			}
			if (key === ".") {
				press(".");
				return;
			}
			if ([
				"+",
				"-",
				"*",
				"/"
			].includes(key)) {
				event.preventDefault();
				press(key);
				return;
			}
			if (/^\d$/.test(key)) press(key);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [press]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto w-full max-w-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl bg-surface p-4 shadow-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 rounded-sm bg-bg px-4 py-5 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "drawing-label mb-2 h-4",
						children: state.op ? `${formatDisplay(state.acc ?? 0)} ${state.op}` : "Ready"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl font-semibold tracking-tight tabular-nums break-all",
						children: state.display
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-4 gap-2",
					children: keys.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => press(key.id),
						className: cn("h-14 rounded-md text-lg font-medium transition-[background-color,transform] duration-150 active:scale-[0.98]", key.id === "0" && "col-span-1", key.kind === "num" && "bg-elevated text-fg shadow-card", key.kind === "fn" && "bg-bg text-muted", key.kind === "op" && "bg-bg text-accent", key.kind === "eq" && "bg-accent text-accent-fg"),
						children: key.label
					}, key.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-center text-xs text-subtle",
					children: "Keyboard: digits, operators, Enter, Esc, Backspace"
				})
			]
		})
	});
}
function formatNumber(n, maxDigits = 8) {
	if (!Number.isFinite(n)) return "—";
	return new Intl.NumberFormat("en-US", { maximumFractionDigits: maxDigits }).format(n);
}
function formatFixed(n, digits = 2) {
	if (!Number.isFinite(n)) return "—";
	return new Intl.NumberFormat("en-US", {
		minimumFractionDigits: digits,
		maximumFractionDigits: digits
	}).format(n);
}
function clampNumber(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function parseNumeric(raw) {
	const trimmed = raw.trim().replace(/,/g, "");
	if (!trimmed) return null;
	const n = Number(trimmed);
	return Number.isFinite(n) ? n : null;
}
function formatBytes(n) {
	if (!Number.isFinite(n) || n < 0) return "—";
	if (n < 1024) return `${n} B`;
	if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`;
	return `${(n / 1048576).toFixed(2)} MB`;
}
function Tabs({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root2, {
		className: cn("flex flex-col gap-4", className),
		...props
	});
}
function TabsList({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
		className: cn("inline-flex h-11 w-fit flex-wrap items-center gap-1 rounded-lg bg-bg p-1 shadow-card", className),
		...props
	});
}
function TabsTrigger({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
		className: cn("inline-flex min-h-9 items-center justify-center rounded-md px-3 text-sm font-medium text-muted transition-colors duration-150 data-[state=active]:bg-elevated data-[state=active]:text-fg data-[state=active]:shadow-card", className),
		...props
	});
}
function TabsContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
		className: cn("outline-none", className),
		...props
	});
}
async function copyText(text, success = "Copied") {
	try {
		await navigator.clipboard.writeText(text);
		toast.success(success);
		return true;
	} catch {
		toast.error("Could not copy");
		return false;
	}
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
		className: cn("text-sm font-medium text-fg", className),
		...props
	});
}
function Field({ label, htmlFor, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor,
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: hint
			}) : null
		]
	});
}
function ToolPanel({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-xl bg-surface p-4 shadow-card sm:p-5", className),
		children
	});
}
function ResultPanel({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-sm bg-bg px-4 py-3", className),
		children
	});
}
function ResultRow({ label, value, large, copy }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "inline-flex min-w-0 items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("truncate font-medium tabular-nums text-fg", large && "font-display text-xl font-semibold"),
				children: value
			}), copy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon",
				className: "size-9",
				"aria-label": `Copy ${label}`,
				onClick: () => void copyText(value),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
			}) : null]
		})]
	});
}
function CopyButton({ value, label = "Copy", className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		type: "button",
		variant: "secondary",
		className,
		onClick: () => void copyText(value),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), label]
	});
}
function ToolForm({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-4 sm:grid-cols-2",
		children
	});
}
function useAmount(initial = "") {
	const [raw, setRaw] = (0, import_react.useState)(initial);
	return {
		raw,
		setRaw,
		value: parseNumeric(raw)
	};
}
function PercentageTool() {
	const [mode, setMode] = (0, import_react.useState)("of");
	const a = useAmount("25");
	const b = useAmount("200");
	const result = (0, import_react.useMemo)(() => {
		if (a.value === null || b.value === null) return null;
		if (mode === "of") return a.value / 100 * b.value;
		if (mode === "is") return b.value === 0 ? null : a.value / b.value * 100;
		return b.value === 0 ? null : (a.value - b.value) / b.value * 100;
	}, [
		a.value,
		b.value,
		mode
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
		value: mode,
		onValueChange: setMode,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
				value: "of",
				children: "X% of Y"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
				value: "is",
				children: "X is what % of Y"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
				value: "change",
				children: "Percent change"
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
			value: mode,
			className: "flex flex-col gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: mode === "of" ? "Percent" : mode === "is" ? "Value" : "New value",
				htmlFor: "pct-a",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "pct-a",
					inputMode: "decimal",
					value: a.raw,
					onChange: (e) => a.setRaw(e.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: mode === "of" ? "Of number" : mode === "is" ? "Whole" : "Original value",
				htmlFor: "pct-b",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "pct-b",
					inputMode: "decimal",
					value: b.raw,
					onChange: (e) => b.setRaw(e.target.value)
				})
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: mode === "of" ? "Result" : mode === "is" ? "Percentage" : "Change",
				value: result === null ? "—" : mode === "of" ? formatFixed(result, 4) : `${formatFixed(result, 4)}%`,
				large: true,
				copy: true
			}) })]
		})]
	}) });
}
function TipCalculatorTool() {
	const bill = useAmount("86.40");
	const tip = useAmount("18");
	const people = useAmount("3");
	const math = (0, import_react.useMemo)(() => {
		if (bill.value === null || tip.value === null || people.value === null) return null;
		if (people.value <= 0) return null;
		const tipAmount = bill.value * tip.value / 100;
		const total = bill.value + tipAmount;
		return {
			tipAmount,
			total,
			perPerson: total / people.value
		};
	}, [
		bill.value,
		tip.value,
		people.value
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Bill amount",
				htmlFor: "tip-bill",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "tip-bill",
					inputMode: "decimal",
					value: bill.raw,
					onChange: (e) => bill.setRaw(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tip percent",
				htmlFor: "tip-pct",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "tip-pct",
					inputMode: "decimal",
					value: tip.raw,
					onChange: (e) => tip.setRaw(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "People",
				htmlFor: "tip-people",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "tip-people",
					inputMode: "numeric",
					value: people.raw,
					onChange: (e) => people.setRaw(e.target.value)
				})
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Tip",
				value: math ? formatFixed(math.tipAmount) : "—",
				copy: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Total",
				value: math ? formatFixed(math.total) : "—",
				large: true,
				copy: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Per person",
				value: math ? formatFixed(math.perPerson) : "—",
				copy: true
			})
		] })]
	});
}
function DiscountCalculatorTool() {
	const price = useAmount("120");
	const off = useAmount("30");
	const math = (0, import_react.useMemo)(() => {
		if (price.value === null || off.value === null) return null;
		const saved = price.value * off.value / 100;
		return {
			saved,
			final: price.value - saved
		};
	}, [price.value, off.value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Original price",
			htmlFor: "disc-price",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: "disc-price",
				inputMode: "decimal",
				value: price.raw,
				onChange: (e) => price.setRaw(e.target.value)
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Discount percent",
			htmlFor: "disc-off",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: "disc-off",
				inputMode: "decimal",
				value: off.raw,
				onChange: (e) => off.setRaw(e.target.value)
			})
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
			label: "You save",
			value: math ? formatFixed(math.saved) : "—",
			copy: true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
			label: "Sale price",
			value: math ? formatFixed(math.final) : "—",
			large: true,
			copy: true
		})] })]
	});
}
function SplitBillTool() {
	const total = useAmount("240");
	const people = useAmount("4");
	const tax = useAmount("8");
	const tip = useAmount("10");
	const math = (0, import_react.useMemo)(() => {
		if (total.value === null || people.value === null || tax.value === null || tip.value === null) return null;
		if (people.value <= 0) return null;
		const grand = total.value * (1 + tax.value / 100) * (1 + tip.value / 100);
		return {
			grand,
			per: grand / people.value
		};
	}, [
		total.value,
		people.value,
		tax.value,
		tip.value
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Subtotal",
				htmlFor: "split-total",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "split-total",
					inputMode: "decimal",
					value: total.raw,
					onChange: (e) => total.setRaw(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "People",
				htmlFor: "split-people",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "split-people",
					inputMode: "numeric",
					value: people.raw,
					onChange: (e) => people.setRaw(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tax percent",
				htmlFor: "split-tax",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "split-tax",
					inputMode: "decimal",
					value: tax.raw,
					onChange: (e) => tax.setRaw(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tip percent",
				htmlFor: "split-tip",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "split-tip",
					inputMode: "decimal",
					value: tip.raw,
					onChange: (e) => tip.setRaw(e.target.value)
				})
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
			label: "Grand total",
			value: math ? formatFixed(math.grand) : "—",
			copy: true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
			label: "Each person",
			value: math ? formatFixed(math.per) : "—",
			large: true,
			copy: true
		})] })]
	});
}
function LoanCalculatorTool() {
	const principal = useAmount("250000");
	const rate = useAmount("6.5");
	const years = useAmount("30");
	const math = (0, import_react.useMemo)(() => {
		if (principal.value === null || rate.value === null || years.value === null) return null;
		const n = years.value * 12;
		if (n <= 0 || principal.value <= 0) return null;
		const r = rate.value / 100 / 12;
		const payment = r === 0 ? principal.value / n : principal.value * r * (1 + r) ** n / ((1 + r) ** n - 1);
		const total = payment * n;
		return {
			payment,
			total,
			interest: total - principal.value,
			n
		};
	}, [
		principal.value,
		rate.value,
		years.value
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Loan amount",
				htmlFor: "loan-p",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "loan-p",
					inputMode: "decimal",
					value: principal.raw,
					onChange: (e) => principal.setRaw(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Annual rate (%)",
				htmlFor: "loan-r",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "loan-r",
					inputMode: "decimal",
					value: rate.raw,
					onChange: (e) => rate.setRaw(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Term (years)",
				htmlFor: "loan-y",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "loan-y",
					inputMode: "decimal",
					value: years.raw,
					onChange: (e) => years.setRaw(e.target.value)
				})
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Monthly payment",
				value: math ? formatFixed(math.payment) : "—",
				large: true,
				copy: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Total paid",
				value: math ? formatFixed(math.total) : "—",
				copy: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Total interest",
				value: math ? formatFixed(math.interest) : "—",
				copy: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Payments",
				value: math ? String(math.n) : "—"
			})
		] })]
	});
}
function CompoundInterestTool() {
	const principal = useAmount("10000");
	const rate = useAmount("7");
	const years = useAmount("10");
	const monthly = useAmount("200");
	const [freq, setFreq] = (0, import_react.useState)("12");
	const math = (0, import_react.useMemo)(() => {
		if (principal.value === null || rate.value === null || years.value === null || monthly.value === null) return null;
		const n = Number(freq);
		const t = years.value;
		const r = rate.value / 100;
		if (n <= 0 || t < 0) return null;
		const compound = principal.value * (1 + r / n) ** (n * t);
		const contrib = monthly.value === 0 ? 0 : monthly.value * (((1 + r / 12) ** (12 * t) - 1) / (r / 12 || 1));
		const future = compound + (r === 0 ? monthly.value * 12 * t : contrib);
		const invested = principal.value + monthly.value * 12 * t;
		return {
			future,
			invested,
			gained: future - invested
		};
	}, [
		principal.value,
		rate.value,
		years.value,
		monthly.value,
		freq
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Principal",
				htmlFor: "ci-p",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "ci-p",
					inputMode: "decimal",
					value: principal.raw,
					onChange: (e) => principal.setRaw(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Annual rate (%)",
				htmlFor: "ci-r",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "ci-r",
					inputMode: "decimal",
					value: rate.raw,
					onChange: (e) => rate.setRaw(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Years",
				htmlFor: "ci-y",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "ci-y",
					inputMode: "decimal",
					value: years.raw,
					onChange: (e) => years.setRaw(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Monthly addition",
				htmlFor: "ci-m",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "ci-m",
					inputMode: "decimal",
					value: monthly.raw,
					onChange: (e) => monthly.setRaw(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Compounds per year",
				htmlFor: "ci-f",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "ci-f",
					inputMode: "numeric",
					value: freq,
					onChange: (e) => setFreq(e.target.value)
				})
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Future value",
				value: math ? formatFixed(math.future) : "—",
				large: true,
				copy: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Amount invested",
				value: math ? formatFixed(math.invested) : "—",
				copy: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Interest earned",
				value: math ? formatFixed(math.gained) : "—",
				copy: true
			})
		] })]
	});
}
function VatCalculatorTool() {
	const amount = useAmount("100");
	const rate = useAmount("20");
	const [mode, setMode] = (0, import_react.useState)("add");
	const math = (0, import_react.useMemo)(() => {
		if (amount.value === null || rate.value === null || rate.value < 0) return null;
		const r = rate.value / 100;
		if (mode === "add") {
			const tax = amount.value * r;
			return {
				net: amount.value,
				tax,
				gross: amount.value + tax
			};
		}
		const gross = amount.value;
		const net = gross / (1 + r);
		return {
			net,
			tax: gross - net,
			gross
		};
	}, [
		amount.value,
		rate.value,
		mode
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
				value: mode,
				onValueChange: setMode,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
					value: "add",
					children: "Add tax"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
					value: "extract",
					children: "Tax included"
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: mode === "add" ? "Net amount" : "Gross amount",
				htmlFor: "vat-a",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "vat-a",
					inputMode: "decimal",
					value: amount.raw,
					onChange: (e) => amount.setRaw(e.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Tax rate (%)",
				htmlFor: "vat-r",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "vat-r",
					inputMode: "decimal",
					value: rate.raw,
					onChange: (e) => rate.setRaw(e.target.value)
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Net",
					value: math ? formatFixed(math.net) : "—",
					copy: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Tax",
					value: math ? formatFixed(math.tax) : "—",
					copy: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Gross",
					value: math ? formatFixed(math.gross) : "—",
					large: true,
					copy: true
				})
			] })
		]
	});
}
function SalaryConverterTool() {
	const [basis, setBasis] = (0, import_react.useState)("yearly");
	const amount = useAmount("72000");
	const hours = useAmount("40");
	const weeks = useAmount("52");
	const math = (0, import_react.useMemo)(() => {
		if (amount.value === null || hours.value === null || weeks.value === null) return null;
		if (hours.value <= 0 || weeks.value <= 0) return null;
		const yearHours = hours.value * weeks.value;
		let yearly = amount.value;
		if (basis === "hourly") yearly = amount.value * yearHours;
		if (basis === "monthly") yearly = amount.value * 12;
		return {
			hourly: yearly / yearHours,
			monthly: yearly / 12,
			yearly,
			weekly: yearly / weeks.value
		};
	}, [
		amount.value,
		hours.value,
		weeks.value,
		basis
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "I know",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						"hourly",
						"monthly",
						"yearly"
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "sm",
						variant: basis === item ? "default" : "secondary",
						onClick: () => setBasis(item),
						children: item
					}, item))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `Amount (${basis})`,
				htmlFor: "sal-a",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "sal-a",
					inputMode: "decimal",
					value: amount.raw,
					onChange: (e) => amount.setRaw(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Hours per week",
				htmlFor: "sal-h",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "sal-h",
					inputMode: "decimal",
					value: hours.raw,
					onChange: (e) => hours.setRaw(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Weeks per year",
				htmlFor: "sal-w",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "sal-w",
					inputMode: "decimal",
					value: weeks.raw,
					onChange: (e) => weeks.setRaw(e.target.value)
				})
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Hourly",
				value: math ? formatFixed(math.hourly) : "—",
				copy: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Weekly",
				value: math ? formatFixed(math.weekly) : "—",
				copy: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Monthly",
				value: math ? formatFixed(math.monthly) : "—",
				copy: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Yearly",
				value: math ? formatFixed(math.yearly) : "—",
				large: true,
				copy: true
			})
		] })]
	});
}
function FuelCostTool() {
	const distance = useAmount("320");
	const economy = useAmount("7.4");
	const price = useAmount("1.65");
	const [unit, setUnit] = (0, import_react.useState)("metric");
	const math = (0, import_react.useMemo)(() => {
		if (distance.value === null || economy.value === null || price.value === null) return null;
		if (distance.value < 0 || economy.value <= 0 || price.value < 0) return null;
		if (unit === "metric") {
			const litres = economy.value / 100 * distance.value;
			return {
				fuel: litres,
				cost: litres * price.value,
				fuelLabel: "Litres",
				distLabel: "km"
			};
		}
		const gallons = distance.value / economy.value;
		return {
			fuel: gallons,
			cost: gallons * price.value,
			fuelLabel: "Gallons",
			distLabel: "miles"
		};
	}, [
		distance.value,
		economy.value,
		price.value,
		unit
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					size: "sm",
					variant: unit === "metric" ? "default" : "secondary",
					onClick: () => setUnit("metric"),
					children: "L / 100 km"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					size: "sm",
					variant: unit === "us" ? "default" : "secondary",
					onClick: () => setUnit("us"),
					children: "MPG"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: unit === "metric" ? "Distance (km)" : "Distance (miles)",
					htmlFor: "fuel-d",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "fuel-d",
						inputMode: "decimal",
						value: distance.raw,
						onChange: (e) => distance.setRaw(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: unit === "metric" ? "L / 100 km" : "Miles per gallon",
					htmlFor: "fuel-e",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "fuel-e",
						inputMode: "decimal",
						value: economy.raw,
						onChange: (e) => economy.setRaw(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: unit === "metric" ? "Price per litre" : "Price per gallon",
					htmlFor: "fuel-p",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "fuel-p",
						inputMode: "decimal",
						value: price.raw,
						onChange: (e) => price.setRaw(e.target.value)
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: math?.fuelLabel ?? "Fuel",
				value: math ? formatFixed(math.fuel, 3) : "—",
				copy: true
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Trip cost",
				value: math ? formatFixed(math.cost) : "—",
				large: true,
				copy: true
			})] })
		]
	});
}
function Badge({ className, tone = "muted", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium", tone === "muted" && "bg-bg text-muted", tone === "accent" && "bg-accent text-accent-fg", tone === "ok" && "bg-ok/10 text-ok", tone === "warn" && "bg-warn/10 text-warn", tone === "danger" && "bg-danger/10 text-danger", className),
		...props
	});
}
function classify(bmi) {
	if (bmi < 18.5) return {
		label: "Underweight",
		tone: "warn"
	};
	if (bmi < 25) return {
		label: "Healthy range",
		tone: "ok"
	};
	if (bmi < 30) return {
		label: "Overweight",
		tone: "warn"
	};
	return {
		label: "Obesity range",
		tone: "danger"
	};
}
function BmiCalculatorTool() {
	const [system, setSystem] = (0, import_react.useState)("metric");
	const [cm, setCm] = (0, import_react.useState)("175");
	const [kg, setKg] = (0, import_react.useState)("70");
	const [ft, setFt] = (0, import_react.useState)("5");
	const [inch, setInch] = (0, import_react.useState)("9");
	const [lb, setLb] = (0, import_react.useState)("154");
	const bmi = (0, import_react.useMemo)(() => {
		if (system === "metric") {
			const height = parseNumeric(cm);
			const weight = parseNumeric(kg);
			if (!height || !weight) return null;
			const meters = height / 100;
			return weight / (meters * meters);
		}
		const feet = parseNumeric(ft) ?? 0;
		const inches = parseNumeric(inch) ?? 0;
		const weight = parseNumeric(lb);
		const totalIn = feet * 12 + inches;
		if (!weight || totalIn <= 0) return null;
		return weight / (totalIn * totalIn) * 703;
	}, [
		system,
		cm,
		kg,
		ft,
		inch,
		lb
	]);
	const band = bmi ? classify(bmi) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
				value: system,
				onValueChange: setSystem,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
					value: "metric",
					children: "Metric"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
					value: "imperial",
					children: "Imperial"
				})] })
			}),
			system === "metric" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Height (cm)",
				htmlFor: "bmi-cm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "bmi-cm",
					inputMode: "decimal",
					value: cm,
					onChange: (e) => setCm(e.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Weight (kg)",
				htmlFor: "bmi-kg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "bmi-kg",
					inputMode: "decimal",
					value: kg,
					onChange: (e) => setKg(e.target.value)
				})
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Height (ft)",
					htmlFor: "bmi-ft",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "bmi-ft",
						inputMode: "numeric",
						value: ft,
						onChange: (e) => setFt(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Height (in)",
					htmlFor: "bmi-in",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "bmi-in",
						inputMode: "numeric",
						value: inch,
						onChange: (e) => setInch(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Weight (lb)",
					htmlFor: "bmi-lb",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "bmi-lb",
						inputMode: "decimal",
						value: lb,
						onChange: (e) => setLb(e.target.value)
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: "BMI"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-xl font-semibold tabular-nums",
						children: bmi ? formatFixed(bmi, 1) : "—"
					})]
				}),
				band ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pt-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: band.tone,
						children: band.label
					})
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Categories follow the WHO adult ranges. This is not medical advice."
				})
			] })
		]
	});
}
var unitCategories = [
	{
		id: "length",
		label: "Length",
		kind: "linear",
		units: [
			{
				id: "nm",
				label: "Nanometer",
				symbol: "nm",
				factor: 1e-9
			},
			{
				id: "mm",
				label: "Millimeter",
				symbol: "mm",
				factor: .001
			},
			{
				id: "cm",
				label: "Centimeter",
				symbol: "cm",
				factor: .01
			},
			{
				id: "m",
				label: "Meter",
				symbol: "m",
				factor: 1
			},
			{
				id: "km",
				label: "Kilometer",
				symbol: "km",
				factor: 1e3
			},
			{
				id: "in",
				label: "Inch",
				symbol: "in",
				factor: .0254
			},
			{
				id: "ft",
				label: "Foot",
				symbol: "ft",
				factor: .3048
			},
			{
				id: "yd",
				label: "Yard",
				symbol: "yd",
				factor: .9144
			},
			{
				id: "mi",
				label: "Mile",
				symbol: "mi",
				factor: 1609.344
			},
			{
				id: "nmi",
				label: "Nautical mile",
				symbol: "nmi",
				factor: 1852
			}
		]
	},
	{
		id: "mass",
		label: "Mass",
		kind: "linear",
		units: [
			{
				id: "mg",
				label: "Milligram",
				symbol: "mg",
				factor: 1e-6
			},
			{
				id: "g",
				label: "Gram",
				symbol: "g",
				factor: .001
			},
			{
				id: "kg",
				label: "Kilogram",
				symbol: "kg",
				factor: 1
			},
			{
				id: "t",
				label: "Tonne",
				symbol: "t",
				factor: 1e3
			},
			{
				id: "oz",
				label: "Ounce",
				symbol: "oz",
				factor: .028349523125
			},
			{
				id: "lb",
				label: "Pound",
				symbol: "lb",
				factor: .45359237
			},
			{
				id: "st",
				label: "Stone",
				symbol: "st",
				factor: 6.35029318
			}
		]
	},
	{
		id: "temperature",
		label: "Temperature",
		kind: "temperature",
		units: [
			{
				id: "c",
				label: "Celsius",
				symbol: "°C"
			},
			{
				id: "f",
				label: "Fahrenheit",
				symbol: "°F"
			},
			{
				id: "k",
				label: "Kelvin",
				symbol: "K"
			}
		]
	},
	{
		id: "volume",
		label: "Volume",
		kind: "linear",
		units: [
			{
				id: "ml",
				label: "Milliliter",
				symbol: "ml",
				factor: 1e-6
			},
			{
				id: "l",
				label: "Liter",
				symbol: "l",
				factor: .001
			},
			{
				id: "m3",
				label: "Cubic meter",
				symbol: "m³",
				factor: 1
			},
			{
				id: "tsp",
				label: "Teaspoon (US)",
				symbol: "tsp",
				factor: 492892159375e-17
			},
			{
				id: "tbsp",
				label: "Tablespoon (US)",
				symbol: "tbsp",
				factor: 1478676478125e-17
			},
			{
				id: "cup",
				label: "Cup (US)",
				symbol: "cup",
				factor: .0002365882365
			},
			{
				id: "floz",
				label: "Fluid ounce (US)",
				symbol: "fl oz",
				factor: 295735295625e-16
			},
			{
				id: "pt",
				label: "Pint (US)",
				symbol: "pt",
				factor: .000473176473
			},
			{
				id: "qt",
				label: "Quart (US)",
				symbol: "qt",
				factor: .000946352946
			},
			{
				id: "gal",
				label: "Gallon (US)",
				symbol: "gal",
				factor: .003785411784
			}
		]
	},
	{
		id: "area",
		label: "Area",
		kind: "linear",
		units: [
			{
				id: "cm2",
				label: "Square centimeter",
				symbol: "cm²",
				factor: 1e-4
			},
			{
				id: "m2",
				label: "Square meter",
				symbol: "m²",
				factor: 1
			},
			{
				id: "km2",
				label: "Square kilometer",
				symbol: "km²",
				factor: 1e6
			},
			{
				id: "ha",
				label: "Hectare",
				symbol: "ha",
				factor: 1e4
			},
			{
				id: "in2",
				label: "Square inch",
				symbol: "in²",
				factor: 64516e-8
			},
			{
				id: "ft2",
				label: "Square foot",
				symbol: "ft²",
				factor: .09290304
			},
			{
				id: "yd2",
				label: "Square yard",
				symbol: "yd²",
				factor: .83612736
			},
			{
				id: "ac",
				label: "Acre",
				symbol: "ac",
				factor: 4046.8564224
			},
			{
				id: "mi2",
				label: "Square mile",
				symbol: "mi²",
				factor: 2589988.110336
			}
		]
	},
	{
		id: "speed",
		label: "Speed",
		kind: "linear",
		units: [
			{
				id: "mps",
				label: "Meters per second",
				symbol: "m/s",
				factor: 1
			},
			{
				id: "kph",
				label: "Kilometers per hour",
				symbol: "km/h",
				factor: 1e3 / 3600
			},
			{
				id: "mph",
				label: "Miles per hour",
				symbol: "mph",
				factor: 1609.344 / 3600
			},
			{
				id: "kn",
				label: "Knot",
				symbol: "kn",
				factor: 1852 / 3600
			},
			{
				id: "fps",
				label: "Feet per second",
				symbol: "ft/s",
				factor: .3048
			}
		]
	},
	{
		id: "time",
		label: "Time",
		kind: "linear",
		units: [
			{
				id: "ms",
				label: "Millisecond",
				symbol: "ms",
				factor: .001
			},
			{
				id: "s",
				label: "Second",
				symbol: "s",
				factor: 1
			},
			{
				id: "min",
				label: "Minute",
				symbol: "min",
				factor: 60
			},
			{
				id: "h",
				label: "Hour",
				symbol: "h",
				factor: 3600
			},
			{
				id: "d",
				label: "Day",
				symbol: "d",
				factor: 86400
			},
			{
				id: "wk",
				label: "Week",
				symbol: "wk",
				factor: 604800
			}
		]
	},
	{
		id: "data",
		label: "Data",
		kind: "linear",
		units: [
			{
				id: "b",
				label: "Byte",
				symbol: "B",
				factor: 1
			},
			{
				id: "kb",
				label: "Kilobyte (10³)",
				symbol: "KB",
				factor: 1e3
			},
			{
				id: "mb",
				label: "Megabyte (10⁶)",
				symbol: "MB",
				factor: 1e6
			},
			{
				id: "gb",
				label: "Gigabyte (10⁹)",
				symbol: "GB",
				factor: 1e9
			},
			{
				id: "tb",
				label: "Terabyte (10¹²)",
				symbol: "TB",
				factor: 0xe8d4a51000
			},
			{
				id: "kib",
				label: "Kibibyte (2¹⁰)",
				symbol: "KiB",
				factor: 1024
			},
			{
				id: "mib",
				label: "Mebibyte (2²⁰)",
				symbol: "MiB",
				factor: 1024 ** 2
			},
			{
				id: "gib",
				label: "Gibibyte (2³⁰)",
				symbol: "GiB",
				factor: 1024 ** 3
			},
			{
				id: "tib",
				label: "Tebibyte (2⁴⁰)",
				symbol: "TiB",
				factor: 1024 ** 4
			}
		]
	},
	{
		id: "energy",
		label: "Energy",
		kind: "linear",
		units: [
			{
				id: "j",
				label: "Joule",
				symbol: "J",
				factor: 1
			},
			{
				id: "kj",
				label: "Kilojoule",
				symbol: "kJ",
				factor: 1e3
			},
			{
				id: "cal",
				label: "Calorie",
				symbol: "cal",
				factor: 4.184
			},
			{
				id: "kcal",
				label: "Kilocalorie",
				symbol: "kcal",
				factor: 4184
			},
			{
				id: "wh",
				label: "Watt-hour",
				symbol: "Wh",
				factor: 3600
			},
			{
				id: "kwh",
				label: "Kilowatt-hour",
				symbol: "kWh",
				factor: 36e5
			},
			{
				id: "btu",
				label: "BTU",
				symbol: "BTU",
				factor: 1055.05585262
			}
		]
	},
	{
		id: "pressure",
		label: "Pressure",
		kind: "linear",
		units: [
			{
				id: "pa",
				label: "Pascal",
				symbol: "Pa",
				factor: 1
			},
			{
				id: "kpa",
				label: "Kilopascal",
				symbol: "kPa",
				factor: 1e3
			},
			{
				id: "bar",
				label: "Bar",
				symbol: "bar",
				factor: 1e5
			},
			{
				id: "psi",
				label: "PSI",
				symbol: "psi",
				factor: 6894.757293168
			},
			{
				id: "atm",
				label: "Atmosphere",
				symbol: "atm",
				factor: 101325
			},
			{
				id: "mmhg",
				label: "mmHg",
				symbol: "mmHg",
				factor: 133.322387415
			}
		]
	}
];
function toKelvin(value, from) {
	if (from === "c") return value + 273.15;
	if (from === "f") return (value - 32) * 5 / 9 + 273.15;
	return value;
}
function fromKelvin(kelvin, to) {
	if (to === "c") return kelvin - 273.15;
	if (to === "f") return (kelvin - 273.15) * 9 / 5 + 32;
	return kelvin;
}
function convertLinear(value, from, to) {
	return value * from.factor / to.factor;
}
function Select({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select$1, { ...props });
}
function SelectValue({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue$1, { ...props });
}
function SelectTrigger({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectTrigger$1, {
		className: cn("flex h-11 w-full items-center justify-between gap-2 rounded-md bg-elevated px-3 text-sm text-fg shadow-card transition-[box-shadow] duration-150 data-placeholder:text-subtle focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:cursor-not-allowed disabled:opacity-50", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectIcon, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4 text-muted" })
		})]
	});
}
function SelectContent({ className, children, position = "popper", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent$1, {
		position,
		className: cn("relative z-50 max-h-72 min-w-40 overflow-hidden rounded-lg bg-elevated shadow-card", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectViewport, {
			className: "p-1",
			children
		})
	}) });
}
function SelectItem({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem$1, {
		className: cn("relative flex w-full cursor-pointer items-center rounded-md py-2 pr-8 pl-2 text-sm text-fg outline-none data-highlighted:bg-bg", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemText, { children }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemIndicator, {
			className: "absolute right-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-accent" })
		})]
	});
}
function UnitConverterTool() {
	const [categoryId, setCategoryId] = (0, import_react.useState)(unitCategories[0].id);
	const category = unitCategories.find((item) => item.id === categoryId) ?? unitCategories[0];
	const [fromId, setFromId] = (0, import_react.useState)(category.units[0].id);
	const [toId, setToId] = (0, import_react.useState)(category.units[1]?.id ?? category.units[0].id);
	const [raw, setRaw] = (0, import_react.useState)("1");
	const onCategory = (id) => {
		const next = unitCategories.find((item) => item.id === id) ?? unitCategories[0];
		setCategoryId(next.id);
		setFromId(next.units[0].id);
		setToId(next.units[1]?.id ?? next.units[0].id);
	};
	const value = parseNumeric(raw);
	const result = (0, import_react.useMemo)(() => {
		if (value === null) return null;
		if (category.kind === "temperature") return fromKelvin(toKelvin(value, fromId), toId);
		const from = category.units.find((unit) => unit.id === fromId);
		const to = category.units.find((unit) => unit.id === toId);
		if (!from || !to) return null;
		return convertLinear(value, from, to);
	}, [
		value,
		category,
		fromId,
		toId
	]);
	const fromUnit = category.units.find((unit) => unit.id === fromId);
	const toUnit = category.units.find((unit) => unit.id === toId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Category",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: categoryId,
					onValueChange: onCategory,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						"aria-label": "Unit category",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: unitCategories.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: item.id,
						children: item.label
					}, item.id)) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "From",
					htmlFor: "unit-from-value",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "unit-from-value",
						inputMode: "decimal",
						value: raw,
						onChange: (e) => setRaw(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "From unit",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: fromId,
						onValueChange: setFromId,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							"aria-label": "From unit",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: category.units.map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
							value: unit.id,
							children: [
								unit.label,
								" (",
								unit.symbol,
								")"
							]
						}, unit.id)) })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "To unit",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: toId,
						onValueChange: setToId,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							"aria-label": "To unit",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: category.units.map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
							value: unit.id,
							children: [
								unit.label,
								" (",
								unit.symbol,
								")"
							]
						}, unit.id)) })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "secondary",
						className: "w-full",
						onClick: () => {
							setFromId(toId);
							setToId(fromId);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeftRight, { className: "size-4" }), "Swap"]
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: `${fromUnit?.symbol ?? ""} → ${toUnit?.symbol ?? ""}`,
				value: result === null ? "—" : `${formatNumber(result, 10)} ${toUnit?.symbol ?? ""}`,
				large: true,
				copy: true
			}) })
		]
	});
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function hexToRgb$1(hex) {
	const raw = hex.trim().replace("#", "");
	const full = raw.length === 3 ? raw.split("").map((ch) => ch + ch).join("") : raw;
	if (!/^[0-9a-fA-F]{6}$/.test(full)) return null;
	return {
		r: Number.parseInt(full.slice(0, 2), 16),
		g: Number.parseInt(full.slice(2, 4), 16),
		b: Number.parseInt(full.slice(4, 6), 16)
	};
}
function rgbToHex(r, g, b) {
	return `#${[
		r,
		g,
		b
	].map((n) => clamp(Math.round(n), 0, 255).toString(16).padStart(2, "0")).join("")}`;
}
function rgbToHsl$1(r, g, b) {
	const nr = r / 255;
	const ng = g / 255;
	const nb = b / 255;
	const max = Math.max(nr, ng, nb);
	const min = Math.min(nr, ng, nb);
	const l = (max + min) / 2;
	const d = max - min;
	let h = 0;
	let s = 0;
	if (d !== 0) {
		s = d / (1 - Math.abs(2 * l - 1));
		switch (max) {
			case nr:
				h = (ng - nb) / d % 6;
				break;
			case ng:
				h = (nb - nr) / d + 2;
				break;
			default: h = (nr - ng) / d + 4;
		}
		h *= 60;
		if (h < 0) h += 360;
	}
	return {
		h,
		s: s * 100,
		l: l * 100
	};
}
function relativeLuminance(r, g, b) {
	const lin = [
		r,
		g,
		b
	].map((channel) => {
		const c = channel / 255;
		return c <= .03928 ? c / 12.92 : ((c + .055) / 1.055) ** 2.4;
	});
	return .2126 * lin[0] + .7152 * lin[1] + .0722 * lin[2];
}
function contrast(r, g, b, against) {
	const l1 = relativeLuminance(r, g, b);
	const l2 = against === "white" ? 1 : 0;
	const lighter = Math.max(l1, l2);
	const darker = Math.min(l1, l2);
	return (lighter + .05) / (darker + .05);
}
function ColorConverterTool() {
	const [hex, setHex] = (0, import_react.useState)("#24554e");
	const rgb = hexToRgb$1(hex);
	const derived = (0, import_react.useMemo)(() => {
		if (!rgb) return null;
		const hsl = rgbToHsl$1(rgb.r, rgb.g, rgb.b);
		return {
			rgb: `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`,
			hsl: `hsl(${Math.round(hsl.h)} ${formatFixed(hsl.s, 1)}% ${formatFixed(hsl.l, 1)}%)`,
			hex: rgbToHex(rgb.r, rgb.g, rgb.b),
			white: contrast(rgb.r, rgb.g, rgb.b, "white"),
			black: contrast(rgb.r, rgb.g, rgb.b, "black")
		};
	}, [rgb]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-[auto_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Picker",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "color",
						value: derived?.hex ?? "#24554e",
						onChange: (e) => setHex(e.target.value),
						className: "h-11 w-16 cursor-pointer rounded-md bg-elevated shadow-card",
						"aria-label": "Color picker"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "HEX",
					htmlFor: "color-hex",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "color-hex",
						value: hex,
						onChange: (e) => setHex(e.target.value),
						spellCheck: false
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-20 rounded-sm shadow-card",
				style: { background: derived?.hex ?? "#24554e" },
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "HEX",
					value: derived?.hex ?? "Invalid",
					copy: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "RGB",
					value: derived?.rgb ?? "—",
					copy: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "HSL",
					value: derived?.hsl ?? "—",
					copy: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Contrast vs white",
					value: derived ? `${formatFixed(derived.white, 2)}:1` : "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Contrast vs black",
					value: derived ? `${formatFixed(derived.black, 2)}:1` : "—"
				})
			] })
		]
	});
}
var ZONES = [
	{
		id: "UTC",
		label: "UTC"
	},
	{
		id: "America/New_York",
		label: "New York"
	},
	{
		id: "America/Chicago",
		label: "Chicago"
	},
	{
		id: "America/Denver",
		label: "Denver"
	},
	{
		id: "America/Los_Angeles",
		label: "Los Angeles"
	},
	{
		id: "America/Sao_Paulo",
		label: "São Paulo"
	},
	{
		id: "Europe/London",
		label: "London"
	},
	{
		id: "Europe/Paris",
		label: "Paris"
	},
	{
		id: "Europe/Berlin",
		label: "Berlin"
	},
	{
		id: "Africa/Cairo",
		label: "Cairo"
	},
	{
		id: "Africa/Johannesburg",
		label: "Johannesburg"
	},
	{
		id: "Asia/Dubai",
		label: "Dubai"
	},
	{
		id: "Asia/Kolkata",
		label: "Mumbai"
	},
	{
		id: "Asia/Singapore",
		label: "Singapore"
	},
	{
		id: "Asia/Shanghai",
		label: "Shanghai"
	},
	{
		id: "Asia/Tokyo",
		label: "Tokyo"
	},
	{
		id: "Australia/Sydney",
		label: "Sydney"
	},
	{
		id: "Pacific/Auckland",
		label: "Auckland"
	}
];
function fmtZone(date, zone) {
	return new Intl.DateTimeFormat("en-GB", {
		timeZone: zone,
		dateStyle: "medium",
		timeStyle: "short",
		hour12: false
	}).format(date);
}
function UnixTimestampTool() {
	const nowSec = Math.floor(Date.now() / 1e3);
	const [raw, setRaw] = (0, import_react.useState)(String(nowSec));
	const parsed = (0, import_react.useMemo)(() => {
		const n = parseNumeric(raw);
		if (n === null) return null;
		const ms = Math.abs(n) >= 0xe8d4a51000 ? n : n * 1e3;
		const date = new Date(ms);
		if (Number.isNaN(date.getTime())) return null;
		return date;
	}, [raw]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Unix time (seconds or milliseconds)",
				htmlFor: "ts-raw",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "ts-raw",
					inputMode: "numeric",
					value: raw,
					onChange: (e) => setRaw(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "secondary",
				onClick: () => setRaw(String(Math.floor(Date.now() / 1e3))),
				children: "Use now"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Local",
					value: parsed ? parsed.toString() : "Invalid",
					copy: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "UTC ISO",
					value: parsed ? parsed.toISOString() : "—",
					copy: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Seconds",
					value: parsed ? String(Math.floor(parsed.getTime() / 1e3)) : "—",
					copy: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Milliseconds",
					value: parsed ? String(parsed.getTime()) : "—",
					copy: true
				})
			] })
		]
	});
}
function toBase(n, radix) {
	if (!Number.isFinite(n) || !Number.isInteger(n)) return "—";
	return (n >>> 0).toString(radix);
}
function NumberBaseTool() {
	const [dec, setDec] = (0, import_react.useState)("255");
	const n = parseNumeric(dec);
	const int = n !== null && Number.isInteger(n) ? n : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Decimal integer",
				htmlFor: "base-dec",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "base-dec",
					inputMode: "numeric",
					value: dec,
					onChange: (e) => setDec(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Binary",
					value: int === null ? "—" : toBase(int, 2),
					copy: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Octal",
					value: int === null ? "—" : toBase(int, 8),
					copy: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Decimal",
					value: int === null ? "—" : String(int),
					copy: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Hex",
					value: int === null ? "—" : toBase(int, 16).toUpperCase(),
					copy: true
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Paste a hex value with a 0x prefix to convert from hex."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "From hex / binary / octal",
				htmlFor: "base-any",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "base-any",
					placeholder: "0xFF or 0b1111 or 0o17",
					onChange: (e) => {
						const v = e.target.value.trim();
						try {
							if (/^0x[0-9a-f]+$/i.test(v)) setDec(String(Number.parseInt(v.slice(2), 16)));
							else if (/^0b[01]+$/i.test(v)) setDec(String(Number.parseInt(v.slice(2), 2)));
							else if (/^0o[0-7]+$/i.test(v)) setDec(String(Number.parseInt(v.slice(2), 8)));
						} catch {}
					}
				})
			})
		]
	});
}
function TimezoneConverterTool() {
	const [from, setFrom] = (0, import_react.useState)("America/New_York");
	const [to, setTo] = (0, import_react.useState)("Asia/Tokyo");
	const [local, setLocal] = (0, import_react.useState)(() => {
		const d = /* @__PURE__ */ new Date();
		const pad = (n) => String(n).padStart(2, "0");
		return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
	});
	const date = (0, import_react.useMemo)(() => {
		const asLocal = new Date(local);
		return Number.isNaN(asLocal.getTime()) ? null : asLocal;
	}, [local]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Date and time",
				htmlFor: "tz-local",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "tz-local",
					type: "datetime-local",
					value: local,
					onChange: (e) => setLocal(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "From zone",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: from,
					onValueChange: setFrom,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						"aria-label": "From time zone",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: ZONES.map((zone) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: zone.id,
						children: zone.label
					}, zone.id)) })]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "To zone",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: to,
					onValueChange: setTo,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						"aria-label": "To time zone",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: ZONES.map((zone) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: zone.id,
						children: zone.label
					}, zone.id)) })]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Interpreted as local clock",
					value: date ? date.toString() : "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: ZONES.find((z) => z.id === from)?.label ?? from,
					value: date ? fmtZone(date, from) : "—",
					copy: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: ZONES.find((z) => z.id === to)?.label ?? to,
					value: date ? fmtZone(date, to) : "—",
					large: true,
					copy: true
				})
			] })
		]
	});
}
function inline(text) {
	const nodes = [];
	const pattern = /(`[^`]+`)|(\*\*[^*]+\*\*)|(\*[^*]+\*)|(\[[^\]]+\]\([^)]+\))/g;
	let last = 0;
	let match;
	let key = 0;
	while (match = pattern.exec(text)) {
		if (match.index > last) nodes.push(text.slice(last, match.index));
		const token = match[0];
		if (token.startsWith("`")) nodes.push((0, import_react.createElement)("code", {
			key: key++,
			className: "rounded-sm bg-bg px-1 py-0.5 font-mono text-sm"
		}, token.slice(1, -1)));
		else if (token.startsWith("**")) nodes.push((0, import_react.createElement)("strong", { key: key++ }, token.slice(2, -2)));
		else if (token.startsWith("*")) nodes.push((0, import_react.createElement)("em", { key: key++ }, token.slice(1, -1)));
		else {
			const link = token.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
			if (link) {
				const href = link[2].startsWith("http") ? link[2] : "#";
				nodes.push((0, import_react.createElement)("a", {
					key: key++,
					href,
					className: "text-accent underline underline-offset-2",
					target: href.startsWith("http") ? "_blank" : void 0,
					rel: href.startsWith("http") ? "noreferrer" : void 0
				}, link[1]));
			}
		}
		last = match.index + token.length;
	}
	if (last < text.length) nodes.push(text.slice(last));
	return nodes;
}
function renderMarkdown(source) {
	const lines = source.replace(/\r\n/g, "\n").split("\n");
	const blocks = [];
	let i = 0;
	let key = 0;
	while (i < lines.length) {
		const line = lines[i];
		if (!line.trim()) {
			i += 1;
			continue;
		}
		if (line.startsWith("```")) {
			const buf = [];
			i += 1;
			while (i < lines.length && !lines[i].startsWith("```")) {
				buf.push(lines[i]);
				i += 1;
			}
			i += 1;
			blocks.push((0, import_react.createElement)("pre", {
				key: key++,
				className: "overflow-x-auto rounded-md bg-bg p-4 font-mono text-sm shadow-card"
			}, (0, import_react.createElement)("code", null, buf.join("\n"))));
			continue;
		}
		if (line.startsWith("# ")) {
			blocks.push((0, import_react.createElement)("h1", {
				key: key++,
				className: "font-display text-2xl font-semibold"
			}, ...inline(line.slice(2))));
			i += 1;
			continue;
		}
		if (line.startsWith("## ")) {
			blocks.push((0, import_react.createElement)("h2", {
				key: key++,
				className: "font-display text-xl font-semibold"
			}, ...inline(line.slice(3))));
			i += 1;
			continue;
		}
		if (line.startsWith("### ")) {
			blocks.push((0, import_react.createElement)("h3", {
				key: key++,
				className: "font-display text-lg font-semibold"
			}, ...inline(line.slice(4))));
			i += 1;
			continue;
		}
		if (line.startsWith("> ")) {
			const buf = [line.slice(2)];
			i += 1;
			while (i < lines.length && lines[i].startsWith("> ")) {
				buf.push(lines[i].slice(2));
				i += 1;
			}
			blocks.push((0, import_react.createElement)("blockquote", {
				key: key++,
				className: "border-l-2 border-border-strong pl-4 text-muted"
			}, buf.join(" ")));
			continue;
		}
		if (/^[-*] /.test(line)) {
			const items = [];
			while (i < lines.length && /^[-*] /.test(lines[i])) {
				items.push(lines[i].replace(/^[-*] /, ""));
				i += 1;
			}
			blocks.push((0, import_react.createElement)("ul", {
				key: key++,
				className: "list-disc space-y-1 pl-5"
			}, items.map((item, idx) => (0, import_react.createElement)("li", { key: idx }, ...inline(item)))));
			continue;
		}
		if (/^\d+\. /.test(line)) {
			const items = [];
			while (i < lines.length && /^\d+\. /.test(lines[i])) {
				items.push(lines[i].replace(/^\d+\. /, ""));
				i += 1;
			}
			blocks.push((0, import_react.createElement)("ol", {
				key: key++,
				className: "list-decimal space-y-1 pl-5"
			}, items.map((item, idx) => (0, import_react.createElement)("li", { key: idx }, ...inline(item)))));
			continue;
		}
		const para = [line];
		i += 1;
		while (i < lines.length && lines[i].trim() && !/^#{1,3} |^```|^> |^[-*] |^\d+\. /.test(lines[i])) {
			para.push(lines[i]);
			i += 1;
		}
		blocks.push((0, import_react.createElement)("p", {
			key: key++,
			className: "leading-normal"
		}, ...inline(para.join(" "))));
	}
	if (!blocks.length) return (0, import_react.createElement)("p", { className: "text-muted" }, "Preview appears here.");
	return (0, import_react.createElement)(import_react.Fragment, null, ...blocks);
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-40 w-full rounded-md bg-elevated px-3 py-3 text-base text-fg shadow-card transition-[box-shadow] duration-150 placeholder:text-subtle focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
function WordCounterTool() {
	const [text, setText] = (0, import_react.useState)("");
	const stats = (0, import_react.useMemo)(() => {
		const trimmed = text.trim();
		const words = trimmed ? trimmed.split(/\s+/).length : 0;
		return {
			words,
			chars: text.length,
			charsNoSpace: text.replace(/\s/g, "").length,
			sentences: trimmed ? trimmed.split(/[.!?]+/).filter((s) => s.trim()).length : 0,
			paragraphs: trimmed ? trimmed.split(/\n\s*\n/).filter(Boolean).length : 0,
			reading: words / 200,
			speaking: words / 130
		};
	}, [text]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Text",
			htmlFor: "wc-text",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				id: "wc-text",
				value: text,
				onChange: (e) => setText(e.target.value),
				placeholder: "Paste or type here…",
				className: "min-h-52"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Words",
				value: String(stats.words),
				large: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Characters",
				value: String(stats.chars)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Characters without spaces",
				value: String(stats.charsNoSpace)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Sentences",
				value: String(stats.sentences)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Paragraphs",
				value: String(stats.paragraphs)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Reading time",
				value: `${formatFixed(stats.reading, 1)} min`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Speaking time",
				value: `${formatFixed(stats.speaking, 1)} min`
			})
		] })]
	});
}
function toTitle(text) {
	return text.toLowerCase().replace(/\b\w/g, (ch) => ch.toUpperCase());
}
function toSentence(text) {
	return text.toLowerCase().replace(/(^\s*\w|[.!?]\s+\w)/g, (ch) => ch.toUpperCase());
}
function toCamel(text) {
	return text.trim().split(/[^a-zA-Z0-9]+/).filter(Boolean).map((part, i) => i === 0 ? part.toLowerCase() : part.slice(0, 1).toUpperCase() + part.slice(1).toLowerCase()).join("");
}
function toSnake(text) {
	return text.trim().split(/[^a-zA-Z0-9]+/).filter(Boolean).map((p) => p.toLowerCase()).join("_");
}
function toKebab(text) {
	return toSnake(text).replaceAll("_", "-");
}
function CaseConverterTool() {
	const [text, setText] = (0, import_react.useState)("Datum daily tools");
	const modes = [
		{
			id: "upper",
			label: "UPPER",
			value: text.toUpperCase()
		},
		{
			id: "lower",
			label: "lower",
			value: text.toLowerCase()
		},
		{
			id: "title",
			label: "Title Case",
			value: toTitle(text)
		},
		{
			id: "sentence",
			label: "Sentence case",
			value: toSentence(text)
		},
		{
			id: "camel",
			label: "camelCase",
			value: toCamel(text)
		},
		{
			id: "snake",
			label: "snake_case",
			value: toSnake(text)
		},
		{
			id: "kebab",
			label: "kebab-case",
			value: toKebab(text)
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Text",
				htmlFor: "case-text",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "case-text",
					value: text,
					onChange: (e) => setText(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2",
				children: modes.map((mode) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex items-center justify-between gap-3 rounded-sm bg-bg px-3 py-3 text-left",
					onClick: () => void copyText(mode.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: mode.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate font-medium",
						children: mode.value || "—"
					})]
				}, mode.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Tap a row to copy that version."
			})
		]
	});
}
var LOREM = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";
function loremWords(count) {
	const words = LOREM.replace(/[.,]/g, "").split(" ");
	const out = [];
	for (let i = 0; i < count; i += 1) out.push(words[i % words.length].toLowerCase());
	out[0] = out[0][0].toUpperCase() + out[0].slice(1);
	return `${out.join(" ")}.`;
}
function LoremIpsumTool() {
	const [count, setCount] = (0, import_react.useState)("3");
	const [kind, setKind] = (0, import_react.useState)("paragraphs");
	const n = Math.max(1, Math.min(50, Number(count) || 1));
	const text = (0, import_react.useMemo)(() => {
		if (kind === "words") return loremWords(n);
		if (kind === "sentences") return Array.from({ length: n }, () => LOREM.split(". ")[0] + ".").join(" ");
		return Array.from({ length: n }, () => LOREM).join("\n\n");
	}, [kind, n]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Count",
				htmlFor: "lorem-n",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "lorem-n",
					inputMode: "numeric",
					value: count,
					onChange: (e) => setCount(e.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Kind",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						"paragraphs",
						"sentences",
						"words"
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: kind === item ? "default" : "secondary",
						size: "sm",
						onClick: () => setKind(item),
						children: item
					}, item))
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				readOnly: true,
				value: text,
				className: "min-h-48"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { value: text })
		]
	});
}
function MarkdownPreviewTool() {
	const [source, setSource] = (0, import_react.useState)("# Heading\n\nWrite **Markdown** on the left.\n\n- Lists work\n- `code` too\n\n[Datum](https://example.com)");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Markdown",
			htmlFor: "md-src",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				id: "md-src",
				value: source,
				onChange: (e) => setSource(e.target.value),
				className: "min-h-72 font-mono text-sm"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: "Preview"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-72 rounded-sm bg-bg px-4 py-3 [&_h1]:mt-0 [&_p]:mt-2",
				children: renderMarkdown(source)
			})]
		})]
	}) });
}
function cleanText(text, opts) {
	let lines = text.replaceAll("\r\n", "\n").split("\n");
	if (opts.trimLines) lines = lines.map((line) => line.trim());
	if (opts.collapse) lines = lines.map((line) => line.replace(/\s+/g, " "));
	if (opts.dropEmpty) lines = lines.filter((line) => line.length > 0);
	if (opts.dropDupes) {
		const seen = /* @__PURE__ */ new Set();
		lines = lines.filter((line) => {
			if (seen.has(line)) return false;
			seen.add(line);
			return true;
		});
	}
	if (opts.sortLines) lines = [...lines].sort((a, b) => a.localeCompare(b));
	return lines.join("\n");
}
function TextCleanerTool() {
	const [text, setText] = (0, import_react.useState)("  Hello   world  \n\nHello   world\nextra   spaces");
	const [trimLines, setTrimLines] = (0, import_react.useState)(true);
	const [collapse, setCollapse] = (0, import_react.useState)(true);
	const [dropEmpty, setDropEmpty] = (0, import_react.useState)(true);
	const [dropDupes, setDropDupes] = (0, import_react.useState)(false);
	const [sortLines, setSortLines] = (0, import_react.useState)(false);
	const cleaned = (0, import_react.useMemo)(() => cleanText(text, {
		trimLines,
		collapse,
		dropEmpty,
		dropDupes,
		sortLines
	}), [
		text,
		trimLines,
		collapse,
		dropEmpty,
		dropDupes,
		sortLines
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Text",
				htmlFor: "clean-src",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "clean-src",
					value: text,
					onChange: (e) => setText(e.target.value),
					className: "min-h-40 font-mono text-sm"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					{
						id: "trim",
						label: "Trim each line",
						on: trimLines,
						set: setTrimLines
					},
					{
						id: "collapse",
						label: "Collapse spaces",
						on: collapse,
						set: setCollapse
					},
					{
						id: "empty",
						label: "Remove empty lines",
						on: dropEmpty,
						set: setDropEmpty
					},
					{
						id: "dupes",
						label: "Remove duplicate lines",
						on: dropDupes,
						set: setDropDupes
					},
					{
						id: "sort",
						label: "Sort lines",
						on: sortLines,
						set: setSortLines
					}
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					size: "sm",
					variant: item.on ? "default" : "secondary",
					onClick: () => item.set(!item.on),
					children: item.label
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Cleaned",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					readOnly: true,
					value: cleaned,
					className: "min-h-40 font-mono text-sm"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { value: cleaned })
		]
	});
}
function lineDiff(a, b) {
	const left = a.replaceAll("\r\n", "\n").split("\n");
	const right = b.replaceAll("\r\n", "\n").split("\n");
	const n = Math.min(2e3, left.length);
	const m = Math.min(2e3, right.length);
	const dp = Array.from({ length: n + 1 }, () => Array(m + 1).fill(0));
	for (let i = 1; i <= n; i += 1) for (let j = 1; j <= m; j += 1) dp[i][j] = left[i - 1] === right[j - 1] ? dp[i - 1][j - 1] + 1 : Math.max(dp[i - 1][j], dp[i][j - 1]);
	const out = [];
	let i = n;
	let j = m;
	while (i > 0 && j > 0) if (left[i - 1] === right[j - 1]) {
		out.push({
			kind: "same",
			text: left[i - 1]
		});
		i -= 1;
		j -= 1;
	} else if (dp[i - 1][j] >= dp[i][j - 1]) {
		out.push({
			kind: "del",
			text: left[i - 1]
		});
		i -= 1;
	} else {
		out.push({
			kind: "add",
			text: right[j - 1]
		});
		j -= 1;
	}
	while (i > 0) {
		out.push({
			kind: "del",
			text: left[i - 1]
		});
		i -= 1;
	}
	while (j > 0) {
		out.push({
			kind: "add",
			text: right[j - 1]
		});
		j -= 1;
	}
	return out.reverse();
}
function TextDiffTool() {
	const [left, setLeft] = (0, import_react.useState)("alpha\nbeta\ngamma");
	const [right, setRight] = (0, import_react.useState)("alpha\nbeta\ndelta");
	const rows = (0, import_react.useMemo)(() => lineDiff(left, right), [left, right]);
	const added = rows.filter((r) => r.kind === "add").length;
	const removed = rows.filter((r) => r.kind === "del").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Original",
					htmlFor: "diff-a",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "diff-a",
						value: left,
						onChange: (e) => setLeft(e.target.value),
						className: "min-h-48 font-mono text-sm"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Revised",
					htmlFor: "diff-b",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "diff-b",
						value: right,
						onChange: (e) => setRight(e.target.value),
						className: "min-h-48 font-mono text-sm"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Added lines",
				value: String(added)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Removed lines",
				value: String(removed)
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-80 overflow-auto rounded-sm bg-bg px-3 py-2 font-mono text-sm",
				children: rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: row.kind === "add" ? "text-ok" : row.kind === "del" ? "text-danger" : "text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mr-2 inline-block w-3",
						children: row.kind === "add" ? "+" : row.kind === "del" ? "−" : " "
					}), row.text || " "]
				}, `${row.kind}-${index}-${row.text.slice(0, 24)}`))
			})
		]
	});
}
function Slider({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		className: cn("relative flex w-full touch-none items-center select-none", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-border-strong",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-accent" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-5 rounded-full bg-elevated shadow-card transition-[box-shadow] duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent" })]
	});
}
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("peer inline-flex h-7 w-12 shrink-0 cursor-pointer items-center rounded-full bg-border-strong p-0.5 transition-colors duration-150 data-[state=checked]:bg-accent focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:cursor-not-allowed disabled:opacity-50", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-6 rounded-full bg-elevated shadow-card transition-transform duration-150 data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0" })
	});
}
function randomInt(max) {
	const buf = /* @__PURE__ */ new Uint32Array(1);
	crypto.getRandomValues(buf);
	return buf[0] % max;
}
function randomChars(length, alphabet) {
	const out = [];
	for (let i = 0; i < length; i += 1) out.push(alphabet[randomInt(alphabet.length)]);
	return out.join("");
}
function passwordScore(value, variety) {
	if (value.length >= 16 && variety >= 3) return {
		label: "Strong",
		tone: "ok"
	};
	if (value.length >= 12 && variety >= 2) return {
		label: "Good",
		tone: "ok"
	};
	if (value.length >= 8) return {
		label: "Fair",
		tone: "warn"
	};
	return {
		label: "Short",
		tone: "danger"
	};
}
function PasswordGeneratorTool() {
	const [length, setLength] = (0, import_react.useState)(16);
	const [upper, setUpper] = (0, import_react.useState)(true);
	const [lower, setLower] = (0, import_react.useState)(true);
	const [digits, setDigits] = (0, import_react.useState)(true);
	const [symbols, setSymbols] = (0, import_react.useState)(true);
	const [exclude, setExclude] = (0, import_react.useState)(true);
	const [value, setValue] = (0, import_react.useState)("");
	const alphabet = (0, import_react.useMemo)(() => {
		const parts = [];
		if (lower) parts.push(exclude ? "abcdefghijkmnopqrstuvwxyz" : "abcdefghijklmnopqrstuvwxyz");
		if (upper) parts.push(exclude ? "ABCDEFGHJKLMNPQRSTUVWXYZ" : "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
		if (digits) parts.push(exclude ? "23456789" : "0123456789");
		if (symbols) parts.push("!@#$%^&*_-+=?");
		return parts.join("") || "abcdefghijkmnopqrstuvwxyz";
	}, [
		upper,
		lower,
		digits,
		symbols,
		exclude
	]);
	const generate = () => setValue(randomChars(length, alphabet));
	(0, import_react.useEffect)(() => {
		setValue(randomChars(length, alphabet));
	}, []);
	const variety = [
		upper,
		lower,
		digits,
		symbols
	].filter(Boolean).length;
	const score = value ? passwordScore(value, variety) : null;
	const toggles = [
		{
			id: "upper",
			label: "Uppercase",
			on: upper,
			set: setUpper
		},
		{
			id: "lower",
			label: "Lowercase",
			on: lower,
			set: setLower
		},
		{
			id: "digits",
			label: "Digits",
			on: digits,
			set: setDigits
		},
		{
			id: "symbols",
			label: "Symbols",
			on: symbols,
			set: setSymbols
		},
		{
			id: "exclude",
			label: "Exclude similar (Il1O0)",
			on: exclude,
			set: setExclude
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `Length · ${length}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 8,
					max: 64,
					step: 1,
					value: [length],
					onValueChange: (v) => setLength(v[0] ?? 16),
					"aria-label": "Password length"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: toggles.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 rounded-sm bg-bg px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: item.id,
						children: item.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						id: item.id,
						checked: item.on,
						onCheckedChange: item.set
					})]
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: generate,
					children: "Generate"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { value })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "break-all font-mono text-lg",
				children: value || "Generate a password to begin."
			}), score ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: score.tone,
					children: score.label
				})
			}) : null] })
		]
	});
}
function QrCodeTool() {
	const [text, setText] = (0, import_react.useState)("https://");
	const encoded = (0, import_react.useMemo)(() => {
		const payload = text.trim() || " ";
		try {
			return {
				svg: renderSVG(payload, {
					ecc: "M",
					border: 2,
					pixelSize: 8,
					blackColor: "#1a1916",
					whiteColor: "#faf8f3"
				}),
				matrix: encode(payload, {
					ecc: "M",
					border: 2
				})
			};
		} catch {
			return null;
		}
	}, [text]);
	const download = (kind) => {
		if (!encoded) return;
		if (kind === "svg") {
			const blob = new Blob([encoded.svg], { type: "image/svg+xml" });
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = "qr-code.svg";
			a.click();
			URL.revokeObjectURL(url);
			return;
		}
		const size = encoded.matrix.size;
		const canvas = document.createElement("canvas");
		const scale = 8;
		canvas.width = size * scale;
		canvas.height = size * scale;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		ctx.fillStyle = "#faf8f3";
		ctx.fillRect(0, 0, canvas.width, canvas.height);
		ctx.fillStyle = "#1a1916";
		encoded.matrix.data.forEach((row, y) => {
			row.forEach((cell, x) => {
				if (cell) ctx.fillRect(x * scale, y * scale, scale, scale);
			});
		});
		canvas.toBlob((blob) => {
			if (!blob) return;
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = "qr-code.png";
			a.click();
			URL.revokeObjectURL(url);
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Text or URL",
				htmlFor: "qr-text",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "qr-text",
					value: text,
					onChange: (e) => setText(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center rounded-sm bg-bg p-4",
				children: encoded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-56 [&_svg]:h-full [&_svg]:w-full",
					dangerouslySetInnerHTML: { __html: encoded.svg }
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Could not encode that text."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: () => download("svg"),
					children: "Download SVG"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "secondary",
					onClick: () => download("png"),
					children: "Download PNG"
				})]
			})
		]
	});
}
function UuidGeneratorTool() {
	const [count, setCount] = (0, import_react.useState)("5");
	const [values, setValues] = (0, import_react.useState)([]);
	const n = clampNumber(Math.floor(Number(count) || 1), 1, 50);
	const generate = () => {
		const next = Array.from({ length: n }, () => crypto.randomUUID());
		setValues(next);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolForm, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "How many",
				htmlFor: "uuid-n",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "uuid-n",
					inputMode: "numeric",
					value: count,
					onChange: (e) => setCount(e.target.value)
				})
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: generate,
					children: "Generate"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
					value: values.join("\n"),
					label: "Copy all"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultPanel, { children: values.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2 font-mono text-sm",
				children: values.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-left hover:text-accent",
					onClick: () => void copyText(id),
					children: id
				}) }, id))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Generate to create version 4 UUIDs."
			}) })
		]
	});
}
function RandomNumberTool() {
	const [min, setMin] = (0, import_react.useState)("1");
	const [max, setMax] = (0, import_react.useState)("100");
	const [count, setCount] = (0, import_react.useState)("1");
	const [unique, setUnique] = (0, import_react.useState)(false);
	const [values, setValues] = (0, import_react.useState)([]);
	const generate = () => {
		const lo = parseNumeric(min);
		const hi = parseNumeric(max);
		const n = clampNumber(Math.floor(Number(count) || 1), 1, 100);
		if (lo === null || hi === null) return;
		const a = Math.ceil(Math.min(lo, hi));
		const span = Math.floor(Math.max(lo, hi)) - a + 1;
		if (span <= 0) return;
		const out = [];
		if (unique) {
			const pool = Array.from({ length: span }, (_, i) => a + i);
			const take = Math.min(n, pool.length);
			for (let i = 0; i < take; i += 1) {
				const idx = randomInt(pool.length);
				out.push(pool.splice(idx, 1)[0]);
			}
		} else for (let i = 0; i < n; i += 1) out.push(a + randomInt(span));
		setValues(out);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Minimum",
					htmlFor: "rnd-min",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "rnd-min",
						inputMode: "numeric",
						value: min,
						onChange: (e) => setMin(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Maximum",
					htmlFor: "rnd-max",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "rnd-max",
						inputMode: "numeric",
						value: max,
						onChange: (e) => setMax(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Count",
					htmlFor: "rnd-n",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "rnd-n",
						inputMode: "numeric",
						value: count,
						onChange: (e) => setCount(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 rounded-sm bg-bg px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "rnd-unique",
						children: "Unique values"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						id: "rnd-unique",
						checked: unique,
						onCheckedChange: setUnique
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: generate,
					children: "Generate"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { value: values.join(", ") })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl font-semibold tabular-nums",
				children: values.length ? values.join(" · ") : "—"
			}) })
		]
	});
}
function JsonFormatterTool() {
	const [source, setSource] = (0, import_react.useState)("{\n  \"ok\": true\n}");
	const [error, setError] = (0, import_react.useState)(null);
	const [output, setOutput] = (0, import_react.useState)("");
	const format = (pretty) => {
		try {
			const parsed = JSON.parse(source);
			setOutput(JSON.stringify(parsed, null, pretty ? 2 : 0));
			setError(null);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Invalid JSON");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "JSON",
				htmlFor: "json-src",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "json-src",
					value: source,
					onChange: (e) => setSource(e.target.value),
					className: "min-h-52 font-mono text-sm"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: () => format(true),
						children: "Format"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						onClick: () => format(false),
						children: "Minify"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { value: output || source })
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			output ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				readOnly: true,
				value: output,
				className: "min-h-40 font-mono text-sm"
			}) : null
		]
	});
}
function encodeBase64(text) {
	const bytes = new TextEncoder().encode(text);
	let binary = "";
	bytes.forEach((b) => {
		binary += String.fromCharCode(b);
	});
	return btoa(binary);
}
function decodeBase64(text) {
	const binary = atob(text);
	const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
	return new TextDecoder().decode(bytes);
}
function Base64Tool() {
	const [source, setSource] = (0, import_react.useState)("Datum");
	const [mode, setMode] = (0, import_react.useState)("encode");
	const result = (0, import_react.useMemo)(() => {
		try {
			if (mode === "encode") return {
				output: encodeBase64(source),
				error: null
			};
			return {
				output: decodeBase64(source.trim()),
				error: null
			};
		} catch {
			return {
				output: "",
				error: "Could not decode that input."
			};
		}
	}, [source, mode]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: mode === "encode" ? "default" : "secondary",
					onClick: () => setMode("encode"),
					children: "Encode"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: mode === "decode" ? "default" : "secondary",
					onClick: () => setMode("decode"),
					children: "Decode"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Input",
				htmlFor: "b64-src",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "b64-src",
					value: source,
					onChange: (e) => setSource(e.target.value),
					className: "font-mono text-sm"
				})
			}),
			result.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: result.error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "break-all font-mono text-sm",
				children: result.output || "—"
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { value: result.output })
		]
	});
}
function UrlEncoderTool() {
	const [source, setSource] = (0, import_react.useState)("hello world & datum=1");
	const [component, setComponent] = (0, import_react.useState)(true);
	const encoded = component ? encodeURIComponent(source) : encodeURI(source);
	let decoded = "";
	let error = null;
	try {
		decoded = component ? decodeURIComponent(source) : decodeURI(source);
	} catch {
		error = "Input is not valid percent-encoding.";
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 rounded-sm bg-bg px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "url-comp",
					children: "Component mode (encodeURIComponent)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					id: "url-comp",
					checked: component,
					onCheckedChange: setComponent
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Input",
				htmlFor: "url-src",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "url-src",
					value: source,
					onChange: (e) => setSource(e.target.value),
					className: "font-mono text-sm"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 text-sm text-muted",
					children: "Encoded"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 break-all font-mono text-sm",
					children: encoded
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 text-sm text-muted",
					children: "Decoded"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "break-all font-mono text-sm",
					children: error ?? decoded
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "secondary",
					onClick: () => void copyText(encoded),
					children: "Copy encoded"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "secondary",
					onClick: () => void copyText(decoded),
					children: "Copy decoded"
				})]
			})
		]
	});
}
var HASHES = [
	"SHA-1",
	"SHA-256",
	"SHA-384",
	"SHA-512"
];
async function digest(algo, text) {
	const data = new TextEncoder().encode(text);
	const buf = await crypto.subtle.digest(algo, data);
	return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function HashGeneratorTool() {
	const [source, setSource] = (0, import_react.useState)("Datum");
	const [algo, setAlgo] = (0, import_react.useState)("SHA-256");
	const [hash, setHash] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	const run = async () => {
		setPending(true);
		try {
			setHash(await digest(algo, source));
		} finally {
			setPending(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Algorithm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: algo,
					onValueChange: (v) => setAlgo(v),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						"aria-label": "Hash algorithm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: HASHES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: item,
						children: item
					}, item)) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Input",
				htmlFor: "hash-src",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "hash-src",
					value: source,
					onChange: (e) => setSource(e.target.value),
					className: "font-mono text-sm"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				onClick: () => void run(),
				disabled: pending,
				children: pending ? "Hashing…" : "Hash"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "break-all font-mono text-sm",
				children: hash || "Run a hash to see the hex digest."
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, { value: hash })
		]
	});
}
var MIME = {
	jpeg: "image/jpeg",
	png: "image/png",
	webp: "image/webp"
};
async function fileToImage(file) {
	if (!file.type.startsWith("image/") && file.type !== "image/svg+xml") throw new Error("Choose an image file.");
	if (file.size > 12582912) throw new Error("Keep files under 12 MB.");
	if (typeof createImageBitmap === "function") try {
		const bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
		const canvas = document.createElement("canvas");
		canvas.width = bitmap.width;
		canvas.height = bitmap.height;
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("Canvas is not available.");
		ctx.drawImage(bitmap, 0, 0);
		bitmap.close();
		const blob = await canvasToBlob(canvas, file.type.startsWith("image/") ? file.type : "image/png");
		const url = URL.createObjectURL(blob);
		return {
			img: await blobUrlToImage(url),
			url
		};
	} catch {}
	const url = URL.createObjectURL(file);
	try {
		return {
			img: await blobUrlToImage(url),
			url
		};
	} catch (err) {
		URL.revokeObjectURL(url);
		throw err;
	}
}
function blobUrlToImage(url) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.onload = () => resolve(img);
		img.onerror = () => reject(/* @__PURE__ */ new Error("Could not read that image."));
		img.src = url;
	});
}
function makeCanvas(width, height) {
	const canvas = document.createElement("canvas");
	canvas.width = Math.max(1, Math.round(width));
	canvas.height = Math.max(1, Math.round(height));
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Canvas is not available.");
	ctx.imageSmoothingEnabled = true;
	ctx.imageSmoothingQuality = "high";
	return {
		canvas,
		ctx
	};
}
function downloadBlob(blob, name) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = name;
	a.click();
	URL.revokeObjectURL(url);
}
function canvasToBlob(canvas, type, quality = .92) {
	return new Promise((resolve, reject) => {
		canvas.toBlob((blob) => {
			if (!blob) reject(/* @__PURE__ */ new Error("Could not export the image."));
			else resolve(blob);
		}, type, quality);
	});
}
async function compressToTarget(canvas, type, targetBytes) {
	if (type === MIME.png) return canvasToBlob(canvas, type);
	let lo = .35;
	let hi = .96;
	let best = await canvasToBlob(canvas, type, .72);
	if (best.size <= targetBytes) {
		const finer = await canvasToBlob(canvas, type, hi);
		if (finer.size <= targetBytes) return finer;
	}
	for (let i = 0; i < 8; i += 1) {
		const mid = (lo + hi) / 2;
		const blob = await canvasToBlob(canvas, type, mid);
		if (blob.size > targetBytes) hi = mid;
		else {
			lo = mid;
			best = blob;
		}
	}
	return best;
}
function fillColor(ctx, color, width, height) {
	ctx.fillStyle = color;
	ctx.fillRect(0, 0, width, height);
}
function rotatedSize(width, height, radians) {
	const c = Math.abs(Math.cos(radians));
	const s = Math.abs(Math.sin(radians));
	return {
		width: Math.max(1, Math.round(width * c + height * s)),
		height: Math.max(1, Math.round(width * s + height * c))
	};
}
function applyVignette(ctx, width, height, amount) {
	if (amount <= 0) return;
	const inner = Math.min(width, height) * .32;
	const outer = Math.max(width, height) * .72;
	const g = ctx.createRadialGradient(width / 2, height / 2, inner, width / 2, height / 2, outer);
	g.addColorStop(0, "rgba(0,0,0,0)");
	g.addColorStop(1, `rgba(0,0,0,${amount})`);
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, width, height);
}
function toHex(r, g, b) {
	return `#${[
		r,
		g,
		b
	].map((n) => n.toString(16).padStart(2, "0")).join("")}`;
}
function hexToRgb(hex) {
	const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
	if (!m?.[1]) return null;
	const n = Number.parseInt(m[1], 16);
	return [
		n >> 16 & 255,
		n >> 8 & 255,
		n & 255
	];
}
function rgbToHsl(r, g, b) {
	const rn = r / 255;
	const gn = g / 255;
	const bn = b / 255;
	const max = Math.max(rn, gn, bn);
	const min = Math.min(rn, gn, bn);
	const d = max - min;
	let h = 0;
	if (d !== 0) {
		if (max === rn) h = (gn - bn) / d % 6;
		else if (max === gn) h = (bn - rn) / d + 2;
		else h = (rn - gn) / d + 4;
		h *= 60;
		if (h < 0) h += 360;
	}
	const l = (max + min) / 2;
	const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
	return `${Math.round(h)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
}
function extractPalette(img, count = 6) {
	const canvas = document.createElement("canvas");
	const w = 96;
	const h = Math.max(1, Math.round(96 * img.naturalHeight / img.naturalWidth));
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d");
	if (!ctx) return [];
	ctx.drawImage(img, 0, 0, w, h);
	const data = ctx.getImageData(0, 0, w, h).data;
	const buckets = /* @__PURE__ */ new Map();
	for (let i = 0; i < data.length; i += 4) {
		if (data[i + 3] < 128) continue;
		const key = `${data[i] >> 4 << 4},${data[i + 1] >> 4 << 4},${data[i + 2] >> 4 << 4}`;
		const cur = buckets.get(key) ?? {
			n: 0,
			r: 0,
			g: 0,
			b: 0
		};
		cur.n += 1;
		cur.r += data[i];
		cur.g += data[i + 1];
		cur.b += data[i + 2];
		buckets.set(key, cur);
	}
	return [...buckets.values()].sort((a, b) => b.n - a.n).slice(0, count).map((c) => toHex(Math.round(c.r / c.n), Math.round(c.g / c.n), Math.round(c.b / c.n)));
}
function extFor(type) {
	if (type === "image/webp") return "webp";
	if (type === "image/png") return "png";
	return "jpg";
}
function stem(name) {
	return name.replace(/\.[^.]+$/, "") || "image";
}
function scaledEdge(img, maxEdge) {
	const scale = Math.min(1, maxEdge / Math.max(img.naturalWidth, img.naturalHeight));
	return {
		width: Math.max(1, Math.round(img.naturalWidth * scale)),
		height: Math.max(1, Math.round(img.naturalHeight * scale))
	};
}
function useSource() {
	const [source, setSource] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		return () => {
			if (source?.url) URL.revokeObjectURL(source.url);
		};
	}, [source]);
	const onFile = async (file) => {
		if (!file) return;
		try {
			const next = await fileToImage(file);
			setSource((prev) => {
				if (prev?.url) URL.revokeObjectURL(prev.url);
				return {
					file,
					img: next.img,
					url: next.url
				};
			});
			setError(null);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not read that image.");
		}
	};
	return {
		source,
		error,
		onFile,
		setError
	};
}
function useBlobUrl() {
	const ref = (0, import_react.useRef)(null);
	const [url, setUrl] = (0, import_react.useState)(null);
	const [size, setSize] = (0, import_react.useState)(null);
	const setBlob = (0, import_react.useCallback)((blob) => {
		if (ref.current) URL.revokeObjectURL(ref.current);
		if (!blob) {
			ref.current = null;
			setUrl(null);
			setSize(null);
			return;
		}
		const next = URL.createObjectURL(blob);
		ref.current = next;
		setUrl(next);
		setSize(blob.size);
	}, []);
	(0, import_react.useEffect)(() => () => {
		if (ref.current) URL.revokeObjectURL(ref.current);
	}, []);
	return {
		url,
		size,
		setBlob
	};
}
function FilePick({ onFile, hint = "Drop a JPEG, PNG, WebP, GIF, or SVG. Stays on this device.", label = "Image", inputId }) {
	const [over, setOver] = (0, import_react.useState)(false);
	const id = inputId ?? `pick-${label.replace(/\s+/g, "-").toLowerCase()}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label,
		hint,
		htmlFor: id,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			htmlFor: id,
			className: cn("flex min-h-28 cursor-pointer flex-col items-center justify-center gap-2 rounded-xl bg-bg px-4 py-5 text-center shadow-card transition-colors duration-150", over && "bg-accent-soft text-fg"),
			onDragOver: (e) => {
				e.preventDefault();
				setOver(true);
			},
			onDragLeave: () => setOver(false),
			onDrop: (e) => {
				e.preventDefault();
				setOver(false);
				onFile(e.dataTransfer.files[0] ?? null);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm text-muted",
				children: "Drop an image here, or browse"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id,
				type: "file",
				accept: "image/*,image/svg+xml",
				className: "max-w-xs",
				onChange: (e) => onFile(e.target.files?.[0] ?? null)
			})]
		})
	});
}
function Preview({ src, alt }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt,
		className: "img-check max-h-72 w-full rounded-sm object-contain"
	});
}
function DownloadLink({ href, name, label = "Download" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href,
			download: name,
			children: label
		})
	});
}
function Choice({ options, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-2",
		children: options.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			size: "sm",
			variant: value === item.id ? "default" : "secondary",
			onClick: () => onChange(item.id),
			children: item.label
		}, item.id))
	});
}
function ColorField({ id, label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label,
		htmlFor: id,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id,
				type: "color",
				value,
				onChange: (e) => onChange(e.target.value),
				className: "size-11 shrink-0 rounded-md bg-elevated shadow-card"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value,
				onChange: (e) => onChange(e.target.value),
				className: "font-mono"
			})]
		})
	});
}
function SwitchRow({ id, label, checked, onCheckedChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			htmlFor: id,
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
			id,
			checked,
			onCheckedChange
		})]
	});
}
function CompareFrame({ before, after }) {
	const [mode, setMode] = (0, import_react.useState)("after");
	const [pct, setPct] = (0, import_react.useState)(50);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
			value: mode,
			onChange: setMode,
			options: [
				{
					id: "after",
					label: "Result"
				},
				{
					id: "before",
					label: "Original"
				},
				{
					id: "split",
					label: "Side by side"
				},
				{
					id: "wipe",
					label: "Wipe"
				}
			]
		}), mode === "split" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-2 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
				className: "flex flex-col gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Preview, {
					src: before,
					alt: "Original"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
					className: "drawing-label",
					children: "Original"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
				className: "flex flex-col gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Preview, {
					src: after,
					alt: "Result"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
					className: "drawing-label",
					children: "Result"
				})]
			})]
		}) : mode === "wipe" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative overflow-hidden rounded-sm bg-bg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: after,
					alt: "Result",
					className: "img-check block w-full"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 overflow-hidden",
					style: { clipPath: `inset(0 ${100 - pct}% 0 0)` },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: before,
						alt: "Original",
						className: "img-check absolute inset-0 size-full object-contain"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute inset-y-0 w-0.5 bg-accent",
					style: { left: `${pct}%` }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "range",
					min: 4,
					max: 96,
					value: pct,
					"aria-label": "Compare wipe",
					className: "absolute inset-0 cursor-ew-resize opacity-0",
					onChange: (e) => setPct(Number(e.target.value))
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Preview, {
			src: mode === "before" ? before : after,
			alt: mode === "before" ? "Original" : "Result"
		})]
	});
}
function Advanced({ children }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			variant: "ghost",
			className: "self-start px-0",
			onClick: () => setOpen((v) => !v),
			children: open ? "Hide advanced" : "Show advanced"
		}), open ? children : null]
	});
}
function ImageCompressorTool() {
	const { source, error, onFile } = useSource();
	const [format, setFormat] = (0, import_react.useState)("jpeg");
	const [quality, setQuality] = (0, import_react.useState)(.72);
	const [maxEdge, setMaxEdge] = (0, import_react.useState)(1600);
	const [keepSize, setKeepSize] = (0, import_react.useState)(false);
	const [targetOn, setTargetOn] = (0, import_react.useState)(false);
	const [targetKb, setTargetKb] = (0, import_react.useState)(250);
	const { url, size, setBlob } = useBlobUrl();
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [outDim, setOutDim] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!source) return;
		let cancel = false;
		setBusy(true);
		const dim = keepSize ? {
			width: source.img.naturalWidth,
			height: source.img.naturalHeight
		} : scaledEdge(source.img, maxEdge);
		const { canvas, ctx } = makeCanvas(dim.width, dim.height);
		ctx.drawImage(source.img, 0, 0, dim.width, dim.height);
		(targetOn && format !== "png" ? compressToTarget(canvas, MIME[format], targetKb * 1024) : canvasToBlob(canvas, MIME[format], quality)).then((blob) => {
			if (cancel) return;
			setBlob(blob);
			setOutDim(`${dim.width} × ${dim.height}`);
		}).catch((err) => {
			if (!cancel) console.error(err);
		}).finally(() => {
			if (!cancel) setBusy(false);
		});
		return () => {
			cancel = true;
		};
	}, [
		source,
		format,
		quality,
		maxEdge,
		keepSize,
		targetOn,
		targetKb,
		setBlob
	]);
	const saved = source && size !== null && source.file.size > 0 ? `${Math.max(0, Math.round((1 - size / source.file.size) * 100))}%` : "—";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				onFile,
				inputId: "cmp-file"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				value: format,
				onChange: (id) => setFormat(id),
				options: [
					{
						id: "jpeg",
						label: "JPEG"
					},
					{
						id: "webp",
						label: "WebP"
					},
					{
						id: "png",
						label: "PNG"
					}
				]
			}),
			!targetOn && format !== "png" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `Quality · ${Math.round(quality * 100)}%`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: .35,
					max: .95,
					step: .01,
					value: [quality],
					onValueChange: (v) => setQuality(v[0] ?? .72)
				})
			}) : null,
			!keepSize ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `Longest edge · ${maxEdge}px`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 400,
					max: 4e3,
					step: 50,
					value: [maxEdge],
					onValueChange: (v) => setMaxEdge(v[0] ?? 1600)
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Advanced, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRow, {
					id: "cmp-keep",
					label: "Keep original dimensions",
					checked: keepSize,
					onCheckedChange: setKeepSize
				}),
				format !== "png" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRow, {
					id: "cmp-target",
					label: "Aim for a file size",
					checked: targetOn,
					onCheckedChange: setTargetOn
				}), targetOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: `Target · ${targetKb} KB`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: 40,
						max: 2e3,
						step: 10,
						value: [targetKb],
						onValueChange: (v) => setTargetKb(v[0] ?? 250)
					})
				}) : null] }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						{
							label: "Web",
							q: .68,
							edge: 1600
						},
						{
							label: "Email",
							q: .78,
							edge: 1200
						},
						{
							label: "Hi-res",
							q: .88,
							edge: 2560
						}
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "sm",
						variant: "secondary",
						onClick: () => {
							setTargetOn(false);
							setKeepSize(false);
							setQuality(item.q);
							setMaxEdge(item.edge);
						},
						children: item.label
					}, item.label))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Original",
					value: source ? `${source.img.naturalWidth} × ${source.img.naturalHeight} · ${formatBytes(source.file.size)}` : "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Compressed",
					value: busy ? "Working…" : size !== null ? `${outDim} · ${formatBytes(size)}` : "—",
					large: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Saved",
					value: saved
				})
			] }),
			url && source ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompareFrame, {
				before: source.url,
				after: url
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadLink, {
				href: url,
				name: `${stem(source.file.name)}-compressed.${extFor(MIME[format])}`
			})] }) : null
		]
	});
}
function ImageBase64Tool() {
	const { source, error, onFile } = useSource();
	const [dataUrl, setDataUrl] = (0, import_react.useState)("");
	const [shrink, setShrink] = (0, import_react.useState)(false);
	const [maxEdge, setMaxEdge] = (0, import_react.useState)(800);
	const [format, setFormat] = (0, import_react.useState)("jpeg");
	const [quality, setQuality] = (0, import_react.useState)(.8);
	(0, import_react.useEffect)(() => {
		if (!source) {
			setDataUrl("");
			return;
		}
		let cancel = false;
		const run = async () => {
			if (!shrink) {
				const reader = new FileReader();
				const raw = await new Promise((resolve, reject) => {
					reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : "");
					reader.onerror = () => reject(/* @__PURE__ */ new Error("Could not read that file."));
					reader.readAsDataURL(source.file);
				});
				if (!cancel) setDataUrl(raw);
				return;
			}
			const dim = scaledEdge(source.img, maxEdge);
			const { canvas, ctx } = makeCanvas(dim.width, dim.height);
			ctx.drawImage(source.img, 0, 0, dim.width, dim.height);
			const blob = await canvasToBlob(canvas, MIME[format], quality);
			const reader = new FileReader();
			const url = await new Promise((resolve, reject) => {
				reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : "");
				reader.onerror = () => reject(/* @__PURE__ */ new Error("Could not encode."));
				reader.readAsDataURL(blob);
			});
			if (!cancel) setDataUrl(url);
		};
		run();
		return () => {
			cancel = true;
		};
	}, [
		source,
		shrink,
		maxEdge,
		format,
		quality
	]);
	const html = dataUrl ? `<img src="${dataUrl}" alt="${source?.file.name ?? "image"}" />` : "";
	const md = dataUrl ? `![image](${dataUrl})` : "";
	const css = dataUrl ? `background-image: url("${dataUrl}");` : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				onFile,
				inputId: "b64-file"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Advanced, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRow, {
				id: "b64-shrink",
				label: "Compress before encoding",
				checked: shrink,
				onCheckedChange: setShrink
			}), shrink ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: `Longest edge · ${maxEdge}px`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: 200,
						max: 2e3,
						step: 50,
						value: [maxEdge],
						onValueChange: (v) => setMaxEdge(v[0] ?? 800)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					value: format,
					onChange: (id) => setFormat(id),
					options: [
						{
							id: "jpeg",
							label: "JPEG"
						},
						{
							id: "webp",
							label: "WebP"
						},
						{
							id: "png",
							label: "PNG"
						}
					]
				}),
				format !== "png" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: `Quality · ${Math.round(quality * 100)}%`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: .4,
						max: .95,
						step: .01,
						value: [quality],
						onValueChange: (v) => setQuality(v[0] ?? .8)
					})
				}) : null
			] }) : null] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "File",
					value: source?.file.name ?? "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Source size",
					value: source ? formatBytes(source.file.size) : "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Data URL length",
					value: dataUrl ? String(dataUrl.length) : "—",
					large: true
				})
			] }),
			dataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: dataUrl,
					alt: "Selected",
					className: "img-check max-h-48 w-full rounded-sm object-contain"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Data URL",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						readOnly: true,
						value: dataUrl,
						className: "min-h-32 font-mono text-xs",
						onFocus: (e) => e.currentTarget.select()
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
							value: dataUrl,
							label: "Copy data URL"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "secondary",
							onClick: () => void copyText(html),
							children: "Copy HTML"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "secondary",
							onClick: () => void copyText(css),
							children: "Copy CSS"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "secondary",
							onClick: () => void copyText(md),
							children: "Copy Markdown"
						})
					]
				})
			] }) : null
		]
	});
}
var FORMAT_OPTIONS = [
	{
		id: "png",
		label: "PNG"
	},
	{
		id: "jpeg",
		label: "JPEG"
	},
	{
		id: "webp",
		label: "WebP"
	}
];
function drawContain(ctx, img, width, height, mode, matte) {
	if (matte) fillColor(ctx, matte, width, height);
	if (mode === "stretch") {
		ctx.drawImage(img, 0, 0, width, height);
		return;
	}
	const scale = mode === "cover" ? Math.max(width / img.naturalWidth, height / img.naturalHeight) : Math.min(width / img.naturalWidth, height / img.naturalHeight);
	const dw = img.naturalWidth * scale;
	const dh = img.naturalHeight * scale;
	ctx.drawImage(img, (width - dw) / 2, (height - dh) / 2, dw, dh);
}
function ImageResizerTool() {
	const { source, error, onFile } = useSource();
	const [mode, setMode] = (0, import_react.useState)("px");
	const [width, setWidth] = (0, import_react.useState)("1200");
	const [height, setHeight] = (0, import_react.useState)("630");
	const [percent, setPercent] = (0, import_react.useState)(50);
	const [lock, setLock] = (0, import_react.useState)(true);
	const [fit, setFit] = (0, import_react.useState)("contain");
	const [format, setFormat] = (0, import_react.useState)("png");
	const [quality, setQuality] = (0, import_react.useState)(.9);
	const [matte, setMatte] = (0, import_react.useState)("#f3efe6");
	const { url, size, setBlob } = useBlobUrl();
	const [busy, setBusy] = (0, import_react.useState)(false);
	const ratio = source ? source.img.naturalWidth / source.img.naturalHeight : 1;
	const out = (0, import_react.useMemo)(() => {
		if (!source) return {
			w: 0,
			h: 0
		};
		if (mode === "pct") {
			const s = percent / 100;
			return {
				w: Math.max(1, Math.round(source.img.naturalWidth * s)),
				h: Math.max(1, Math.round(source.img.naturalHeight * s))
			};
		}
		return {
			w: Math.max(1, Math.round(parseNumeric(width) ?? 0)),
			h: Math.max(1, Math.round(parseNumeric(height) ?? 0))
		};
	}, [
		source,
		mode,
		percent,
		width,
		height
	]);
	(0, import_react.useEffect)(() => {
		if (!source || !out.w || !out.h) return;
		let cancel = false;
		setBusy(true);
		const { canvas, ctx } = makeCanvas(out.w, out.h);
		drawContain(ctx, source.img, out.w, out.h, fit, format === "png" && fit !== "cover" ? null : matte);
		canvasToBlob(canvas, MIME[format], quality).then((blob) => {
			if (!cancel) {
				setBlob(blob);
				setBusy(false);
			}
		});
		return () => {
			cancel = true;
		};
	}, [
		source,
		out.w,
		out.h,
		fit,
		format,
		quality,
		matte,
		setBlob
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				onFile,
				inputId: "rz-file"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				value: mode,
				onChange: (id) => setMode(id),
				options: [{
					id: "px",
					label: "Pixels"
				}, {
					id: "pct",
					label: "Percent"
				}]
			}),
			mode === "pct" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `Scale · ${percent}%`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 5,
					max: 200,
					step: 1,
					value: [percent],
					onValueChange: (v) => setPercent(v[0] ?? 50)
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						{
							label: "Original",
							w: source?.img.naturalWidth,
							h: source?.img.naturalHeight
						},
						{
							label: "OG",
							w: 1200,
							h: 630
						},
						{
							label: "Square",
							w: 1080,
							h: 1080
						},
						{
							label: "Story",
							w: 1080,
							h: 1920
						},
						{
							label: "Avatar",
							w: 400,
							h: 400
						},
						{
							label: "Favicon",
							w: 32,
							h: 32
						}
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "sm",
						variant: "secondary",
						disabled: !item.w || !item.h,
						onClick: () => {
							if (!item.w || !item.h) return;
							setWidth(String(item.w));
							setHeight(String(item.h));
							setLock(item.label === "Original");
						},
						children: item.label
					}, item.label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Width (px)",
					htmlFor: "rz-w",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "rz-w",
						inputMode: "numeric",
						value: width,
						onChange: (e) => {
							const next = e.target.value;
							setWidth(next);
							if (lock) {
								const n = parseNumeric(next);
								if (n) setHeight(String(Math.round(n / ratio)));
							}
						}
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Height (px)",
					htmlFor: "rz-h",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "rz-h",
						inputMode: "numeric",
						value: height,
						onChange: (e) => {
							const next = e.target.value;
							setHeight(next);
							if (lock) {
								const n = parseNumeric(next);
								if (n) setWidth(String(Math.round(n * ratio)));
							}
						}
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRow, {
					id: "rz-lock",
					label: "Lock aspect",
					checked: lock,
					onCheckedChange: setLock
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				value: fit,
				onChange: (id) => setFit(id),
				options: [
					{
						id: "contain",
						label: "Fit"
					},
					{
						id: "cover",
						label: "Fill"
					},
					{
						id: "stretch",
						label: "Stretch"
					}
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				value: format,
				onChange: (id) => setFormat(id),
				options: FORMAT_OPTIONS
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Advanced, { children: [format !== "png" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `Quality · ${Math.round(quality * 100)}%`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: .4,
					max: .98,
					step: .01,
					value: [quality],
					onValueChange: (v) => setQuality(v[0] ?? .9)
				})
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
				id: "rz-matte",
				label: "Matte (letterbox / JPEG)",
				value: matte,
				onChange: setMatte
			})] }),
			source ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Original",
				value: `${source.img.naturalWidth} × ${source.img.naturalHeight} · ${formatBytes(source.file.size)}`
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Output",
				value: busy ? "Working…" : `${out.w} × ${out.h}${size !== null ? ` · ${formatBytes(size)}` : ""}`,
				large: true
			})] }) : null,
			url && source ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompareFrame, {
				before: source.url,
				after: url
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadLink, {
				href: url,
				name: `${stem(source.file.name)}-resized.${extFor(MIME[format])}`
			})] }) : null
		]
	});
}
var ASPECTS = [
	{
		id: "free",
		label: "Free",
		value: null
	},
	{
		id: "1:1",
		label: "1:1",
		value: 1
	},
	{
		id: "4:3",
		label: "4:3",
		value: 4 / 3
	},
	{
		id: "3:2",
		label: "3:2",
		value: 3 / 2
	},
	{
		id: "16:9",
		label: "16:9",
		value: 16 / 9
	},
	{
		id: "9:16",
		label: "9:16",
		value: 9 / 16
	},
	{
		id: "custom",
		label: "Custom",
		value: null
	}
];
function ImageCropTool() {
	const { source, error, onFile } = useSource();
	const [aspect, setAspect] = (0, import_react.useState)("1:1");
	const [customW, setCustomW] = (0, import_react.useState)("5");
	const [customH, setCustomH] = (0, import_react.useState)("4");
	const [sizePct, setSizePct] = (0, import_react.useState)(80);
	const [ox, setOx] = (0, import_react.useState)(50);
	const [oy, setOy] = (0, import_react.useState)(50);
	const [roundPct, setRoundPct] = (0, import_react.useState)(0);
	const [thirds, setThirds] = (0, import_react.useState)(true);
	const [exportW, setExportW] = (0, import_react.useState)("");
	const [format, setFormat] = (0, import_react.useState)("png");
	const { url, size, setBlob } = useBlobUrl();
	const drag = (0, import_react.useRef)(null);
	const ratio = (0, import_react.useMemo)(() => {
		if (aspect === "custom") {
			const w = parseNumeric(customW) ?? 1;
			const h = parseNumeric(customH) ?? 1;
			return w / Math.max(h, .01);
		}
		return ASPECTS.find((a) => a.id === aspect)?.value ?? null;
	}, [
		aspect,
		customW,
		customH
	]);
	const box = (0, import_react.useMemo)(() => {
		if (!source) return null;
		const iw = source.img.naturalWidth;
		const ih = source.img.naturalHeight;
		let cw;
		let ch;
		if (!ratio) {
			cw = iw * sizePct / 100;
			ch = ih * sizePct / 100;
		} else if (iw / ih > ratio) {
			ch = ih * sizePct / 100;
			cw = ch * ratio;
		} else {
			cw = iw * sizePct / 100;
			ch = cw / ratio;
		}
		cw = Math.min(iw, Math.max(8, cw));
		ch = Math.min(ih, Math.max(8, ch));
		return {
			x: clampNumber((iw - cw) * (ox / 100), 0, iw - cw),
			y: clampNumber((ih - ch) * (oy / 100), 0, ih - ch),
			w: cw,
			h: ch,
			iw,
			ih
		};
	}, [
		source,
		ratio,
		sizePct,
		ox,
		oy
	]);
	(0, import_react.useEffect)(() => {
		if (!source || !box) return;
		const destW = Math.max(8, Math.round(parseNumeric(exportW) ?? box.w));
		const destH = Math.max(8, Math.round(destW * box.h / box.w));
		const { canvas, ctx } = makeCanvas(destW, destH);
		const r = roundPct / 100 * (Math.min(destW, destH) / 2);
		if (r > 0) {
			ctx.beginPath();
			ctx.roundRect(0, 0, destW, destH, r);
			ctx.clip();
		}
		if (format !== "png") fillColor(ctx, "#f3efe6", destW, destH);
		ctx.drawImage(source.img, box.x, box.y, box.w, box.h, 0, 0, destW, destH);
		canvasToBlob(canvas, MIME[format], .92).then(setBlob);
	}, [
		source,
		box,
		roundPct,
		format,
		exportW,
		setBlob
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				onFile,
				inputId: "crop-file"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				value: aspect,
				onChange: (id) => setAspect(id),
				options: ASPECTS.map((a) => ({
					id: a.id,
					label: a.label
				}))
			}),
			aspect === "custom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Ratio width",
				htmlFor: "crop-rw",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "crop-rw",
					inputMode: "decimal",
					value: customW,
					onChange: (e) => setCustomW(e.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Ratio height",
				htmlFor: "crop-rh",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "crop-rh",
					inputMode: "decimal",
					value: customH,
					onChange: (e) => setCustomH(e.target.value)
				})
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `Frame · ${sizePct}%`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 20,
					max: 100,
					step: 1,
					value: [sizePct],
					onValueChange: (v) => setSizePct(v[0] ?? 80)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Horizontal",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 0,
					max: 100,
					step: 1,
					value: [ox],
					onValueChange: (v) => setOx(v[0] ?? 50)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Vertical",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 0,
					max: 100,
					step: 1,
					value: [oy],
					onValueChange: (v) => setOy(v[0] ?? 50)
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					size: "sm",
					variant: "secondary",
					onClick: () => {
						setOx(50);
						setOy(50);
					},
					children: "Center"
				})
			}),
			source && box ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative touch-none overflow-hidden rounded-sm bg-bg",
				onPointerDown: (e) => {
					e.currentTarget.setPointerCapture(e.pointerId);
					drag.current = {
						x: e.clientX,
						y: e.clientY,
						ox,
						oy
					};
				},
				onPointerMove: (e) => {
					if (!drag.current) return;
					const rect = e.currentTarget.getBoundingClientRect();
					const dx = (e.clientX - drag.current.x) / rect.width * 100;
					const dy = (e.clientY - drag.current.y) / rect.height * 100;
					setOx(clampNumber(drag.current.ox + dx, 0, 100));
					setOy(clampNumber(drag.current.oy + dy, 0, 100));
				},
				onPointerUp: () => {
					drag.current = null;
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: source.url,
					alt: "Source",
					className: "pointer-events-none block w-full select-none",
					draggable: false
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "crop-veil pointer-events-none absolute ring-1 ring-accent",
					style: {
						left: `${box.x / box.iw * 100}%`,
						top: `${box.y / box.ih * 100}%`,
						width: `${box.w / box.iw * 100}%`,
						height: `${box.h / box.ih * 100}%`,
						borderRadius: `${roundPct}%`
					},
					children: thirds ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-0 bottom-0 left-1/3 w-px bg-elevated/70" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-0 bottom-0 left-2/3 w-px bg-elevated/70" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-0 left-0 top-1/3 h-px bg-elevated/70" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-0 left-0 top-2/3 h-px bg-elevated/70" })
					] }) : null
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Drag on the photo to pan the crop."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `Corner radius · ${roundPct}%`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 0,
					max: 50,
					step: 1,
					value: [roundPct],
					onValueChange: (v) => setRoundPct(v[0] ?? 0)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				value: format,
				onChange: (id) => setFormat(id),
				options: FORMAT_OPTIONS
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Advanced, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRow, {
				id: "crop-thirds",
				label: "Rule of thirds",
				checked: thirds,
				onCheckedChange: setThirds
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Export width (px, blank = crop size)",
				htmlFor: "crop-ew",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "crop-ew",
					inputMode: "numeric",
					value: exportW,
					onChange: (e) => setExportW(e.target.value),
					placeholder: box ? String(Math.round(box.w)) : ""
				})
			})] }),
			url ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Crop",
				value: box ? `${Math.round(box.w)} × ${Math.round(box.h)}` : "—",
				large: true
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "File",
				value: size !== null ? formatBytes(size) : "—"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadLink, {
				href: url,
				name: `${stem(source?.file.name ?? "image")}-crop.${extFor(MIME[format])}`
			})] }) : null
		]
	});
}
function ImageConvertTool() {
	const { source, error, onFile } = useSource();
	const [format, setFormat] = (0, import_react.useState)("webp");
	const [quality, setQuality] = (0, import_react.useState)(.85);
	const [matte, setMatte] = (0, import_react.useState)("#f3efe6");
	const { url, size, setBlob } = useBlobUrl();
	const [pack, setPack] = (0, import_react.useState)(null);
	const packRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!source) return;
		let cancel = false;
		const { canvas, ctx } = makeCanvas(source.img.naturalWidth, source.img.naturalHeight);
		if (format !== "png") fillColor(ctx, matte, canvas.width, canvas.height);
		ctx.drawImage(source.img, 0, 0);
		(async () => {
			const blob = await canvasToBlob(canvas, MIME[format], quality);
			const jpegCanvas = makeCanvas(source.img.naturalWidth, source.img.naturalHeight);
			fillColor(jpegCanvas.ctx, matte, jpegCanvas.canvas.width, jpegCanvas.canvas.height);
			jpegCanvas.ctx.drawImage(source.img, 0, 0);
			const pngCanvas = makeCanvas(source.img.naturalWidth, source.img.naturalHeight);
			pngCanvas.ctx.drawImage(source.img, 0, 0);
			const [jpeg, png, webp] = await Promise.all([
				canvasToBlob(jpegCanvas.canvas, MIME.jpeg, quality),
				canvasToBlob(pngCanvas.canvas, MIME.png),
				canvasToBlob(jpegCanvas.canvas, MIME.webp, quality)
			]);
			if (cancel) return;
			setBlob(blob);
			packRef.current = {
				jpeg,
				png,
				webp
			};
			setPack({
				jpeg: jpeg.size,
				png: png.size,
				webp: webp.size
			});
		})();
		return () => {
			cancel = true;
		};
	}, [
		source,
		format,
		quality,
		matte,
		setBlob
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				onFile,
				inputId: "cv-file"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				value: format,
				onChange: (id) => setFormat(id),
				options: FORMAT_OPTIONS
			}),
			format !== "png" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `Quality · ${Math.round(quality * 100)}%`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: .4,
					max: .98,
					step: .01,
					value: [quality],
					onValueChange: (v) => setQuality(v[0] ?? .85)
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Advanced, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
				id: "cv-matte",
				label: "JPEG / WebP matte",
				value: matte,
				onChange: setMatte
			}) }),
			source ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "Original",
					value: `${source.file.type || "image"} · ${formatBytes(source.file.size)}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
					label: "This format",
					value: size !== null ? formatBytes(size) : "—",
					large: true
				}),
				pack ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
						label: "JPEG",
						value: formatBytes(pack.jpeg)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
						label: "PNG",
						value: formatBytes(pack.png)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
						label: "WebP",
						value: formatBytes(pack.webp)
					})
				] }) : null
			] }) : null,
			source && url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompareFrame, {
				before: source.url,
				after: url
			}) : source ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Preview, {
				src: source.url,
				alt: "Original"
			}) : null,
			url && source ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadLink, {
					href: url,
					name: `${stem(source.file.name)}.${extFor(MIME[format])}`
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "secondary",
					onClick: () => {
						const blobs = packRef.current;
						if (!blobs) return;
						const base = stem(source.file.name);
						downloadBlob(blobs.jpeg, `${base}.jpg`);
						downloadBlob(blobs.png, `${base}.png`);
						downloadBlob(blobs.webp, `${base}.webp`);
					},
					children: "Download all three"
				})]
			}) : null
		]
	});
}
function ImageRotateTool() {
	const { source, error, onFile } = useSource();
	const [angle, setAngle] = (0, import_react.useState)(0);
	const [flipH, setFlipH] = (0, import_react.useState)(false);
	const [flipV, setFlipV] = (0, import_react.useState)(false);
	const [expand, setExpand] = (0, import_react.useState)(true);
	const [format, setFormat] = (0, import_react.useState)("png");
	const [matte, setMatte] = (0, import_react.useState)("#f3efe6");
	const { url, setBlob } = useBlobUrl();
	(0, import_react.useEffect)(() => {
		if (!source) return;
		const rad = angle * Math.PI / 180;
		const iw = source.img.naturalWidth;
		const ih = source.img.naturalHeight;
		const size = expand ? rotatedSize(iw, ih, rad) : {
			width: iw,
			height: ih
		};
		const { canvas, ctx } = makeCanvas(size.width, size.height);
		if (format !== "png" || !expand) fillColor(ctx, matte, canvas.width, canvas.height);
		ctx.translate(canvas.width / 2, canvas.height / 2);
		ctx.rotate(rad);
		ctx.scale(flipH ? -1 : 1, flipV ? -1 : 1);
		ctx.drawImage(source.img, -iw / 2, -ih / 2);
		canvasToBlob(canvas, MIME[format], .92).then(setBlob);
	}, [
		source,
		angle,
		flipH,
		flipV,
		expand,
		format,
		matte,
		setBlob
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				onFile,
				inputId: "rot-file"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						onClick: () => setAngle((n) => n - 90),
						children: "−90°"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						onClick: () => setAngle((n) => n + 90),
						children: "+90°"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: flipH ? "default" : "secondary",
						onClick: () => setFlipH((v) => !v),
						children: "Flip H"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: flipV ? "default" : "secondary",
						onClick: () => setFlipV((v) => !v),
						children: "Flip V"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						onClick: () => {
							setAngle(0);
							setFlipH(false);
							setFlipV(false);
						},
						children: "Reset"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `Straighten · ${angle}°`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: -180,
					max: 180,
					step: 1,
					value: [angle],
					onValueChange: (v) => setAngle(v[0] ?? 0)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRow, {
				id: "rot-expand",
				label: "Expand canvas to fit",
				checked: expand,
				onCheckedChange: setExpand
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Advanced, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				value: format,
				onChange: (id) => setFormat(id),
				options: FORMAT_OPTIONS
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
				id: "rot-matte",
				label: "Background",
				value: matte,
				onChange: setMatte
			})] }),
			url && source ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompareFrame, {
				before: source.url,
				after: url
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadLink, {
				href: url,
				name: `${stem(source.file.name)}-rotated.${extFor(MIME[format])}`
			})] }) : null
		]
	});
}
var FILTER_PRESETS = [
	{
		id: "none",
		label: "None",
		value: {
			gray: 0,
			bright: 100,
			contrast: 100,
			sat: 100,
			blur: 0,
			hue: 0,
			vig: 0,
			sepia: false,
			invert: false
		}
	},
	{
		id: "punch",
		label: "Punch",
		value: {
			gray: 0,
			bright: 104,
			contrast: 124,
			sat: 118,
			blur: 0,
			hue: 0,
			vig: .12,
			sepia: false,
			invert: false
		}
	},
	{
		id: "fade",
		label: "Fade",
		value: {
			gray: 8,
			bright: 110,
			contrast: 86,
			sat: 78,
			blur: 0,
			hue: 8,
			vig: .18,
			sepia: false,
			invert: false
		}
	},
	{
		id: "warm",
		label: "Warm",
		value: {
			gray: 0,
			bright: 106,
			contrast: 108,
			sat: 112,
			blur: 0,
			hue: -12,
			vig: .08,
			sepia: false,
			invert: false
		}
	},
	{
		id: "cool",
		label: "Cool",
		value: {
			gray: 0,
			bright: 102,
			contrast: 110,
			sat: 96,
			blur: 0,
			hue: 18,
			vig: .1,
			sepia: false,
			invert: false
		}
	},
	{
		id: "noir",
		label: "Noir",
		value: {
			gray: 100,
			bright: 98,
			contrast: 132,
			sat: 0,
			blur: 0,
			hue: 0,
			vig: .48,
			sepia: false,
			invert: false
		}
	},
	{
		id: "film",
		label: "Film",
		value: {
			gray: 0,
			bright: 102,
			contrast: 114,
			sat: 88,
			blur: 0,
			hue: -6,
			vig: .22,
			sepia: true,
			invert: false
		}
	}
];
function ImageFiltersTool() {
	const { source, error, onFile } = useSource();
	const [f, setF] = (0, import_react.useState)(FILTER_PRESETS[0].value);
	const [preset, setPreset] = (0, import_react.useState)("none");
	const [format, setFormat] = (0, import_react.useState)("png");
	const { url, setBlob } = useBlobUrl();
	(0, import_react.useEffect)(() => {
		if (!source) return;
		const { canvas, ctx } = makeCanvas(source.img.naturalWidth, source.img.naturalHeight);
		ctx.filter = [
			`grayscale(${f.gray}%)`,
			`brightness(${f.bright}%)`,
			`contrast(${f.contrast}%)`,
			`saturate(${f.sat}%)`,
			`hue-rotate(${f.hue}deg)`,
			`blur(${f.blur}px)`,
			f.sepia ? "sepia(0.65)" : "",
			f.invert ? "invert(1)" : ""
		].filter(Boolean).join(" ");
		ctx.drawImage(source.img, 0, 0);
		ctx.filter = "none";
		applyVignette(ctx, canvas.width, canvas.height, f.vig);
		canvasToBlob(canvas, MIME[format], .92).then(setBlob);
	}, [
		source,
		f,
		format,
		setBlob
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				onFile,
				inputId: "fx-file"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				value: preset,
				onChange: (id) => {
					setPreset(id);
					const found = FILTER_PRESETS.find((p) => p.id === id);
					if (found) setF(found.value);
				},
				options: FILTER_PRESETS.map((p) => ({
					id: p.id,
					label: p.label
				}))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `Brightness · ${f.bright}%`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 40,
					max: 180,
					step: 1,
					value: [f.bright],
					onValueChange: (v) => {
						setPreset("custom");
						setF((s) => ({
							...s,
							bright: v[0] ?? 100
						}));
					}
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `Contrast · ${f.contrast}%`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 40,
					max: 180,
					step: 1,
					value: [f.contrast],
					onValueChange: (v) => {
						setPreset("custom");
						setF((s) => ({
							...s,
							contrast: v[0] ?? 100
						}));
					}
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `Saturation · ${f.sat}%`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 0,
					max: 200,
					step: 1,
					value: [f.sat],
					onValueChange: (v) => {
						setPreset("custom");
						setF((s) => ({
							...s,
							sat: v[0] ?? 100
						}));
					}
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Advanced, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: `Hue · ${f.hue}°`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: -180,
						max: 180,
						step: 1,
						value: [f.hue],
						onValueChange: (v) => {
							setPreset("custom");
							setF((s) => ({
								...s,
								hue: v[0] ?? 0
							}));
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: `Grayscale · ${f.gray}%`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: 0,
						max: 100,
						step: 1,
						value: [f.gray],
						onValueChange: (v) => {
							setPreset("custom");
							setF((s) => ({
								...s,
								gray: v[0] ?? 0
							}));
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: `Blur · ${f.blur}px`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: 0,
						max: 12,
						step: 1,
						value: [f.blur],
						onValueChange: (v) => {
							setPreset("custom");
							setF((s) => ({
								...s,
								blur: v[0] ?? 0
							}));
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: `Vignette · ${Math.round(f.vig * 100)}%`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: 0,
						max: .7,
						step: .01,
						value: [f.vig],
						onValueChange: (v) => {
							setPreset("custom");
							setF((s) => ({
								...s,
								vig: v[0] ?? 0
							}));
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "sm",
						variant: f.sepia ? "default" : "secondary",
						onClick: () => {
							setPreset("custom");
							setF((s) => ({
								...s,
								sepia: !s.sepia
							}));
						},
						children: "Sepia"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "sm",
						variant: f.invert ? "default" : "secondary",
						onClick: () => {
							setPreset("custom");
							setF((s) => ({
								...s,
								invert: !s.invert
							}));
						},
						children: "Invert"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					value: format,
					onChange: (id) => setFormat(id),
					options: FORMAT_OPTIONS
				})
			] }),
			url && source ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompareFrame, {
				before: source.url,
				after: url
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadLink, {
				href: url,
				name: `${stem(source.file.name)}-edit.${extFor(MIME[format])}`
			})] }) : null
		]
	});
}
function ImagePaletteTool() {
	const { source, error, onFile } = useSource();
	const [count, setCount] = (0, import_react.useState)(6);
	const colors = (0, import_react.useMemo)(() => source ? extractPalette(source.img, count) : [], [source, count]);
	const css = colors.map((c, i) => `  --swatch-${i + 1}: ${c};`).join("\n");
	const json = JSON.stringify(colors, null, 2);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				onFile,
				inputId: "pal-file"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `Swatches · ${count}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 3,
					max: 10,
					step: 1,
					value: [count],
					onValueChange: (v) => setCount(v[0] ?? 6)
				})
			}),
			source ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Preview, {
				src: source.url,
				alt: "Source"
			}) : null,
			colors.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
				children: colors.map((hex) => {
					const rgb = hexToRgb(hex);
					const hsl = rgb ? rgbToHsl(...rgb) : "";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex flex-col overflow-hidden rounded-md text-left shadow-card",
						onClick: () => void copyText(hex, "Copied colour"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "h-16 w-full",
							style: { backgroundColor: hex }
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "bg-elevated px-3 py-2 font-mono text-xs",
							children: [hex, hsl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-1 block text-muted",
								children: [
									"hsl(",
									hsl,
									")"
								]
							}) : null]
						})]
					}, hex);
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
						value: colors.join("\n"),
						label: "Copy hex list"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
						value: `:root {\n${css}\n}`,
						label: "Copy CSS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
						value: json,
						label: "Copy JSON"
					})
				]
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Tap a swatch to copy its hex value."
			})
		]
	});
}
function ImageWatermarkTool() {
	const photo = useSource();
	const mark = useSource();
	const [text, setText] = (0, import_react.useState)("Datum");
	const [pos, setPos] = (0, import_react.useState)("br");
	const [size, setSize] = (0, import_react.useState)(6);
	const [opacity, setOpacity] = (0, import_react.useState)(.55);
	const [fill, setFill] = (0, import_react.useState)("#faf8f3");
	const [stroke, setStroke] = (0, import_react.useState)("#1a1916");
	const [angle, setAngle] = (0, import_react.useState)(0);
	const [tile, setTile] = (0, import_react.useState)(false);
	const [useStroke, setUseStroke] = (0, import_react.useState)(true);
	const { url, setBlob } = useBlobUrl();
	(0, import_react.useEffect)(() => {
		if (!photo.source) return;
		const img = photo.source.img;
		const { canvas, ctx } = makeCanvas(img.naturalWidth, img.naturalHeight);
		ctx.drawImage(img, 0, 0);
		ctx.save();
		ctx.globalAlpha = opacity;
		const minSide = Math.min(canvas.width, canvas.height);
		const px = Math.max(12, Math.round(minSide * size / 100));
		const pad = Math.round(px * .8);
		const drawMark = (x, y, rot) => {
			ctx.save();
			ctx.translate(x, y);
			ctx.rotate(rot * Math.PI / 180);
			if (mark.source) {
				const mw = minSide * size / 20;
				const mh = mw * mark.source.img.naturalHeight / mark.source.img.naturalWidth;
				ctx.drawImage(mark.source.img, -mw / 2, -mh / 2, mw, mh);
			} else {
				ctx.font = `600 ${px}px "Sora", system-ui, sans-serif`;
				ctx.textAlign = "center";
				ctx.textBaseline = "middle";
				if (useStroke) {
					ctx.lineWidth = Math.max(1, px * .08);
					ctx.strokeStyle = stroke;
					ctx.strokeText(text || " ", 0, 0);
				}
				ctx.fillStyle = fill;
				ctx.fillText(text || " ", 0, 0);
			}
			ctx.restore();
		};
		if (tile) {
			const step = Math.max(80, px * 6);
			for (let y = step / 2; y < canvas.height + step; y += step) for (let x = step / 2; x < canvas.width + step; x += step) drawMark(x, y, angle || -24);
		} else drawMark(pos === "tl" || pos === "bl" ? pad + px : pos === "tr" || pos === "br" ? canvas.width - pad - px : canvas.width / 2, pos === "tl" || pos === "tr" ? pad + px : pos === "bl" || pos === "br" ? canvas.height - pad - px : canvas.height / 2, angle);
		ctx.restore();
		canvasToBlob(canvas, "image/png").then(setBlob);
	}, [
		photo.source,
		mark.source,
		text,
		pos,
		size,
		opacity,
		fill,
		stroke,
		angle,
		tile,
		useStroke,
		setBlob
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				onFile: photo.onFile,
				inputId: "wm-photo"
			}),
			photo.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: photo.error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Text",
				htmlFor: "wm-t",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "wm-t",
					value: text,
					onChange: (e) => setText(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				value: pos,
				onChange: setPos,
				options: [
					{
						id: "tl",
						label: "Top left"
					},
					{
						id: "tr",
						label: "Top right"
					},
					{
						id: "c",
						label: "Center"
					},
					{
						id: "bl",
						label: "Bottom left"
					},
					{
						id: "br",
						label: "Bottom right"
					}
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `Size · ${size}%`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 2,
					max: 18,
					step: 1,
					value: [size],
					onValueChange: (v) => setSize(v[0] ?? 6)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: `Opacity · ${Math.round(opacity * 100)}%`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: .12,
					max: 1,
					step: .01,
					value: [opacity],
					onValueChange: (v) => setOpacity(v[0] ?? .55)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Advanced, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
					onFile: mark.onFile,
					label: "Logo (optional)",
					inputId: "wm-mark",
					hint: "Use a PNG with transparency."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRow, {
					id: "wm-tile",
					label: "Repeat across the photo",
					checked: tile,
					onCheckedChange: setTile
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: `Rotation · ${angle}°`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
						min: -90,
						max: 90,
						step: 1,
						value: [angle],
						onValueChange: (v) => setAngle(v[0] ?? 0)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRow, {
					id: "wm-stroke",
					label: "Text outline",
					checked: useStroke,
					onCheckedChange: setUseStroke
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
					id: "wm-c",
					label: "Fill",
					value: fill,
					onChange: setFill
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
					id: "wm-s",
					label: "Outline",
					value: stroke,
					onChange: setStroke
				})] })
			] }),
			url && photo.source ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompareFrame, {
				before: photo.source.url,
				after: url
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadLink, {
				href: url,
				name: `${stem(photo.source.file.name)}-mark.png`
			})] }) : null
		]
	});
}
function ImagePlaceholderTool() {
	const [w, setW] = (0, import_react.useState)("1200");
	const [h, setH] = (0, import_react.useState)("630");
	const [bg, setBg] = (0, import_react.useState)("#24554e");
	const [fg, setFg] = (0, import_react.useState)("#faf8f3");
	const [label, setLabel] = (0, import_react.useState)("");
	const [sub, setSub] = (0, import_react.useState)("");
	const [pattern, setPattern] = (0, import_react.useState)("solid");
	const [retina, setRetina] = (0, import_react.useState)(false);
	const [format, setFormat] = (0, import_react.useState)("png");
	const { url, setBlob } = useBlobUrl();
	const width = Math.max(1, Math.min(4e3, Math.round(parseNumeric(w) ?? 0)));
	const height = Math.max(1, Math.min(4e3, Math.round(parseNumeric(h) ?? 0)));
	const caption = label.trim() || `${width} × ${height}`;
	const scale = retina ? 2 : 1;
	(0, import_react.useEffect)(() => {
		if (!width || !height) return;
		const cw = width * scale;
		const ch = height * scale;
		const { canvas, ctx } = makeCanvas(cw, ch);
		fillColor(ctx, bg, cw, ch);
		if (pattern === "grid") {
			ctx.strokeStyle = fg;
			ctx.globalAlpha = .18;
			ctx.lineWidth = scale;
			const step = 48 * scale;
			for (let x = 0; x <= cw; x += step) {
				ctx.beginPath();
				ctx.moveTo(x, 0);
				ctx.lineTo(x, ch);
				ctx.stroke();
			}
			for (let y = 0; y <= ch; y += step) {
				ctx.beginPath();
				ctx.moveTo(0, y);
				ctx.lineTo(cw, y);
				ctx.stroke();
			}
			ctx.globalAlpha = 1;
		}
		if (pattern === "checker") {
			const cell = 32 * scale;
			ctx.fillStyle = fg;
			ctx.globalAlpha = .12;
			for (let y = 0; y < ch; y += cell) for (let x = 0; x < cw; x += cell) if ((x / cell + y / cell) % 2 === 0) ctx.fillRect(x, y, cell, cell);
			ctx.globalAlpha = 1;
		}
		ctx.fillStyle = fg;
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		const px = Math.max(14, Math.round(Math.min(cw, ch) / 12));
		ctx.font = `600 ${px}px "Sora", system-ui, sans-serif`;
		ctx.fillText(caption, cw / 2, ch / 2 - (sub.trim() ? px * .4 : 0));
		if (sub.trim()) {
			ctx.font = `500 ${Math.round(px * .45)}px "Sora", system-ui, sans-serif`;
			ctx.globalAlpha = .8;
			ctx.fillText(sub.trim(), cw / 2, ch / 2 + px * .55);
			ctx.globalAlpha = 1;
		}
		canvasToBlob(canvas, MIME[format], .92).then(setBlob);
	}, [
		width,
		height,
		bg,
		fg,
		caption,
		sub,
		pattern,
		scale,
		format,
		setBlob
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Width (px)",
				htmlFor: "ph-w",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "ph-w",
					inputMode: "numeric",
					value: w,
					onChange: (e) => setW(e.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Height (px)",
				htmlFor: "ph-h",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "ph-h",
					inputMode: "numeric",
					value: h,
					onChange: (e) => setH(e.target.value)
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Label",
				htmlFor: "ph-l",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "ph-l",
					value: label,
					onChange: (e) => setLabel(e.target.value),
					placeholder: `${width} × ${height}`
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				value: pattern,
				onChange: (id) => setPattern(id),
				options: [
					{
						id: "solid",
						label: "Solid"
					},
					{
						id: "grid",
						label: "Grid"
					},
					{
						id: "checker",
						label: "Checker"
					}
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
				id: "ph-bg",
				label: "Background",
				value: bg,
				onChange: setBg
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
				id: "ph-fg",
				label: "Ink",
				value: fg,
				onChange: setFg
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					{
						w: 1200,
						h: 630,
						label: "OG card"
					},
					{
						w: 1080,
						h: 1080,
						label: "Square"
					},
					{
						w: 1080,
						h: 1920,
						label: "Story"
					},
					{
						w: 16,
						h: 16,
						label: "Favicon"
					}
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					size: "sm",
					variant: "secondary",
					onClick: () => {
						setW(String(item.w));
						setH(String(item.h));
					},
					children: item.label
				}, item.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Advanced, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Subtitle",
					htmlFor: "ph-s",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "ph-s",
						value: sub,
						onChange: (e) => setSub(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRow, {
					id: "ph-2x",
					label: "Retina @2x",
					checked: retina,
					onCheckedChange: setRetina
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					value: format,
					onChange: (id) => setFormat(id),
					options: FORMAT_OPTIONS
				})
			] }),
			url ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Preview, {
				src: url,
				alt: "Placeholder preview"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadLink, {
				href: url,
				name: `placeholder-${width}x${height}${retina ? "@2x" : ""}.${extFor(MIME[format])}`
			})] }) : null
		]
	});
}
function pad(n, size = 2) {
	return String(n).padStart(size, "0");
}
function formatMs(ms) {
	const total = Math.max(0, Math.floor(ms));
	const minutes = Math.floor(total / 6e4);
	const seconds = Math.floor(total % 6e4 / 1e3);
	const tenths = Math.floor(total % 1e3 / 10);
	return `${pad(minutes)}:${pad(seconds)}.${pad(tenths)}`;
}
function StopwatchTool() {
	const [mode, setMode] = (0, import_react.useState)("stopwatch");
	const [running, setRunning] = (0, import_react.useState)(false);
	const [elapsed, setElapsed] = (0, import_react.useState)(0);
	const [laps, setLaps] = (0, import_react.useState)([]);
	const started = (0, import_react.useRef)(null);
	const base = (0, import_react.useRef)(0);
	const [mins, setMins] = (0, import_react.useState)("5");
	const [secs, setSecs] = (0, import_react.useState)("0");
	const [remain, setRemain] = (0, import_react.useState)(3e5);
	(0, import_react.useEffect)(() => {
		if (!running) return;
		const id = window.setInterval(() => {
			if (mode === "stopwatch" && started.current !== null) setElapsed(base.current + (performance.now() - started.current));
			if (mode === "timer") setRemain((prev) => {
				const next = prev - 100;
				if (next <= 0) {
					setRunning(false);
					return 0;
				}
				return next;
			});
		}, 80);
		return () => window.clearInterval(id);
	}, [running, mode]);
	const startStopwatch = () => {
		started.current = performance.now();
		setRunning(true);
	};
	const pauseStopwatch = () => {
		if (started.current !== null) base.current += performance.now() - started.current;
		started.current = null;
		setRunning(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
		value: mode,
		onValueChange: (v) => {
			setMode(v);
			setRunning(false);
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
				value: "stopwatch",
				children: "Stopwatch"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
				value: "timer",
				children: "Timer"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
				value: "stopwatch",
				className: "flex flex-col gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-center text-4xl font-semibold tabular-nums",
						children: formatMs(elapsed)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap justify-center gap-2",
						children: [
							running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: pauseStopwatch,
								children: "Pause"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: startStopwatch,
								children: "Start"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "secondary",
								onClick: () => setLaps((prev) => [elapsed, ...prev].slice(0, 20)),
								disabled: elapsed === 0,
								children: "Lap"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								onClick: () => {
									setRunning(false);
									setElapsed(0);
									setLaps([]);
									started.current = null;
									base.current = 0;
								},
								children: "Reset"
							})
						]
					}),
					laps.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "space-y-1 text-sm tabular-nums text-muted",
						children: laps.map((lap, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"Lap ",
							laps.length - i,
							": ",
							formatMs(lap)
						] }, `${lap}-${i}`))
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
				value: "timer",
				className: "flex flex-col gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Minutes",
						htmlFor: "tm-m",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "tm-m",
							inputMode: "numeric",
							value: mins,
							onChange: (e) => setMins(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Seconds",
						htmlFor: "tm-s",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "tm-s",
							inputMode: "numeric",
							value: secs,
							onChange: (e) => setSecs(e.target.value)
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-center text-4xl font-semibold tabular-nums",
						children: formatMs(remain)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap justify-center gap-2",
						children: [running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							onClick: () => setRunning(false),
							children: "Pause"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							onClick: () => {
								if (remain <= 0) {
									const m = parseNumeric(mins) ?? 0;
									const s = parseNumeric(secs) ?? 0;
									setRemain((m * 60 + s) * 1e3);
								}
								setRunning(true);
							},
							children: "Start"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							onClick: () => {
								const m = parseNumeric(mins) ?? 0;
								const s = parseNumeric(secs) ?? 0;
								setRunning(false);
								setRemain((m * 60 + s) * 1e3);
							},
							children: "Reset"
						})]
					})
				]
			})
		]
	}) });
}
function diffYMD(from, to) {
	let years = to.getFullYear() - from.getFullYear();
	let months = to.getMonth() - from.getMonth();
	let days = to.getDate() - from.getDate();
	if (days < 0) {
		months -= 1;
		const prev = new Date(to.getFullYear(), to.getMonth(), 0).getDate();
		days += prev;
	}
	if (months < 0) {
		years -= 1;
		months += 12;
	}
	return {
		years,
		months,
		days
	};
}
function AgeCalculatorTool() {
	const today = /* @__PURE__ */ new Date();
	const iso = (d) => d.toISOString().slice(0, 10);
	const [birth, setBirth] = (0, import_react.useState)("1994-06-15");
	const [other, setOther] = (0, import_react.useState)(iso(today));
	const start = (0, import_react.useMemo)(() => /* @__PURE__ */ new Date(`${birth}T00:00:00`), [birth]);
	const end = (0, import_react.useMemo)(() => /* @__PURE__ */ new Date(`${other}T00:00:00`), [other]);
	const valid = !Number.isNaN(start.getTime()) && !Number.isNaN(end.getTime()) && end >= start;
	const span = valid ? diffYMD(start, end) : null;
	const totalDays = valid ? Math.round((end.getTime() - start.getTime()) / 864e5) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "From date (birth date)",
			htmlFor: "age-from",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: "age-from",
				type: "date",
				value: birth,
				onChange: (e) => setBirth(e.target.value)
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "To date",
			htmlFor: "age-to",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: "age-to",
				type: "date",
				value: other,
				onChange: (e) => setOther(e.target.value)
			})
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Years",
				value: span ? String(span.years) : "—",
				large: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Months",
				value: span ? String(span.months) : "—"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Days",
				value: span ? String(span.days) : "—"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Total days",
				value: totalDays !== null ? String(totalDays) : "—",
				copy: true
			})
		] })]
	});
}
var DEFAULT_CITIES = [
	"America/New_York",
	"Europe/London",
	"Asia/Dubai",
	"Asia/Tokyo"
];
function WorldClockTool() {
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const [cities, setCities] = (0, import_react.useState)(DEFAULT_CITIES);
	const [add, setAdd] = (0, import_react.useState)("Australia/Sydney");
	(0, import_react.useEffect)(() => {
		const stored = localStorage.getItem("datum-world-clock");
		if (stored) try {
			const parsed = JSON.parse(stored);
			if (Array.isArray(parsed) && parsed.length) setCities(parsed);
		} catch {}
		const id = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 1e3);
		return () => window.clearInterval(id);
	}, []);
	(0, import_react.useEffect)(() => {
		localStorage.setItem("datum-world-clock", JSON.stringify(cities));
	}, [cities]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-2 sm:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: add,
				onValueChange: setAdd,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					"aria-label": "Add city",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: ZONES.map((zone) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: zone.id,
					children: zone.label
				}, zone.id)) })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "secondary",
				onClick: () => setCities((prev) => prev.includes(add) ? prev : [...prev, add]),
				children: "Add city"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-2",
			children: cities.map((id) => {
				const label = ZONES.find((z) => z.id === id)?.label ?? id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 rounded-sm bg-bg px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: id
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg font-semibold tabular-nums",
							children: fmtZone(now, id)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "sm",
							onClick: () => setCities((prev) => prev.filter((c) => c !== id)),
							children: "Remove"
						})]
					})]
				}, id);
			})
		})]
	});
}
function beep() {
	const ctx = new AudioContext();
	const osc = ctx.createOscillator();
	const gain = ctx.createGain();
	osc.frequency.value = 880;
	gain.gain.value = .05;
	osc.connect(gain);
	gain.connect(ctx.destination);
	osc.start();
	osc.stop(ctx.currentTime + .25);
}
function PomodoroTool() {
	const [work, setWork] = (0, import_react.useState)("25");
	const [brk, setBrk] = (0, import_react.useState)("5");
	const [phase, setPhase] = (0, import_react.useState)("focus");
	const [remain, setRemain] = (0, import_react.useState)(1500);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [sessions, setSessions] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!running) return;
		const id = window.setInterval(() => {
			setRemain((prev) => {
				if (prev <= 1) {
					beep();
					if (phase === "focus") {
						setSessions((n) => n + 1);
						setPhase("break");
						return (parseNumeric(brk) ?? 5) * 60;
					}
					setPhase("focus");
					return (parseNumeric(work) ?? 25) * 60;
				}
				return prev - 1;
			});
		}, 1e3);
		return () => window.clearInterval(id);
	}, [
		running,
		phase,
		brk,
		work
	]);
	const mm = Math.floor(remain / 60);
	const ss = remain % 60;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolForm, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Focus minutes",
				htmlFor: "po-w",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "po-w",
					inputMode: "numeric",
					value: work,
					onChange: (e) => setWork(e.target.value)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Break minutes",
				htmlFor: "po-b",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "po-b",
					inputMode: "numeric",
					value: brk,
					onChange: (e) => setBrk(e.target.value)
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "drawing-label text-center",
				children: phase === "focus" ? "Focus" : "Break"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-display text-center text-5xl font-semibold tabular-nums",
				children: [
					pad(mm),
					":",
					pad(ss)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap justify-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: () => setRunning((v) => !v),
					children: running ? "Pause" : "Start"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					onClick: () => {
						setRunning(false);
						setPhase("focus");
						setRemain((parseNumeric(work) ?? 25) * 60);
					},
					children: "Reset"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ResultPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				label: "Completed focus sessions",
				value: String(sessions)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "pt-2 text-sm text-muted",
				children: [
					"Target ratio is typically ",
					formatFixed((parseNumeric(work) ?? 25) / ((parseNumeric(brk) ?? 5) || 1), 1),
					":1 focus to break."
				]
			})] })
		]
	});
}
function splitDuration(ms) {
	const total = Math.max(0, Math.floor(ms / 1e3));
	return {
		days: Math.floor(total / 86400),
		hours: Math.floor(total % 86400 / 3600),
		minutes: Math.floor(total % 3600 / 60),
		seconds: total % 60,
		past: ms < 0
	};
}
function CountdownTool() {
	const [target, setTarget] = (0, import_react.useState)(() => {
		const d = /* @__PURE__ */ new Date();
		d.setDate(d.getDate() + 14);
		d.setMinutes(0, 0, 0);
		return (/* @__PURE__ */ new Date(d.getTime() - d.getTimezoneOffset() * 6e4)).toISOString().slice(0, 16);
	});
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setNow(Date.now()), 250);
		return () => window.clearInterval(id);
	}, []);
	const parts = (0, import_react.useMemo)(() => {
		const t = new Date(target).getTime();
		if (!Number.isFinite(t)) return null;
		return splitDuration(t - now);
	}, [target, now]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToolPanel, {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Date and time",
			htmlFor: "cd-t",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: "cd-t",
				type: "datetime-local",
				value: target,
				onChange: (e) => setTarget(e.target.value)
			})
		}), parts ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "drawing-label text-center",
			children: parts.past ? "Elapsed" : "Remaining"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-4 gap-2 text-center",
			children: [
				{
					label: "Days",
					value: parts.days
				},
				{
					label: "Hours",
					value: parts.hours
				},
				{
					label: "Minutes",
					value: parts.minutes
				},
				{
					label: "Seconds",
					value: parts.seconds
				}
			].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-sm bg-bg px-2 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl font-semibold tabular-nums",
					children: item.value
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "drawing-label mt-1",
					children: item.label
				})]
			}, item.label))
		})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Enter a valid date."
		})]
	});
}
var toolComponents = {
	calculator: CalculatorTool,
	percentage: PercentageTool,
	"bmi-calculator": BmiCalculatorTool,
	"tip-calculator": TipCalculatorTool,
	"discount-calculator": DiscountCalculatorTool,
	"vat-calculator": VatCalculatorTool,
	"loan-calculator": LoanCalculatorTool,
	"compound-interest": CompoundInterestTool,
	"salary-converter": SalaryConverterTool,
	"split-bill": SplitBillTool,
	"fuel-cost": FuelCostTool,
	"unit-converter": UnitConverterTool,
	"color-converter": ColorConverterTool,
	"unix-timestamp": UnixTimestampTool,
	"number-base": NumberBaseTool,
	"timezone-converter": TimezoneConverterTool,
	"word-counter": WordCounterTool,
	"case-converter": CaseConverterTool,
	"text-cleaner": TextCleanerTool,
	"text-diff": TextDiffTool,
	"lorem-ipsum": LoremIpsumTool,
	"markdown-preview": MarkdownPreviewTool,
	"password-generator": PasswordGeneratorTool,
	"qr-code": QrCodeTool,
	"image-compressor": ImageCompressorTool,
	"image-resizer": ImageResizerTool,
	"image-crop": ImageCropTool,
	"image-convert": ImageConvertTool,
	"image-rotate": ImageRotateTool,
	"image-filters": ImageFiltersTool,
	"image-palette": ImagePaletteTool,
	"image-watermark": ImageWatermarkTool,
	"image-placeholder": ImagePlaceholderTool,
	"uuid-generator": UuidGeneratorTool,
	"random-number": RandomNumberTool,
	"json-formatter": JsonFormatterTool,
	base64: Base64Tool,
	"image-base64": ImageBase64Tool,
	"url-encoder": UrlEncoderTool,
	"hash-generator": HashGeneratorTool,
	stopwatch: StopwatchTool,
	"age-calculator": AgeCalculatorTool,
	countdown: CountdownTool,
	"world-clock": WorldClockTool,
	pomodoro: PomodoroTool
};
function ToolPage() {
	const { tool } = Route.useLoaderData();
	const Component = toolComponents[tool.slug];
	const category = getCategory(tool.category);
	const related = relatedTools(tool.slug);
	const touch = useToolPrefs((s) => s.touch);
	const toggleFavorite = useToolPrefs((s) => s.toggleFavorite);
	const favorite = useToolPrefs((s) => s.favorites.includes(tool.slug));
	(0, import_react.useEffect)(() => {
		touch(tool.slug);
	}, [tool.slug, touch]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex max-w-6xl flex-col gap-8 px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JsonLd, { data: {
				"@context": "https://schema.org",
				"@type": "WebApplication",
				name: tool.name,
				applicationCategory: "UtilitiesApplication",
				operatingSystem: "Any",
				description: tool.seoDescription,
				offers: {
					"@type": "Offer",
					price: "0",
					priceCurrency: "USD"
				},
				isAccessibleForFree: true
			} }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JsonLd, { data: {
				"@context": "https://schema.org",
				"@type": "BreadcrumbList",
				itemListElement: [
					{
						"@type": "ListItem",
						position: 1,
						name: "Home",
						item: "/"
					},
					{
						"@type": "ListItem",
						position: 2,
						name: "Tools",
						item: "/tools"
					},
					{
						"@type": "ListItem",
						position: 3,
						name: tool.name
					}
				]
			} }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JsonLd, { data: {
				"@context": "https://schema.org",
				"@type": "HowTo",
				name: `Use the ${tool.name}`,
				description: tool.seoDescription,
				step: [
					{
						"@type": "HowToStep",
						name: "Open the tool",
						text: `Open the free ${tool.name} in your browser. No account is required.`
					},
					{
						"@type": "HowToStep",
						name: "Enter values",
						text: "Type or paste your input. Processing happens on this device."
					},
					{
						"@type": "HowToStep",
						name: "Copy the result",
						text: "Read the result and copy it if you need it elsewhere."
					}
				]
			} }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "text-sm text-muted",
				"aria-label": "Breadcrumb",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "hover:text-fg",
							children: "Home"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							"aria-hidden": "true",
							children: "/"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/tools",
							className: "hover:text-fg",
							children: "Tools"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							"aria-hidden": "true",
							children: "/"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-fg",
							children: tool.name
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "drawing-label",
							children: [
								category?.index,
								" ",
								category?.label
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl font-semibold tracking-tight",
							children: tool.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-2xl text-muted",
							children: tool.description
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "secondary",
					onClick: () => toggleFavorite(tool.slug),
					"aria-pressed": favorite,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: cn("size-4", favorite && "fill-fg") }), favorite ? "Saved" : "Save"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-[minmax(0,1fr)_18rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-w-0",
					children: Component ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Component, {}) : null
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "flex flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdSlot, { slot: "sidebar" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-surface p-4 shadow-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "drawing-label mb-2",
								children: "On this device"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "This tool processes data in your browser. Refreshing the page clears what you typed, except where noted."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-surface p-4 shadow-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "drawing-label mb-2",
								children: "About"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: tool.seoDescription
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdSlot, { slot: "toolBottom" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold",
					children: "Related tools"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
					children: related.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolCard, { tool: item }, item.slug))
				})]
			})
		]
	});
}
//#endregion
export { ToolPage as component };
