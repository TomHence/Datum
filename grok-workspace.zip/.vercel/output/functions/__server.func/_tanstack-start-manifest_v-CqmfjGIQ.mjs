//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CqmfjGIQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/privacy",
			"/sitemap.xml",
			"/tools/$slug",
			"/tools/"
		],
		preloads: [
			"/assets/index-DQfJ0RNF.js",
			"/assets/site-BHTT261D.js",
			"/assets/catalog-Fe-Fvn2i.js",
			"/assets/preload-helper-BIYnXy-g.js",
			"/assets/tool-icon-CsJIeIqM.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DQfJ0RNF.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-C-NuSINs.js",
			"/assets/json-ld-BEII0hvp.js",
			"/assets/input-DcTSDW5c.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-DgAHYjwV.js"]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-DHhBHp2K.js"]
	},
	"/tools/$slug": {
		filePath: "/workspace/src/routes/tools/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-D2Sq2Wjd.js",
			"/assets/json-ld-BEII0hvp.js",
			"/assets/input-DcTSDW5c.js"
		]
	},
	"/tools/": {
		filePath: "/workspace/src/routes/tools/index.tsx",
		children: void 0,
		preloads: ["/assets/tools-cF-nSnwH.js", "/assets/input-DcTSDW5c.js"]
	}
} });
//#endregion
export { tsrStartManifest };
