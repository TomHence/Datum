import { i as __toESM } from "../_runtime.mjs";
import { c as toolsByCategory, o as searchTools, s as toolList, t as categories } from "./catalog-DkD8-adi.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { o as AdSlot, r as Route$1 } from "./router-CWhg0SXy.mjs";
import { n as ToolCard, t as Input } from "./input-CNtvLvgh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tools-tXJ98vYo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ToolsIndex() {
	const { q } = Route$1.useSearch();
	const [query, setQuery] = (0, import_react.useState)(q ?? "");
	const filtered = (0, import_react.useMemo)(() => searchTools(query), [query]);
	const searching = query.trim().length > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex max-w-6xl flex-col gap-10 px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "drawing-label",
						children: "Catalog"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-semibold tracking-tight",
						children: "All tools"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "max-w-2xl text-muted",
						children: [toolList.length, " instruments for daily work. Filter by name or keyword, or jump a category."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: query,
						onChange: (e) => setQuery(e.target.value),
						placeholder: "Filter tools…",
						className: "max-w-md"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdSlot, { slot: "header" }),
			searching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
				children: filtered.map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolCard, { tool }, tool.slug))
			}) : categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: category.id,
				className: "scroll-mt-24 flex flex-col gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-2xl font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "drawing-label mr-3",
							children: category.index
						}), category.label]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: category.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
						children: toolsByCategory(category.id).map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolCard, { tool }, tool.slug))
					})
				]
			}, category.id))
		]
	});
}
//#endregion
export { ToolsIndex as component };
