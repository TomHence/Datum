import "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as cn, s as ToolIcon } from "./router-CWhg0SXy.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
function ToolCard({ tool, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/tools/$slug",
		params: { slug: tool.slug },
		className: cn("group flex flex-col gap-3 rounded-xl bg-surface p-4 shadow-card transition-[box-shadow,transform] duration-150 ease-[cubic-bezier(0.22,1,0.36,1)] hover:shadow-card-hover", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex size-10 items-center justify-center rounded-sm bg-bg text-fg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolIcon, { name: tool.icon })
			}), tool.popular ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "drawing-label",
				children: "Frequent"
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex flex-col gap-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium tracking-tight",
				children: tool.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm text-muted",
				children: tool.description
			})]
		})]
	});
}
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-md bg-elevated px-3 text-base text-fg shadow-card transition-[box-shadow] duration-150 placeholder:text-subtle file:border-0 file:bg-transparent file:text-sm file:font-medium focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
//#endregion
export { ToolCard as n, Input as t };
