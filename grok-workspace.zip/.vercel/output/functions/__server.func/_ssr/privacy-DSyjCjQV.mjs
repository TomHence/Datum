import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as SITE } from "./router-CWhg0SXy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-DSyjCjQV.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex max-w-3xl flex-col gap-6 px-4 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "drawing-label",
				children: "Privacy"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold tracking-tight",
				children: "What stays on your device."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3 text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold text-fg",
					children: "Tool input"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"Calculators, converters, generators, and text tools run entirely in your browser. The numbers, passwords, JSON, and notes you type are not uploaded to a ",
					SITE.name,
					" server."
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3 text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold text-fg",
					children: "Local storage"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This site may keep recent tools, saved tools, and your world-clock city list in your browser's local storage so the catalog feels familiar on the next visit. You can clear that data from your browser settings." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3 text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold text-fg",
					children: "Fonts"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Typefaces are loaded from Google Fonts. That request is made by your browser to Google's servers." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3 text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold text-fg",
					children: "Advertising"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Advertising is currently off. If ads are enabled later, a third-party network such as Google AdSense may set cookies and collect standard advertising data according to that network's policy." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3 text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold text-fg",
					children: "Accounts"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "There are no user accounts and no passwords stored by this site." })]
			})
		]
	});
}
//#endregion
export { PrivacyPage as component };
