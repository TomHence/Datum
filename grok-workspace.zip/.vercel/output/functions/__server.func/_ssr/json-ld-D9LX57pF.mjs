import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/json-ld-D9LX57pF.js
var import_jsx_runtime = require_jsx_runtime();
var useToolPrefs = create()(persist((set, get) => ({
	recents: [],
	favorites: [],
	touch: (slug) => set({ recents: [slug, ...get().recents.filter((item) => item !== slug)].slice(0, 8) }),
	toggleFavorite: (slug) => set({ favorites: get().favorites.includes(slug) ? get().favorites.filter((item) => item !== slug) : [slug, ...get().favorites] }),
	isFavorite: (slug) => get().favorites.includes(slug)
}), { name: "datum-tool-prefs" }));
function JsonLd({ data }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
		type: "application/ld+json",
		dangerouslySetInnerHTML: { __html: JSON.stringify(data) }
	});
}
//#endregion
export { useToolPrefs as n, JsonLd as t };
