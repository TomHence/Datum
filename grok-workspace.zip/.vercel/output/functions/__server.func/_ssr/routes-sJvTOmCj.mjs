import { i as __toESM } from "../_runtime.mjs";
import { c as toolsByCategory, i as popularTools, o as searchTools, s as toolList, t as categories } from "./catalog-DkD8-adi.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { D as Lock, T as Monitor, h as Search, nt as ArrowRight } from "../_libs/lucide-react.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as SITE, i as Button, o as AdSlot } from "./router-CWhg0SXy.mjs";
import { n as useToolPrefs, t as JsonLd } from "./json-ld-D9LX57pF.mjs";
import { n as ToolCard, t as Input } from "./input-CNtvLvgh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-sJvTOmCj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var siteFaq = [
	{
		question: "Are these tools really free?",
		answer: "Yes. Every tool on Datum is free to use. There is no account, no trial, and no paywall."
	},
	{
		question: "Do you upload what I type?",
		answer: "No. Calculators, converters, and generators run in your browser. Inputs stay on your device."
	},
	{
		question: "Will this work on my phone?",
		answer: "Yes. The layout is built for a phone-width screen first, with tap targets large enough for thumbs."
	},
	{
		question: "How many tools are there?",
		answer: `The catalog currently has ${toolList.length} instruments across calculate, convert, text, generate, develop, time, and image.`
	},
	{
		question: "Will there be ads?",
		answer: `${SITE.name} is designed so advertising can be switched on later without redesigning pages. Ads are currently off.`
	}
];
function FaqSection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-col gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "drawing-label",
			children: "Notes"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl font-semibold",
			children: "Questions, answered"
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-px overflow-hidden rounded-xl bg-border shadow-card sm:grid-cols-2",
			children: siteFaq.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "flex flex-col gap-2 bg-surface p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-medium tracking-tight",
					children: item.question
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: item.answer
				})]
			}, item.question))
		})]
	});
}
function HeroPlate() {
	const featured = popularTools().slice(0, 8);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "sheet-frame hidden min-w-0 flex-col lg:flex",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-4 border-b border-border px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "drawing-label",
					children: "Datum studio"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg font-semibold tracking-tight",
					children: "Sheet A1"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "drawing-label",
						children: "Rev 01"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "drawing-label text-fg",
						children: [toolList.length, " tools"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-1 flex-col",
				children: featured.map((tool, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-b border-border last:border-b-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/tools/$slug",
						params: { slug: tool.slug },
						className: "flex items-baseline justify-between gap-3 px-4 py-3 hover:bg-bg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex min-w-0 items-baseline gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "drawing-label w-6 shrink-0",
								children: String(index + 1).padStart(2, "0")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate font-medium",
								children: tool.name
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "drawing-label shrink-0",
							children: tool.category
						})]
					})
				}, tool.slug))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 border-t border-border px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "scale-bar",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "drawing-label",
					children: "Scale 1:1"
				})]
			})
		]
	});
}
function Home() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const recents = useToolPrefs((s) => s.recents);
	const favorites = useToolPrefs((s) => s.favorites);
	(0, import_react.useEffect)(() => {
		setHydrated(true);
	}, []);
	const recentTools = hydrated ? recents.map((slug) => toolList.find((tool) => tool.slug === slug)).filter((tool) => Boolean(tool)) : [];
	const savedTools = hydrated ? favorites.map((slug) => toolList.find((tool) => tool.slug === slug)).filter((tool) => Boolean(tool)) : [];
	const filtered = (0, import_react.useMemo)(() => searchTools(query), [query]);
	const isSearch = query.trim().length > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JsonLd, { data: {
			"@context": "https://schema.org",
			"@type": "WebSite",
			name: SITE.name,
			description: SITE.description,
			potentialAction: {
				"@type": "SearchAction",
				target: "/tools?q={search_term_string}",
				"query-input": "required name=search_term_string"
			}
		} }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JsonLd, { data: {
			"@context": "https://schema.org",
			"@type": "ItemList",
			name: `${SITE.name} daily tools`,
			numberOfItems: toolList.length,
			itemListElement: toolList.map((tool, index) => ({
				"@type": "ListItem",
				position: index + 1,
				name: tool.name,
				url: `/tools/${tool.slug}`
			}))
		} }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JsonLd, { data: {
			"@context": "https://schema.org",
			"@type": "FAQPage",
			mainEntity: siteFaq.map((item) => ({
				"@type": "Question",
				name: item.question,
				acceptedAnswer: {
					"@type": "Answer",
					text: item.answer
				}
			}))
		} }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "hero-grid border-b border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl gap-10 px-4 py-12 lg:grid-cols-[minmax(0,1fr)_22rem] lg:items-stretch sm:py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col justify-center gap-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "drawing-label",
							children: "DS-01 / Public instruments"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "max-w-xl font-display text-3xl font-semibold tracking-tight sm:text-4xl",
							children: "The tools you reach for every day."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "max-w-xl text-lg text-muted",
							children: [toolList.length, " calculators, converters, and generators. They run on your device. Nothing is uploaded. There is no account and no fee."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "relative max-w-xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "Search tools"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: query,
									onChange: (e) => setQuery(e.target.value),
									placeholder: "Search percentage, password, JSON…",
									className: "h-12 pl-10"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `#${category.id}`,
								className: "min-h-11 rounded-full bg-surface px-3 py-2 text-sm text-muted shadow-card hover:text-fg",
								children: [
									category.index,
									" ",
									category.label
								]
							}, category.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
							className: "grid max-w-xl grid-cols-3 gap-3 border-t border-border pt-5",
							children: [
								{
									label: "Tools",
									value: String(toolList.length)
								},
								{
									label: "Accounts",
									value: "0"
								},
								{
									label: "Uploads",
									value: "0"
								}
							].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "drawing-label",
								children: item.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-display text-2xl font-semibold tabular-nums",
								children: item.value
							})] }, item.label))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroPlate, {})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col gap-14 px-4 py-12",
			children: [
				isSearch ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-2xl font-semibold",
						children: [
							filtered.length,
							" result",
							filtered.length === 1 ? "" : "s"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
						children: filtered.map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolCard, { tool }, tool.slug))
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					savedTools.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-col gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "drawing-label",
							children: "Saved on this device"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
							children: savedTools.slice(0, 4).map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolCard, { tool }, tool.slug))
						})]
					}) : null,
					recentTools.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-col gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "drawing-label",
							children: "Recently used"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
							children: recentTools.slice(0, 4).map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolCard, { tool }, tool.slug))
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-col gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-end justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "drawing-label",
								children: "Frequently opened"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl font-semibold",
								children: "Popular tools"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "ghost",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/tools",
									children: ["Full catalog", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
							children: popularTools().map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolCard, { tool }, tool.slug))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdSlot, { slot: "inContent" }),
					categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: category.id,
						className: "scroll-mt-24 flex flex-col gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "font-display text-2xl font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "drawing-label mr-3",
									children: category.index
								}), category.label]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hidden max-w-sm text-sm text-muted sm:block",
								children: category.blurb
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
							children: toolsByCategory(category.id).map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolCard, { tool }, tool.slug))
						})]
					}, category.id))
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "grid gap-4 rounded-xl bg-surface p-5 shadow-card sm:grid-cols-3",
					children: [
						{
							icon: Lock,
							title: "Private by design",
							body: "Inputs never leave this tab. There is no account and no cloud processing."
						},
						{
							icon: Monitor,
							title: "Works on your phone",
							body: "Large tap targets, a searchable catalog, and layouts that fit a narrow screen."
						},
						{
							icon: ArrowRight,
							title: "Free, always",
							body: "Use every tool without paying. Ads can be added later without changing the layout."
						}
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
								className: "size-5 text-accent",
								strokeWidth: 1.75
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-medium",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: item.body
							})
						]
					}, item.title))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqSection, {})
			]
		})
	] });
}
//#endregion
export { Home as component };
