import { s as toolList } from "./catalog-DkD8-adi.mjs";
import { c as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as SITE } from "./router-CWhg0SXy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-Cez7NxUp.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex max-w-3xl flex-col gap-6 px-4 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "drawing-label",
				children: "About"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold tracking-tight",
				children: "A small public workshop."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-lg text-muted",
				children: [
					SITE.name,
					" is a set of ",
					toolList.length,
					" everyday tools: the calculator you open before a meeting, the converter you need at a desk, the password you generate once and copy."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "Every tool runs in your browser. We do not create accounts, we do not store what you type on a server, and there is no charge to use the catalog."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "The layout is already prepared for advertising. When ads are enabled in one config file, they occupy reserved slots in the header, sidebar, in-content band, and footer. Until then those slots stay empty so the pages stay quiet."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-muted",
				children: [
					"If you want a specific instrument added, start with the",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/tools",
						className: "text-fg underline underline-offset-2",
						children: "full catalog"
					}),
					" ",
					"— most daily jobs are already there."
				]
			})
		]
	});
}
//#endregion
export { AboutPage as component };
